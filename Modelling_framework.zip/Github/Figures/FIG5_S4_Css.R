#################################
# #### CS PKPD model framework ##
## S.pneumoniae D39 adaptation ##  
####      FQ resistant         ##
##  Combination treatment for  ##    
##    CIP + ERY. LNZ or PEN    ##
##      With interaction       ##
#         Processing script    ##
## Scenario 2: css             ##
##    Written by Linda Aulin   ##
#################################



########
library(dplyr)
library(tidyr)
library(forcats)
library(ggplot2)
library(viridis)
library(patchwork)

memory.limit() 
memory.limit(24000)
n = 500

ET <- read.csv("Data/EXP_DAT/ET.csv", sep = ";")
#source("Scripts/CS_model/Figures/Plot_script_v7.R")

Scenario_n <- 2

dat_path <- paste0("Results/PNAS/Simulations/Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i)) %>% 
    filter(time == 336)
  df_ii$ID <- as.numeric(strsplit(df_i, split = "_")[[1]][4])
  
  df_list[[i]] <- df_ii
  
}




df_raw <- bind_rows(df_list)  

  
  
df_2<- df_raw %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n,
         model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model)) #%>% 
                                  

# Css scenarios
Scenario_n <- 14

dat_path <- paste0("Results/PNAS/Simulations/Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i)) %>% 
    filter(time == 336)
  df_ii$ID <- as.numeric(strsplit(df_i, split = "_")[[1]][4])
  
  df_list[[i]] <- df_ii
  
}




df_raw <- bind_rows(df_list)  


df<- df_raw %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n,
         model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model)) %>% 
  bind_rows(df_2)


# 
CB_col <- c("black", "#1E88E5", "#FFC107",  "#BE1908")
col_order = c( "#1E88E5", "#FFC107",  "#BE1908")
col_A <- "#72bfc5"
col_B <- "#6f30a0"



#####

# make_PD_plot <- function(df, col_order = c("#70ad47",  "#001ac0", "#ed7c31","#ff0000")){
bind_df <- data.frame(DRUG = c("LNZ", "ERY", "PEN"),
                      CSS_AB = 0)

df_cip<- df %>% 
  distinct(time, Population, model, Scenario, ID, CSS_CIP, CSS_AB, .keep_all = T)  %>% 
  filter(DRUG == "CIP") %>% 
  select(-DRUG) %>% 
  left_join(bind_df)




df_plot<- df %>% 
    distinct(time, Population, model, Scenario, ID, CSS_CIP, CSS_AB, .keep_all = T) %>% 
  filter(DRUG != "CIP") %>% 
  bind_rows(df_cip) %>% 
  left_join(ET) %>% 
  mutate(ref_MIC = MIC_AB_S) %>% 
  pivot_longer(cols=contains("MIC_AB"), names_to = "MIC_pop", values_to = "MIC") %>% 
  filter((Population == "S" & MIC_pop == "MIC_AB_S" |
          Population == "GyrA" & MIC_pop == "MIC_AB_GyrA" )|
           (Population == "ParC" & MIC_pop == "MIC_AB_ParC" )|
           (Population == "R" & MIC_pop == "MIC_AB_R" )) %>% 
  mutate(CE = as.factor(ifelse(log2(MIC/ref_MIC) == 0, "No CE",
                               ifelse(log2(MIC/ref_MIC) > 0, "CR", "CS")))) %>% 
        mutate( CE  = fct_relevel(CE, "No CE", after = 1),
         # KG_o = ifelse(KG/KG_S == 1, 1, 2),
         Pop_o = ifelse(Population == "S", 1,
                        ifelse(Population == "GyrA", 2,
                               ifelse(Population == "ParC", 3,4)))) %>% 
  mutate(Population = fct_reorder(Population, Pop_o))


pop.labs <- c("py", "gx","gxpy")
names(pop.labs) <- c("ParC", "GyrA", "R")
    

    
    pop.labs <- c("WT", "py", "gx","gxpy")
    names(pop.labs) <- c("S", "ParC", "GyrA", "R")
    
    plot_res_ERY_point<- df_plot %>% 
      filter(model == "ERY") %>% 
      ggplot(aes(x = as.factor(CSS_CIP)))+
      geom_line( aes(y = R_Dev*100/n,  col = as.factor(ET), group= interaction( ET),
                     linetype = CE),
                 position = position_dodge(width = 0.6),   
                 size = 0.5)+
      geom_point( aes(y = R_Dev*100/n,  fill = as.factor(ET), col = as.factor(ET), group= interaction(ET), shape = CE),
                  position = position_dodge(width = 0.6),
                  size = 3)+
      
      facet_grid(Population~paste(CSS_AB, "x MIC", model), labeller = labeller(Population = pop.labs)) + 
      scale_shape_manual(values = c(24, 21, 25), drop = F)+
      scale_linetype_manual(values = c("longdash", "solid", "dotted"), drop = F)+
      scale_color_viridis(discrete=TRUE, option="turbo") +
      scale_fill_viridis(discrete=TRUE, option="turbo") +
      labs(x = "x MIC CIP",
           y = "Probability of resistance (%)",
           fill = "Evolutionary\ntrajectory (ET)",
           col = "Evolutionary\ntrajectory (ET)",
           linetype = "Collateral effect",
           shape = "Collateral effect")+
      theme_bw() +
      theme(text = element_text(size = 20),
            panel.grid.minor.y =  element_blank())
    #plot_res_ERY_point
    

    
    plot_res_LNZ_point<- df_plot %>% 
      filter(model == "LNZ") %>% 
      ggplot(aes(x = as.factor(CSS_CIP)))+
      geom_line( aes(y = R_Dev*100/n,  col = as.factor(ET), group= interaction( ET),
                     linetype = CE),
                 position = position_dodge(width = 0.6),   
                 size = 0.5)+
      geom_point( aes(y = R_Dev*100/n,  fill = as.factor(ET), col = as.factor(ET), group= interaction(ET), shape = CE),
                  position = position_dodge(width = 0.6),
                  size = 3)+
      
      facet_grid(Population~paste(CSS_AB, "x MIC", model), labeller = labeller(Population = pop.labs)) + 
      scale_shape_manual(values = c(24, 21, 25), drop = F)+
      scale_linetype_manual(values = c("longdash", "solid", "dotted"), drop = F)+
      
      scale_color_viridis(discrete=TRUE, option="turbo") +
      scale_fill_viridis(discrete=TRUE, option="turbo") +
      labs(x = "x MIC CIP",
           y = "Probability of resistance (%)",
           fill = "Evolutionary\ntrajectory (ET)",
           col = "Evolutionary\ntrajectory (ET)",
           linetype = "Collateral effect",
           shape = "Collateral effect")+
      theme_bw() +
      theme(text = element_text(size = 20),
            panel.grid.minor.y =  element_blank())
   # plot_res_LNZ_point
    
    
    
    plot_res_PEN_point<- df_plot %>% 
      filter(model == "PEN") %>% 
      ggplot(aes(x = as.factor(CSS_CIP)))+
      geom_line( aes(y = R_Dev*100/n,  col = as.factor(ET), group= interaction( ET),
                     linetype = CE),
                 position = position_dodge(width = 0.6),   
                 size = 0.5)+
      geom_point( aes(y = R_Dev*100/n,  fill = as.factor(ET), col = as.factor(ET), group= interaction(ET), shape = CE),
                  position = position_dodge(width = 0.6),
                  size = 3)+
      
      facet_grid(Population~paste(CSS_AB, "x MIC", model), labeller = labeller(Population = pop.labs)) + 
      scale_shape_manual(values = c(24, 21, 25), drop = F)+
      
      scale_color_viridis(discrete=TRUE, option="turbo") +
      scale_fill_viridis(discrete=TRUE, option="turbo") +
      scale_linetype_manual(values = c("longdash", "solid", "dotted"), drop = F)+
      labs(x = "x MIC CIP",
           y = "Probability of resistance (%)",
           fill = "Evolutionary\ntrajectory (ET)",
           col = "Evolutionary\ntrajectory (ET)",
           linetype = "Collateral effect",
           shape = "Collateral effect")+
      theme_bw() +
      theme(text = element_text(size = 20),
            panel.grid.minor.y =  element_blank())
   # plot_res_PEN_point
    
    
    

    pdf("Results/PNAS/resubmission_figures/Final/FIGS4_Css.pdf", width = 20, height = 12)
    plot_res_ERY_point+ plot_res_PEN_point +plot_layout(ncol = 1, guides = "collect")+plot_annotation(tag_levels = "A")
    dev.off()
    
    
    
    df_plot_2 <- df %>% 
      filter(time == 336 & model == "LNZ" & CSS_CIP == 1 & CSS_AB == 1) %>% 
      distinct(Population, ID, Scenario, model, Strain_R, .keep_all = T)%>%
      mutate(M = ifelse(Population == "GyrA", gsub("GyrA:", "g", Strain_GyrA), 
                        ifelse(Population == "ParC", gsub("ParC:", "p", Strain_ParC),
                               ifelse(Population == "R", paste0(gsub("GyrA:", "g", Strain_GyrA),  gsub("ParC:", "p", Strain_ParC)), "WT")))) %>% 
      
      mutate( n = 500) %>% 
      ungroup() %>% 
      
      mutate(p = R_Dev/n) %>% 
      mutate(
        CI = 1.96*sqrt(p*(1-p)/n),
        SE = sqrt(p*(1-p)/n), 
        M_0 = ifelse(Population == "S", 1,
                     ifelse(Population == "GyrA", 2,
                            ifelse(Population == "ParC", 3, 4)))) %>%
      arrange(desc(M_0)) %>%
      group_by(M_0, M) %>%
      mutate(M_o = cur_group_id()) %>%

      mutate(M = fct_reorder(M, M_o))  %>% 
      mutate(ref_MIC = MIC_AB_S) %>% 
      pivot_longer(cols=contains("MIC_AB"), names_to = "MIC_pop", values_to = "MIC") %>% 
      filter((Population == "S" & MIC_pop == "MIC_AB_S")|
               (Population == "GyrA" & MIC_pop == "MIC_AB_GyrA" )|
               (Population == "ParC" & MIC_pop == "MIC_AB_ParC" )|
               (Population == "R" & MIC_pop == "MIC_AB_R" )) %>% 
      mutate(CE = as.factor(ifelse(Population == "S", "WT",
                                   ifelse(log2(MIC/ref_MIC) == 0, "No CE",
                                   ifelse(log2(MIC/ref_MIC) > 0, "CR", "CS"))))) %>% 
      left_join(ET)
    
    
    

    
    plot_7b<- df_plot_2 %>% 
      ggplot(              aes( x = M, 
                                y = R_Dev*100/n,
                                fill = Population))  +
      
      geom_col(aes(group = Population),
               position = "dodge", width = 0.6)+
      geom_point(aes(group = Population, shape = CE, col = Population), y = 105, size = 3)+
      
      geom_linerange(aes(ymin = p*100 - SE*100,
                         ymax = p*100 +SE*100, 
                         group = Population),
                     col = "black", position = position_dodge(width = 0.6))+
      facet_grid(~paste("ET:", ET), scales = "free_x")+
      coord_cartesian(ylim =  c(0, 110))+
      
      labs(x = "Subpopulation",
           y = "Probability of resistance (%)",
           fill = "Subpopulation",
           col = "Subpopulation",
           shape = "Collateral effect")+
      scale_fill_manual(values = c("black", col_order),
                        labels = c("WT", "py", "gx","gxpy"))+
      scale_color_manual(values = c("black", col_order),
                        labels = c("WT", "py", "gx","gxpy"))+
      
      scale_shape_manual(values = c(22, 24, 21, 25), drop = F)+
      theme_bw()+
      theme(text = element_text(size = 20),
            axis.text.x = element_text(angle = 90, colour = c("black", col_order[c(2,1,3)]), vjust = 0.2, hjust = 0.95))
    
    

    
   # plot_res_LNZ_point +   plot_7b +plot_layout(ncol = 1, heights = c(1,0.3))
    
    
    
    
    pdf("Results/PNAS/resubmission_figures/Final/FIG5_Css.pdf", width = 20, height = 13)
    plot_res_LNZ_point  +   plot_7b +plot_layout(ncol = 1, heights = c(1,0.3)) +plot_annotation(tag_levels = "A")
    dev.off()
    
    
   
    