#################################
# #### CS PKPD model framework ##
## S.pneumoniae D39 adaptation ##  
####      FQ resistant         ##
##  Combination treatment for  ##    
##    CIP + ERY. LNZ or PEN    ##
##      With interaction       ##
#         Processing script    ##
## Scenario 2: css             ##
##    Written by Linda Aulin   ##
#################################



########
library(dplyr)
library(tidyr)
library(forcats)
library(ggplot2)

memory.limit() 
memory.limit(24000)
n = 500
#source("Scripts/CS_model/Figures/Plot_script_v7.R")
CB_col <- c("black", "#1E88E5", "#FFC107",  "#BE1908")
col_order = c( "#1E88E5", "#FFC107",  "#BE1908")
col_A <- "#72bfc5"
col_B <- "#6f30a0"

theme_CS <- function () { 
  theme_bw() %+replace% 
    theme(text = element_text(size = 20),
          plot.margin=unit(c(9,9,9,9),"mm")
    )
}


Scenario_n <- 2

dat_path <- paste0("Results/PNAS/Simulations/Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i)) %>% 
    filter(time == 336)
  df_ii$ID <- as.numeric(strsplit(df_i, split = "_")[[1]][4])
  
  df_list[[i]] <- df_ii
  
}


df_2 <- bind_rows(df_list)  %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n,
         model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model)) %>% 
  filter(CSS_CIP == 1 & CSS_AB == 1 & DRUG == "LNZ")




Scenario_n <- 3

dat_path <- paste0("Results/PNAS/Simulations/Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i)) %>% 
    filter(time == 336)
  df_ii$ID <- as.numeric(strsplit(df_i, split = "_")[[1]][4])
  
  df_list[[i]] <- df_ii
  
}




df_3 <- bind_rows(df_list)  %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n,
         model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model))

Scenario_n <- 4

dat_path <- paste0("Results/PNAS/Simulations/Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i)) %>% 
    filter(time == 336)
  df_ii$ID <- as.numeric(strsplit(df_i, split = "_")[[1]][4])
  
  df_list[[i]] <- df_ii
  
}

df_4 <- bind_rows(df_list)  %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n,
         model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model))

Scenario_n <- 5

dat_path <- paste0("Results/PNAS/Simulations/Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i)) %>% 
    filter(time == 336)
  df_ii$ID <- as.numeric(strsplit(df_i, split = "_")[[1]][4])
  
  df_list[[i]] <- df_ii
  
}




df_5 <- bind_rows(df_list)  


ET <- read.csv("Data/EXP_DAT/ET.csv", sep = ";")
#source("Scripts/CS_model/Figures/Plot_script_v7.R")




df_LNZ<- df_5 %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n,
         model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model)) %>% 
  bind_rows(df_3) %>% 
  bind_rows(df_4) %>% 
  bind_rows(df_2) %>% 
  left_join(ET)
# 



df_LNZ_plot<- df_LNZ %>% 
  distinct(time, Population, model, Scenario, ID, CSS_CIP, CSS_AB, .keep_all = T) %>% 
  pivot_longer(cols=c(MIC_AB_ParC, MIC_AB_GyrA, MIC_AB_R), names_to = "MIC_pop", values_to = "MIC") %>% 
  filter((Population == "GyrA" & MIC_pop == "MIC_AB_GyrA" )|
           (Population == "ParC" & MIC_pop == "MIC_AB_ParC" )|
           (Population == "R" & MIC_pop == "MIC_AB_R" )) %>% 
  mutate(CE = as.factor(ifelse(log2(MIC/MIC_AB_S) == 0, "No CE",
                     ifelse(log2(MIC/MIC_AB_S) > 0, "CR", "CS")))) %>% 
  pivot_longer(cols=c(KG_ParC, KG_GyrA, KG_R), names_to ="KG_pop", values_to = "KG") %>% 
  filter((Population == "GyrA"   & KG_pop == "KG_GyrA" )|
           (Population == "ParC" & KG_pop == "KG_ParC" )|
           (Population == "R"    & KG_pop == "KG_R" )) %>%
  mutate(Sim_scen = ifelse(Scenario == 2, "Collateral and\nfitness effects",
                           ifelse(Scenario == 3, "No effects",
                                  ifelse(Scenario == 4, "Fitness effects", "Collateral effects"))),
         CE  = fct_relevel(CE, "No CE", after = 1),
         KG_o = ifelse(KG/KG_S == 1, 1, 2),
         Pop_o = ifelse(Population == "S", 1,
                        ifelse(Population == "GyrA", 2,
                               ifelse(Population == "ParC", 3,4)))) %>% 
  mutate(Population = fct_reorder(Population, Pop_o)) %>% 
  mutate(Strain = ifelse(Population == "GyrA", 
                         gsub("GyrA:", "g", Strain_GyrA),
                         ifelse(Population == "ParC", 
                                gsub("ParC:", "p", Strain_ParC),
                                paste0( gsub("GyrA:", "g", Strain_GyrA), gsub("ParC:", "p", Strain_ParC)))))
  

test_LNZ <- df_LNZ_plot %>% 
  select(Population, ET, Sim_scen, R_Dev, Strain_R, Strain_GyrA, Strain_ParC, contains("MIC_CIP"), CE)

pop.labs <- c("py", "gx","gxpy")
names(pop.labs) <- c("ParC", "GyrA", "R")

pdf("Results/PNAS/resubmission_figures/Final/FIG6A_LNZ_Effects.pdf", width = 16, height = 12)



p <- ggplot(df_LNZ_plot, aes(x = Strain))+

  geom_point( aes(y = R_Dev*100/n,  fill = KG/KG_S, group= ET, shape = CE),
              position = position_dodge(width = 0.7), size = 7, col = "black") +
  geom_text(aes(label = ET, y = R_Dev*100/n,  group= ET, col = as.factor(KG_o)),
            position = position_dodge(width = 0.7), size = 5,  fontface = "bold", show.legend = F)+
  facet_grid(Sim_scen~Population, labeller = labeller(Population = pop.labs), scales = "free_x") + 
  scale_fill_gradient2(low = "navy", mid = "white", high = "firebrick3", midpoint = 1 )+
  scale_color_manual(values = c("black",  "white")) + 
ggtitle("LNZ")+
  coord_cartesian(ylim= c(0, 100))+
  scale_shape_manual(values = c(24, 21, 25), drop = F)+
  labs(shape = "Collateral effect",
       y = " Probability of resistance (%)",
       fill = "Relative\ngrowth rate",
       x = "Strain")+
  theme_CS()   +
  theme(strip.text.x = element_text(colour = "white", face = "bold"),
        axis.text.x = element_text(angle = 75, hjust = 1))


g <- ggplot_gtable(ggplot_build(p))
stripr <- which(grepl('strip-t', g$layout$name))
fills <- col_order[c(2,1,3)]
k <- 1
for (i in stripr) {
  j <- which(grepl('rect', g$grobs[[i]]$grobs[[1]]$childrenOrder))
  g$grobs[[i]]$grobs[[1]]$children[[j]]$gp$fill <- fills[k]
  k <- k+1
}

grid::grid.draw(g)
dev.off()


######## ERY
Scenario_n <- 2

dat_path <- paste0("Results/PNAS/Simulations/Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i)) %>% 
    filter(time == 336)
  df_ii$ID <- as.numeric(strsplit(df_i, split = "_")[[1]][4])
  
  df_list[[i]] <- df_ii
  
}


df_2 <- bind_rows(df_list)  %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n,
         model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model)) %>% 
  filter(CSS_CIP == 1 & CSS_AB == 1 & DRUG == "ERY")




Scenario_n <- 6

dat_path <- paste0("Results/PNAS/Simulations/Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i)) %>% 
    filter(time == 336)
  df_ii$ID <- as.numeric(strsplit(df_i, split = "_")[[1]][4])
  
  df_list[[i]] <- df_ii
  
}




df_6 <- bind_rows(df_list)  %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n,
         model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model))

Scenario_n <- 7

dat_path <- paste0("Results/PNAS/Simulations/Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i)) %>% 
    filter(time == 336)
  df_ii$ID <- as.numeric(strsplit(df_i, split = "_")[[1]][4])
  
  df_list[[i]] <- df_ii
  
}

df_7 <- bind_rows(df_list)  %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n,
         model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model))

Scenario_n <- 8

dat_path <- paste0("Results/PNAS/Simulations/Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i)) %>% 
    filter(time == 336)
  df_ii$ID <- as.numeric(strsplit(df_i, split = "_")[[1]][4])
  
  df_list[[i]] <- df_ii
  
}




df_8 <- bind_rows(df_list)  


ET <- read.csv("Data/EXP_DAT/ET.csv", sep = ";")
#source("Scripts/CS_model/Figures/Plot_script_v7.R")




df_ERY<- df_8 %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n,
         model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model)) %>% 
  bind_rows(df_6) %>% 
  bind_rows(df_7) %>% 
  bind_rows(df_2) %>% 
  left_join(ET)
# 



df_ERY_plot<- df_ERY %>% 
  distinct(time, Population, model, Scenario, ID, CSS_CIP, CSS_AB, .keep_all = T) %>% 
  pivot_longer(cols=c(MIC_AB_ParC, MIC_AB_GyrA, MIC_AB_R), names_to = "MIC_pop", values_to = "MIC") %>% 
  filter((Population == "GyrA" & MIC_pop == "MIC_AB_GyrA" )|
           (Population == "ParC" & MIC_pop == "MIC_AB_ParC" )|
           (Population == "R" & MIC_pop == "MIC_AB_R" )) %>% 
  mutate(CE = as.factor(ifelse(log2(MIC/MIC_AB_S) == 0, "No CE",
                               ifelse(log2(MIC/MIC_AB_S) > 0, "CR", "CS")))) %>% 
  pivot_longer(cols=c(KG_ParC, KG_GyrA, KG_R), names_to ="KG_pop", values_to = "KG") %>% 
  filter((Population == "GyrA"   & KG_pop == "KG_GyrA" )|
           (Population == "ParC" & KG_pop == "KG_ParC" )|
           (Population == "R"    & KG_pop == "KG_R" )) %>%
  mutate(Sim_scen = ifelse(Scenario == 2, "Collateral and\nfitness effects",
                           ifelse(Scenario == 6, "No effects",
                                  ifelse(Scenario == 7, "Fitness effects", "Collateral effects"))),
         CE  = fct_relevel(CE, "No CE", after = 1),
         KG_o = ifelse(KG/KG_S == 1, 1, 2),
         Pop_o = ifelse(Population == "S", 1,
                        ifelse(Population == "GyrA", 2,
                               ifelse(Population == "ParC", 3,4)))) %>% 
  mutate(Population = fct_reorder(Population, Pop_o))%>% 
  mutate(Strain = ifelse(Population == "GyrA", 
                         gsub("GyrA:", "g", Strain_GyrA),
                         ifelse(Population == "ParC", 
                                gsub("ParC:", "p", Strain_ParC),
                                paste0( gsub("GyrA:", "g", Strain_GyrA), gsub("ParC:", "p", Strain_ParC)))))


test_ERY <- df_ERY_plot %>% 
  select(Population, ET, Sim_scen, R_Dev, Strain_R, Strain_GyrA, Strain_ParC, contains("MIC_CIP"), CE)


pop.labs <- c("py", "gx","gxpy")
names(pop.labs) <- c("ParC", "GyrA", "R")

pdf("Results/PNAS/resubmission_figures/Final/FIGS7A_ERY_Effects.pdf", width = 16, height = 12)



p <- ggplot(df_ERY_plot, aes(x = Strain))+
  
  geom_point( aes(y = R_Dev*100/n,  fill = KG/KG_S, group= ET, shape = CE),
              position = position_dodge(width = 0.7), size = 7, col = "black") +
  geom_text(aes(label = ET, y = R_Dev*100/n,  group= ET, col = as.factor(KG_o)),
            position = position_dodge(width = 0.7), size = 5,  fontface = "bold", show.legend = F)+
  facet_grid(Sim_scen~Population, labeller = labeller(Population = pop.labs), scales = "free_x") + 
  scale_fill_gradient2(low = "navy", mid = "white", high = "firebrick3", midpoint = 1 )+
  scale_color_manual(values = c("black",  "white")) + 
  ggtitle("ERY")+
  coord_cartesian(ylim= c(0, 100))+
  scale_shape_manual(values = c(24, 21, 25), drop = F)+
  labs(shape = "Collateral effect",
       y = " Probability of resistance (%)",
       fill = "Relative\ngrowth rate",
       x = "Strain")+
  theme_CS()   +
  theme(strip.text.x = element_text(colour = "white", face = "bold"),
        axis.text.x = element_text(angle = 75, hjust = 1))





g <- ggplot_gtable(ggplot_build(p))
stripr <- which(grepl('strip-t', g$layout$name))
fills <- col_order[c(2,1,3)]
k <- 1
for (i in stripr) {
  j <- which(grepl('rect', g$grobs[[i]]$grobs[[1]]$childrenOrder))
  g$grobs[[i]]$grobs[[1]]$children[[j]]$gp$fill <- fills[k]
  k <- k+1
}

grid::grid.draw(g)
dev.off()




######## PEN
Scenario_n <- 2

dat_path <- paste0("Results/PNAS/Simulations/Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i)) %>% 
    filter(time == 336)
  df_ii$ID <- as.numeric(strsplit(df_i, split = "_")[[1]][4])
  
  df_list[[i]] <- df_ii
  
}


df_2 <- bind_rows(df_list)  %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n,
         model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model)) %>% 
  filter(CSS_CIP == 0.5 & CSS_AB == 1 & DRUG == "PEN")




Scenario_n <- 9

dat_path <- paste0("Results/PNAS/Simulations/Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i)) %>% 
    filter(time == 336)
  df_ii$ID <- as.numeric(strsplit(df_i, split = "_")[[1]][4])
  
  df_list[[i]] <- df_ii
  
}




df_9 <- bind_rows(df_list)  %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n,
         model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model))

Scenario_n <- 10

dat_path <- paste0("Results/PNAS/Simulations/Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i)) %>% 
    filter(time == 336)
  df_ii$ID <- as.numeric(strsplit(df_i, split = "_")[[1]][4])
  
  df_list[[i]] <- df_ii
  
}

df_10 <- bind_rows(df_list)  %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n,
         model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model))

Scenario_n <- 11

dat_path <- paste0("Results/PNAS/Simulations/Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i)) %>% 
    filter(time == 336)
  df_ii$ID <- as.numeric(strsplit(df_i, split = "_")[[1]][4])
  
  df_list[[i]] <- df_ii
  
}




df_11 <- bind_rows(df_list)  


ET <- read.csv("Data/EXP_DAT/ET.csv", sep = ";")
#source("Scripts/CS_model/Figures/Plot_script_v7.R")




df_PEN<- df_11 %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n,
         model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model)) %>% 
  bind_rows(df_9) %>% 
  bind_rows(df_10) %>% 
  bind_rows(df_2) %>% 
  left_join(ET)
# 

df_PEN_plot<- df_PEN %>% 
  distinct(time, Population, model, Scenario, ID, CSS_CIP, CSS_AB, .keep_all = T) %>% 
  pivot_longer(cols=c(MIC_AB_ParC, MIC_AB_GyrA, MIC_AB_R), names_to = "MIC_pop", values_to = "MIC") %>% 
  filter((Population == "GyrA" & MIC_pop == "MIC_AB_GyrA" )|
           (Population == "ParC" & MIC_pop == "MIC_AB_ParC" )|
           (Population == "R" & MIC_pop == "MIC_AB_R" )) %>% 
  mutate(CE = as.factor(ifelse(log2(MIC/MIC_AB_S) == 0, "No CE",
                               ifelse(log2(MIC/MIC_AB_S) > 0, "CR", "CS")))) %>% 
  pivot_longer(cols=c(KG_ParC, KG_GyrA, KG_R), names_to ="KG_pop", values_to = "KG") %>% 
  filter((Population == "GyrA"   & KG_pop == "KG_GyrA" )|
           (Population == "ParC" & KG_pop == "KG_ParC" )|
           (Population == "R"    & KG_pop == "KG_R" )) %>%
  mutate(Sim_scen = ifelse(Scenario == 2, "Collateral and\nfitness effects",
                           ifelse(Scenario == 11, "No effects",
                                  ifelse(Scenario == 10, "Fitness effects", "Collateral effects"))),
         CE  = fct_relevel(CE, "No CE", after = 1),
         KG_o = ifelse(KG/KG_S == 1, 1, 2),
         Pop_o = ifelse(Population == "S", 1,
                        ifelse(Population == "GyrA", 2,
                               ifelse(Population == "ParC", 3,4)))) %>% 
  mutate(Population = fct_reorder(Population, Pop_o))%>% 
  mutate(Strain = ifelse(Population == "GyrA", 
                         gsub("GyrA:", "g", Strain_GyrA),
                         ifelse(Population == "ParC", 
                                gsub("ParC:", "p", Strain_ParC),
                                paste0( gsub("GyrA:", "g", Strain_GyrA), gsub("ParC:", "p", Strain_ParC)))))

test_PEN <- df_PEN_plot %>% 
  select(Population, ET, Sim_scen, R_Dev, Strain_R, Strain_GyrA, Strain_ParC, contains("MIC_CIP"))



pop.labs <- c("py", "gx","gxpy")
names(pop.labs) <- c("ParC", "GyrA", "R")

pdf("Results/PNAS/resubmission_figures/Final/FIGS7B_PEN_Effects.pdf", width = 16, height = 12)



p <- ggplot(df_PEN_plot, aes(x = Strain))+
  
  geom_point( aes(y = R_Dev*100/n,  fill = KG/KG_S, group= ET, shape = CE),
              position = position_dodge(width = 0.7), size = 7, col = "black") +
  geom_text(aes(label = ET, y = R_Dev*100/n,  group= ET, col = as.factor(KG_o)),
            position = position_dodge(width = 0.7), size = 5,  fontface = "bold", show.legend = F)+
  facet_grid(Sim_scen~Population, labeller = labeller(Population = pop.labs), scales = "free_x") + 
  scale_fill_gradient2(low = "navy", mid = "white", high = "firebrick3", midpoint = 1 )+
  scale_color_manual(values = c("black",  "white")) + 
  ggtitle("PEN")+
  coord_cartesian(ylim= c(0, 100))+
  scale_shape_manual(values = c( 25, 21), drop = F)+
  labs(shape = "Collateral effect",
       y = " Probability of resistance (%)",
       fill = "Relative\ngrowth rate",
       x = "Strain")+
  theme_CS()   +
  theme(strip.text.x = element_text(colour = "white", face = "bold"),
        axis.text.x = element_text(angle = 75, hjust = 1))





g <- ggplot_gtable(ggplot_build(p))
stripr <- which(grepl('strip-t', g$layout$name))
fills <- col_order[c(2,1,3)]
k <- 1
for (i in stripr) {
  j <- which(grepl('rect', g$grobs[[i]]$grobs[[1]]$childrenOrder))
  g$grobs[[i]]$grobs[[1]]$children[[j]]$gp$fill <- fills[k]
  k <- k+1
}

grid::grid.draw(g)
dev.off()

# all_df <- df_PEN_plot %>% 
#   bind_rows(df_LNZ_plot) %>% 
#   bind_rows(df_ERY_plot)
# 
# 
# 
# p <- ggplot(all_df, aes(x = CE))+
#   
#   geom_point( aes(y = R_Dev*100/n,  fill = KG/KG_S, group= ET),
#               position = position_dodge(width = 0.7), size = 5, shape = 21, col = "black") +
#   geom_text(aes(label = ET, y = R_Dev*100/n,  group= ET, col = as.factor(KG_o)),
#             position = position_dodge(width = 0.7), size = 3,  fontface = "bold", show.legend = F)+
#   facet_grid(Sim_scen~Population+AB, labeller = labeller(Population = pop.labs)) + 
#   scale_fill_gradient2(low = "navy", mid = "white", high = "firebrick3", midpoint = 1 )+
#   scale_color_manual(values = c("black",  "white")) + 
#   labs(x = "Collateral effect",
#        y = " Probability of resistance (%)",
#        fill = "Relative\ngrowth rate",
#        col = "Subpopulation")+
#   theme_CS()   +
#   theme(strip.text.x = element_text(colour = "white", face = "bold"))
# 
# dev.off()
# 
