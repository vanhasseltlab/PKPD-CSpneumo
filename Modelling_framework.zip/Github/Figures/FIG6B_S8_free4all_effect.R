#################################
# #### CS PKPD model framework ##
## S.pneumoniae D39 adaptation ##  
####      FQ resistant         ##
##  Combination treatment for  ##    
##    CIP + ERY. LNZ or PEN    ##
##      With interaction       ##
#         Processing script    ##
##        Scenario 15-18       ##
##        disentangle          ##
##      LNZ, Free 4 all        ##
##    Written by Linda Aulin   ##
#################################


         
########
library(dplyr)
library(tidyr)
library(forcats)
library(ggplot2)
library(patchwork)



#Increasememory limit due to large data set
memory.limit() 
memory.limit(24000)



#Select relevant scenarios 
scenario_v <- 15:26

df_list <- list()
for(i in 1:length(scenario_v)){
  

  Scenario_n <- scenario_v[i]

  dat_path <- paste0("Results/PNAS/Simulations/Scenario_", Scenario_n)
  file_list <-list.files(dat_path, pattern = "_n")
  Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds")) %>% 
    rename(model = AB)
  # 
  # 
  # 
  df_i <- file_list
  df_raw<- readRDS(paste0(dat_path, "/",df_i))
  # 
  # 
  # 
  df<- df_raw %>%
    mutate(S0 = 10^4) %>%
    mutate(Scenario = Scenario_n)%>%
    mutate(model = as.factor(model)) %>%
    ungroup() %>%
    mutate(Population = ifelse(Population == "S", "WT", Population)) %>%
   filter(time == 336) %>% 
    left_join(Scenario_input)

  df_list[[i]] <- df
  
}


df_all <- bind_rows(df_list)




#number of simulation realizations 
n = 500

CB_col <- c("black", "#1E88E5", "#FFC107",  "#BE1908")
col_order = c( "#1E88E5", "#FFC107",  "#BE1908")
col_A <- "#72bfc5"
col_B <- "#6f30a0"

theme_CS <- function () { 
  theme_bw() %+replace% 
    theme(text = element_text(size = 20),
          plot.margin=unit(c(9,9,9,9),"mm")
    )
}

#####

#MAke data compatible for plotting
  df_plot<- df_all %>% 
   distinct(time, Population, model, Scenario,   .keep_all = T) %>% 
  mutate(ref_MIC = MIC_AB_S) %>% 
  pivot_longer(cols=contains("MIC_AB"), names_to = "MIC_pop", values_to = "MIC") %>% 
  separate(MIC_pop, into = c("MIC_X", "AB_X", "MIC_pop"), sep = "_" ) %>% 
  select(-"MIC_X", -"AB_X") %>% 
  filter(Population == MIC_pop ) %>% 
  mutate(CE = as.factor(ifelse(log2(MIC/ref_MIC) == 0, "No CE",
                               ifelse(log2(MIC/ref_MIC) > 0, "CR", "CS")))) %>%
  mutate(ref_KG = KG_S) %>% 
  pivot_longer(cols=contains("KG_"), names_to = "KG_pop", values_to = "KG") %>% 
  separate(KG_pop, into = c("KG_X", "KG_pop"), sep = "_" ) %>% 
  select(-"KG_X") %>% 
  filter(Population == KG_pop ) %>%

    
  mutate(Sim_scen = ifelse(Scenario %in% c(18, 19,23), "Collateral and\nfitness effects",
                           ifelse(Scenario %in% c(15,20,26), "No effects",
                                  ifelse(Scenario %in% c(17,22,25), "Fitness effects", "Collateral effects"))),
         CE  = fct_relevel(CE, "No CE", after = 1),
         KG_o = ifelse(KG/ref_KG == 1, 1, 2)) #,


pop.labs <- c("py", "gx","gxpy")
names(pop.labs) <- c("ParC", "GyrA", "R")

pdf("Results/PNAS/resubmission_figures/Final/FIG6B_LNZ_Effects_free4all.pdf", width = 20, height = 12)


pop.labs <- c("py", "gx","gxpy")
names(pop.labs) <- c("ParC", "GyrA", "R")

p <- df_plot %>% 
  filter(model == "LNZ") %>% 
  ggplot( aes(x = Population))+
  geom_hline(yintercept = 0, alpha = 0.2)+
  geom_point( aes(y = R_Dev*100/n,  fill = KG/ref_KG, shape = CE),
              position = position_dodge(width = 0.7), size = 5) +
  facet_grid(Sim_scen~B_pop, labeller = labeller(B_pop = pop.labs), scales = "free_x") + 
  scale_fill_gradient2(low = "navy", mid = "white", high = "firebrick3", midpoint = 1 )+
  coord_cartesian(ylim = c(-10, 100))+
  ggtitle("LNZ")+
  labs(shape = "Collateral effect",
       y = " Probability of resistance (%)",
       fill = "Relative\ngrowth rate",
       x = "Strain")+
  scale_shape_manual(values = c(24, 21, 25), drop = F)+
  theme_CS()   +
  theme(strip.text.x = element_text(colour = "white", face = "bold"),
        axis.text.x = element_text(angle = 75, hjust = 1),

        legend.key.width = unit(x = 15, units = "mm"))

#color facet strips
g <- ggplot_gtable(ggplot_build(p))
stripr <- which(grepl('strip-t', g$layout$name))
fills <- col_order[c(2,1,3)]
k <- 1
for (i in stripr) {
  j <- which(grepl('rect', g$grobs[[i]]$grobs[[1]]$childrenOrder))
  g$grobs[[i]]$grobs[[1]]$children[[j]]$gp$fill <- fills[k]
  k <- k+1
}

grid::grid.draw(g)
dev.off()




pdf("Results/PNAS/resubmission_figures/Final/FIGS8A_ERY_Effects_free4all.pdf", width = 20, height = 12)

pop.labs <- c("py", "gx","gxpy")
names(pop.labs) <- c("ParC", "GyrA", "R")

p <- df_plot %>% 
  filter(model == "ERY") %>% 
  ggplot( aes(x = Population))+
  geom_hline(yintercept = 0, alpha = 0.2)+
  geom_point( aes(y = R_Dev*100/n,  fill = KG/ref_KG, shape = CE),
              position = position_dodge(width = 0.7), size = 5) +
  facet_grid(Sim_scen~B_pop, labeller = labeller(B_pop = pop.labs), scales = "free_x") + 
  scale_fill_gradient2(low = "navy", mid = "white", high = "firebrick3", midpoint = 1 )+
  coord_cartesian(ylim = c(-10, 100))+
  ggtitle("ERY")+
  labs(shape = "Collateral effect",
       y = " Probability of resistance (%)",
       fill = "Relative\ngrowth rate",
       x = "Strain")+
  scale_shape_manual(values = c(24, 21, 25), drop = F)+
  theme_CS()   +
  theme(strip.text.x = element_text(colour = "white", face = "bold"),
        axis.text.x = element_text(angle = 75, hjust = 1),
        
        legend.key.width = unit(x = 15, units = "mm"))


g <- ggplot_gtable(ggplot_build(p))
stripr <- which(grepl('strip-t', g$layout$name))
fills <- col_order[c(2,1,3)]
k <- 1
for (i in stripr) {
  j <- which(grepl('rect', g$grobs[[i]]$grobs[[1]]$childrenOrder))
  g$grobs[[i]]$grobs[[1]]$children[[j]]$gp$fill <- fills[k]
  k <- k+1
}

grid::grid.draw(g)
dev.off()





pdf("Results/PNAS/resubmission_figures/Final/FIGS8B_PEN_Effects_free4all.pdf", width = 20, height = 12)

pop.labs <- c("py", "gx","gxpy")
names(pop.labs) <- c("ParC", "GyrA", "R")

p <- df_plot %>% 
  filter(model == "PEN") %>% 
  ggplot( aes(x = Population))+
  geom_hline(yintercept = 0, alpha = 0.2)+
  geom_point( aes(y = R_Dev*100/n,  fill = KG/ref_KG, shape = CE),
              position = position_dodge(width = 0.7), size = 5) +
  facet_grid(Sim_scen~B_pop, labeller = labeller(B_pop = pop.labs), scales = "free_x") + 
  scale_fill_gradient2(low = "navy", mid = "white", high = "firebrick3", midpoint = 1 )+
  coord_cartesian(ylim = c(-10, 100))+
  ggtitle("PEN")+
  labs(shape = "Collateral effect",
       y = " Probability of resistance (%)",
       fill = "Relative\ngrowth rate",
       x = "Strain")+
  scale_shape_manual(values = c(24, 21, 25), drop = F)+
  theme_CS()   +
  theme(strip.text.x = element_text(colour = "white", face = "bold"),
        axis.text.x = element_text(angle = 75, hjust = 1),
        
        legend.key.width = unit(x = 15, units = "mm"))



g <- ggplot_gtable(ggplot_build(p))
stripr <- which(grepl('strip-t', g$layout$name))
fills <- col_order[c(2,1,3)]
k <- 1
for (i in stripr) {
  j <- which(grepl('rect', g$grobs[[i]]$grobs[[1]]$childrenOrder))
  g$grobs[[i]]$grobs[[1]]$children[[j]]$gp$fill <- fills[k]
  k <- k+1
}

grid::grid.draw(g)
dev.off()
