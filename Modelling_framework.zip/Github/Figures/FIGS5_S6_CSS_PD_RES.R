#################################
# #### CS PKPD model framework ##
## S.pneumoniae D39 adaptation ##  
####      FQ resistant         ##
##  Combination treatment for  ##    
##    CIP + ERY. LNZ or PEN    ##
##      With interaction       ##
#         Processing script    ##
##     Scenario 2: css         ##
##     bacterial dynamics      ##
##    Written by Linda Aulin   ##
#################################



########
library(dplyr)
library(tidyr)
library(forcats)
library(ggplot2)

memory.limit() 
memory.limit(24000)
n = 500
#source("Scripts/CS_model/Figures/Plot_script_v7.R")

ET <- read.csv("Data/EXP_DAT/ET.csv", sep = ";")
#source("Scripts/CS_model/Figures/Plot_script_v7.R")

Scenario_n <- 2

dat_path <- paste0("Results/PNAS/Simulations/Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i)) %>% 
  distinct(time, Population, model, ID,  CSS_CIP, CSS_AB, MT, .keep_all = T)
  df_ii$ID <- as.numeric(strsplit(df_i, split = "_")[[1]][4])
  
  df_list[[i]] <- df_ii
  
}




df_raw <- bind_rows(df_list)  




df_2<- df_raw %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n,
         model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model)) #%>% 



Scenario_n <- 14

dat_path <- paste0("Results/PNAS/Simulations/Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i)) %>% 
    distinct(time, Population, model,  ID, CSS_CIP, CSS_AB, MT, .keep_all = T)
  df_ii$ID <- as.numeric(strsplit(df_i, split = "_")[[1]][4])
  
  df_list[[i]] <- df_ii
  
}



df_raw <- bind_rows(df_list)  


rm(df_list)
rm(df_ii)




df<- df_raw %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n,
         model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model)) %>% 
  bind_rows(df_2) %>% 
  left_join(ET)

rm(df_raw)

# 
CB_col <- c("black", "#1E88E5", "#FFC107",  "#BE1908")
col_order = c( "#1E88E5", "#FFC107",  "#BE1908")
col_A <- "#72bfc5"
col_B <- "#6f30a0"



df_plot<- df %>% 
    distinct(time, Population, model, Scenario, ID, CSS_CIP, CSS_AB, ET, .keep_all = T)

    models <- unique(df_plot$model)
    plots <- list()
  pdf("Results/PNAS/resubmission_figures/Final/FIGS5_Css_PD.pdf", width = 19, height = 27)
    for(i in 1:length(models)){
      
    M <- models[i]  
    plot_PD<- df_plot %>% 
      filter(model == M) %>% 
      ggplot(aes(x = time))+
      geom_hline(mapping = aes(yintercept = S0, linetype = "Resistance cut-off"), size = 0.7)+
      geom_ribbon(aes(ymin = CFU_05,  ymax = CFU_95, fill = Population, 
                      group=  Population), alpha = 0.3)+
      geom_line( aes(y = CFU_MEDIAN,  col = Population, group= Population))+
      facet_grid( paste0(M, ":", CSS_AB, "xMIC")+
                    paste0("CIP:", CSS_CIP, "xMIC")
                   ~paste("ET: ", ET)+ Strain_R ) + 
      scale_color_manual(values = c("black", col_order),
                         labels = c("WT", "py", "gx","gxpy"))+
      scale_fill_manual(values = c("black", col_order),
                        labels = c("WT", "py", "gx","gxpy"))+
      scale_linetype_manual(values = "dashed")+
      scale_y_log10(limits = c(0.01,10^10))+
      labs(x = "Time (hours)",
           y = "Bacteria (CFU/mL)",
           linetype = "",
           fill = "Subpopulation",
           col = "Subpopulation")+
      theme_bw()+
      theme(text = element_text(size = 10))
    
    print( plot_PD)
      
      
    }
    dev.off()
    
    
    
    df_plot_2 <- df_plot %>% 
      mutate(M = ifelse(Population == "GyrA", gsub("GyrA:", "g", Strain_GyrA), 
                        ifelse(Population == "ParC", gsub("ParC:", "p", Strain_ParC),
                               ifelse(Population == "R", paste0(gsub("GyrA:", "g", Strain_GyrA), gsub("ParC:", "p", Strain_ParC)), "WT"))))  %>% 
      filter(time == 336) %>% 
      distinct(Population, ID, Scenario, model, Strain_R, CSS_CIP, CSS_AB, .keep_all = T)%>%
      
      mutate( n = 500) %>% 
      ungroup() %>% 
      
      mutate(p = R_Dev/n) %>% 
      mutate(
        CI = 1.96*sqrt(p*(1-p)/n),
        SE = sqrt(p*(1-p)/n), 
        M_0 = ifelse(Population == "S", 1,
                     ifelse(Population == "GyrA", 2,
                            ifelse(Population == "ParC", 3, 4)))) %>%
      arrange(desc(M_0)) %>% 
      group_by(M_0, M) %>% 
      mutate(M_o = cur_group_id()) %>% 
      
      mutate(M = fct_reorder(M, M_o),
             CE_ParC = ifelse(model == "CIP", "",
                              ifelse(log2(MIC_AB_ParC/MIC_AB_S) > 0, "(CR)",
                              ifelse(log2(MIC_AB_ParC/MIC_AB_S) < 0, "(CS)", "(No CE)"))),
             CE_GyrA = ifelse(model == "CIP", "",
                              ifelse(log2(MIC_AB_GyrA/MIC_AB_S) > 0, "(CR)",
                              ifelse(log2(MIC_AB_GyrA/MIC_AB_S) < 0, "(CS)", "(No CE)"))),
             CE_R    = ifelse(model == "CIP", "",
                              ifelse(log2(MIC_AB_R/MIC_AB_S) > 0, "(CR)",
                              ifelse(log2(MIC_AB_R/MIC_AB_S) < 0, "(CS)", "(No CE)"))))
    
    
    pdf("Results/PNAS/resubmission_figures/Final/FIGS6_Css_res.pdf", width = 19, height = 27)
    for(i in 1:length(models)){
      
      Mod <- models[i] 
    pop.labs <- c("py", "gx","gxpy")
    names(pop.labs) <- c("ParC", "GyrA", "R")

        plot_res_point<- df_plot_2%>% 
          filter(model == Mod & time == 336) %>%
          ggplot(              aes( x = paste0(Mod, ":", CSS_AB, "xMIC"), 
                                    y = R_Dev*100/n,
                                    fill = Population))  +
          
          geom_col(aes(group = Population),
                   position = "dodge", width = 0.6)+
          
          geom_linerange(aes(ymin = p*100 - SE*100,
                             ymax = p*100 +SE*100, 
                             group = Population),
                         col = "black", position = position_dodge(width = 0.6))+
          facet_grid( paste("ET:", ET)+
                        paste(Strain_R,  CE_R)+
                        paste(Strain_ParC,  CE_ParC) +
                        paste(Strain_GyrA,  CE_GyrA) ~ reorder(paste0("CIP:", CSS_CIP, "xMIC"), CSS_CIP)) +
          
          labs(x = "Concentration of AB",
               y = "Probability of resistance (%)",
               fill = "Subpopulation")+
          scale_fill_manual(values = c("black", col_order),
                            labels = c("WT", "py", "gx","gxpy"))+
          ggtitle(Mod)+
            theme_bw()+
          theme(text = element_text(size = 20),
                axis.text.x = element_text(angle = 90,  vjust = 0.2, hjust = 0.95))
    print(plot_res_point)
    
    }
dev.off()    


