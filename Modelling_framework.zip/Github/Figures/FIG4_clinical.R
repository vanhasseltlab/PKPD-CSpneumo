#################################
# #### CS PKPD model framework ##
## S.pneumoniae D39 adaptation ##  
####      FQ resistant         ##
##  Combination treatment for  ##    
##    CIP + ERY. LNZ or PEN    ##
##      With interaction       ##
#       Processing script      ##
## Scenario 1: clinical dosing ##
##           FIG. 4            ##
##    Written by Linda Aulin   ##
#################################

#Load libraries 
library(dplyr)
library(tidyr)
library(forcats)
library(ggplot2)

memory.limit() 
memory.limit(24000)
#load evolutionary trajectories
ET <- read.csv("Data/EXP_DAT/ET.csv", sep = ";")

# Set scenario number and load data
Scenario_n <-1

dat_path <- paste0("Results/PNAS/Simulations/Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i))
  df_ii$ID <- as.numeric(strsplit(df_i, split = "_")[[1]][4])
  
  df_list[[i]] <- df_ii
  
}




df_raw <- bind_rows(df_list)  

  
#post processing 
df<- df_raw %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n,
         model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model)) %>% 
  left_join(ET) %>% 
  ungroup() %>% 
  mutate(M = ifelse(Population == "GyrA", gsub("GyrA:", "g", Strain_GyrA), 
                    ifelse(Population == "ParC", gsub("ParC:", "p", Strain_ParC),
                           ifelse(Population == "R", paste0(gsub("GyrA:", "g", Strain_GyrA),gsub("ParC:", "p", Strain_ParC)), "WT"))))  


# Colour schemes 
CB_col <- c("black", "#1E88E5", "#FFC107",  "#BE1908")
col_order = c( "#1E88E5", "#FFC107",  "#BE1908")
col_A <- "#72bfc5"
col_B <- "#6f30a0"



#####
# Subset data for plotting 
  df_plot<- df %>% 
    distinct(time, Population, model, Scenario, ID, .keep_all = T)
  
  # Plot 4A
  plot_6a<- df_plot %>% 
    filter(model == "CIP") %>% 
    ggplot(aes(x = time))+
    geom_hline(mapping = aes(yintercept = S0, linetype = "Resistance cut-off"), size = 0.7)+
    geom_ribbon(aes(ymin = CFU_05,  ymax = CFU_95, fill = Population, 
                    group=  Population), alpha = 0.3)+
    geom_line( aes(y = CFU_MEDIAN,  col = Population, group= Population))+
    facet_grid(~paste("ET: ", ET)) + 
    scale_color_manual(values = c("black", col_order),
                       labels = c("WT", "py", "gx","gxpy"))+
    scale_fill_manual(values = c("black", col_order),
                       labels = c("WT", "py", "gx","gxpy"))+
    scale_linetype_manual(values = "dashed")+
    scale_y_log10(limits = c(0.01,10^10))+
    labs(x = "Time (hours)",
         y = "Bacteria (CFU/mL)",
         linetype = "",
         fill = "Subpopulation",
         col = "Subpopulation")+
    theme_bw()+
    theme(text = element_text(size = 20))
  
  
  
    df_plot_2 <- df %>% 
      filter(time == 336) %>% 
      distinct(Population, ID, Scenario, model, Strain_R, .keep_all = T)%>%
      
      mutate( n = 500) %>% # number of simulation realizations
      ungroup() %>% 
      
      mutate(p = R_Dev/n) %>% # probability of resistance
      mutate(
        CI = 1.96*sqrt(p*(1-p)/n),
        SE = sqrt(p*(1-p)/n), 
      M_0 = ifelse(Population == "S", 1,
                   ifelse(Population == "GyrA", 2,
                          ifelse(Population == "ParC", 3, 4)))) %>%
    arrange(desc(M_0)) %>% 
      group_by(M_0, M) %>% 
      mutate(M_o = cur_group_id()) %>% 
 
      mutate(M = fct_reorder(M, M_o))
    
    #Plot 4B
    
    plot_6b<- df_plot_2 %>% 
      filter(model == "CIP") %>% 
      ggplot(              aes( x = M, 
                           y = R_Dev*100/n,
                           fill = Population))  +
     
      geom_col(aes(group = Population),
                position = "dodge", width = 0.6)+
      
      geom_linerange(aes(ymin = p*100 - SE*100,
                         ymax = p*100 +SE*100, 
                         group = Population),
                     col = "black", position = position_dodge(width = 0.6))+
      facet_grid(~paste("ET:", ET), scales = "free_x")+

      coord_cartesian(ylim =  c(0, 100))+
      
      labs(x = "Subpopulation",
           y = "Probability of resistance (%)",
           fill = "Subpopulation")+
      scale_fill_manual(values = c("black", col_order),
                        labels = c("WT", "py", "gx","gxpy"))+
      theme_bw()+
      theme(text = element_text(size = 20),
            axis.text.x = element_text(angle = 90, colour = c("black", col_order[c(2,1,3)]), vjust = 0.2, hjust = 0.95))
  

    cip.labs <- c("CIP", "CIP + ERY", "CIP + LNZ", "CIP + PEN")
    names(cip.labs) <- c("CIP", "ERY", "LNZ", "PEN")
    
    #Figure 4C
    plot_6C<- df_plot_2 %>% 
      ggplot(              aes( x = paste("ET:", ET), 
                                y = R_Dev*100/n,
                                fill = Population))  +
      
      geom_col(aes(group = Population),
               position = "dodge", width = 0.6)+
      
      geom_linerange(aes(ymin = p*100 - SE*100,
                         ymax = p*100 +SE*100, 
                         group = Population),
                     col = "black", position = position_dodge(width = 0.6))+
      facet_grid(model~., labeller = labeller(model = cip.labs))+
      coord_cartesian(ylim =  c(0, 100))+
      
      labs(x = "Evolutionary trajectory",
           y = "Probability of resistance (%)",
           fill = "Subpopulation")+
      scale_fill_manual(values = c("black", col_order),
                        labels = c("WT", "py", "gx","gxpy"))+
 
      theme_bw()+
      theme(text = element_text(size = 20),
            axis.text.x = element_text(angle = 90,  vjust = 0.2, hjust = 0.95))
  
    
    pdf("Results/PNAS/resubmission_figures/Final/FIG4_clinical.pdf", height = 10, width = 28)
    ((plot_6a / plot_6b + plot_layout(heights = c(1,0.4), guides = 'auto')) | plot_6C) + plot_layout( widths = c( 1, 0.4)) + 
      plot_annotation(tag_levels = "A")
    dev.off()
