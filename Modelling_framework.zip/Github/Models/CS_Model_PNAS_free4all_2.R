#################################
# #### CS PKPD model framework ##
## S.pneumoniae D39 adaptation ##  
####      FQ resistant         ##
##  Combination treatment for  ##    
##    CIP + ERY. LNZ or PEN    ##
##      With interaction       ##
#         Model script         ##
##    Written by Linda Aulin   ##
#################################



CS_model <- function( p_Bmax = 10, OUT = F, sim_ID = "", DRUG , CSS_CIP = 1, CSS_AB = 1, DOSE_scale = "CL", p_KG_S, p_KG_pS79Y, p_KG_pS79F, p_KG_pD83Y,p_KG_pD83N, p_KG_gS81Y, p_KG_gS81F, p_KG_gE85K, p_KG_gE85G, p_KG_gS81YpS79Y, p_KG_gS81YpS79F, p_KG_gS81FpS79Y, p_KG_gS81FpS79F, p_KG_gS81FpD83Y, p_KG_gS81FpD83N, p_KG_gE85KpS79Y, p_KG_gE85GpS79F, p_GMIN_CIP,  p_HILL_CIP,  p_GMIN_AB,  p_HILL_AB,  p_INTER,  p_MIC_CIP_S,  p_MIC_CIP_pS79Y,  p_MIC_CIP_pS79F, p_MIC_CIP_pD83Y, p_MIC_CIP_pD83N, p_MIC_CIP_gS81Y,  p_MIC_CIP_gS81F, p_MIC_CIP_gE85K, p_MIC_CIP_gE85G, p_MIC_CIP_gS81YpS79Y,  p_MIC_CIP_gS81YpS79F,  p_MIC_CIP_gS81FpS79Y,  p_MIC_CIP_gS81FpS79F,  p_MIC_CIP_gS81FpD83Y,  p_MIC_CIP_gS81FpD83N,  p_MIC_CIP_gE85KpS79Y,  p_MIC_CIP_gE85GpS79F,  p_MIC_AB_S,  p_MIC_AB_pS79Y,  p_MIC_AB_pS79F,  p_MIC_AB_pD83Y,  p_MIC_AB_pD83N,  p_MIC_AB_gS81Y, p_MIC_AB_gS81F, p_MIC_AB_gE85K, p_MIC_AB_gE85G, p_MIC_AB_gS81YpS79Y, p_MIC_AB_gS81YpS79F, p_MIC_AB_gS81FpS79Y, p_MIC_AB_gS81FpS79F, p_MIC_AB_gS81FpD83Y, p_MIC_AB_gS81FpD83N, p_MIC_AB_gE85KpS79Y, p_MIC_AB_gE85GpS79F, p_V  = 100, p_ke = 0, p_u  = 1.4*10^-8, eS0  = 9, n = 10, DT = 1, ST = 24) {
  
  start_t <- Sys.time()
  
  is.wholenumber <- function(x, tol = .Machine$double.eps^0.5)  abs(x - round(x)) < tol  # need to check for whole numbers later
  
  
  ##############
  ## PK Model ##
  ##############
  

  #Covariates:
  BW   <- 70 #KG
  CrCL <- 75
  
  TAU  <- 12 #h
  T_start <- 0 #h
  
  
  ##################################
  ########## CIP parameters ########
  ##################################
  pCIP_CL <- 8+0.21*CrCL
  SDCIP_CL <- 0.186   #CV
  
  # CIP_CL <- pCIP_CL*exp(qnorm(0, SDCIP_CL, p = 0.95))
  CIP_CL  <- pCIP_CL
  
  pCIP_V  <-22.7+0.86*BW
  SDCIP_V <- 0.14     
  
  #CIP_V <- pCIP_V*qnorm(0 ,SDCIP_V , p = 0.95)
  CIP_V <- pCIP_V
  
  CIP_ke <- CIP_CL/CIP_V 
  CIP_fu <- 0.7 #Zhanel et al (review)
  
  
  
  MIC_CIP_S = p_MIC_CIP_S
 
  if(DOSE_scale == "CL" ){
   
     DOSE_CIP <- 500
    
  }else{ DOSE_CIP = CSS_CIP*MIC_CIP_S*CIP_CL*TAU/CIP_fu }


  
  PK_inits_1cmt <- c(A_CIP = 0, A_AB = 0);
  
  #CIP model based on Cios et al. 1-comp CIP elderly patients
  
  if(DRUG == "CIP") {
    
    #CIP_V <- pCIP_V*qnorm(0 ,SDCIP_V , p = 0.95)
    AB_V <- pCIP_V
    
    AB_ke <- CIP_CL/CIP_V 
    AB_fu <- 0.7 #Zhanel et al (review)
    
    
    PK_mod_CIP<- RxODE({
      
      
      d/dt(A_CIP) = -CIP_ke*A_CIP
      d/dt(A_AB) =  0
      
      CIP = A_CIP/CIP_V*CIP_fu
      AB  = A_AB
      
    });
    
    PK_theta_CIP <- c(CIP_V = CIP_V, 
                      CIP_ke= CIP_ke,
                      CIP_fu = CIP_fu ) #MIC if sensitive WT (S)) # PK elimination rate constant)
    
    ev_PK_CIP <- eventTable(amount.units="mg", time.units="hours") %>%
      add.dosing(start.time = T_start, dosing.to = 1, dose=DOSE_CIP, nbr.doses = 28,  dosing.interval=TAU) %>%
      add.sampling(seq(0,ST+T_start,DT))  %>%
      as.tbl()
    
    
    
    PK_sim    <- as.data.frame(PK_mod_CIP$run(PK_theta_CIP ,ev_PK_CIP ,     PK_inits_1cmt));
    
  }
  
  if(DRUG == "ERY"){
    
    ################################################
    ##### ERY , no IIV available ###################
    ##ERY model based on Nielsen et al 2-comp model#
    ################################################
    
    #parameters
    AB_V  <- 34.9 #L
    AB_CL <-22.8
    AB_V2 <- 20.7
    AB_Q  <- 16.9
    AB_fu <- 0.16
    
    AB_ke  = AB_CL/AB_V
    AB_k12 = AB_Q/AB_V
    AB_k21 = AB_Q/AB_V2
    
    
    MIC_AB_S  = p_MIC_AB_S  #MIC if sensitive WT (S)
    
    if(DOSE_scale == "CL" ){
      
      DOSE_ERY = 600
      
    }else{  DOSE_ERY = CSS_AB*MIC_AB_S*AB_CL*TAU/AB_fu }
    
    

   
    
    PK_mod_ERY<- RxODE({
      
      
      d/dt(A_CIP) =  -CIP_ke*A_CIP
      d/dt(A_AB) =   -AB_ke*A_AB   - AB_k12*A_AB + AB_k21*A2_AB
      d/dt(A2_AB) =   AB_k12*A_AB - AB_k21*A2_AB
      
      CIP = A_CIP/CIP_V*CIP_fu
      AB  = A_AB/AB_V*AB_fu
      
    });
    
    
    
    
    PK_theta_ERY <- c(CIP_V  = CIP_V, 
                      CIP_ke = CIP_ke,
                      CIP_fu = CIP_fu,
                      AB_V   = AB_V,
                      AB_V2  = AB_V2,
                      AB_fu  = AB_fu,
                      AB_ke  = AB_ke ,
                      AB_k12 = AB_k12,
                      AB_k21 = AB_k21#,
                      
                      #MIC_CIP_S = p_MIC_CIP_S, #CIP MIC if resistant  (R)  (gryA + parC)
                      #MIC_AB_S  = p_MIC_AB_S  #MIC if sensitive WT (S)
    ) 
    
    
    ev_PK_ERY <- eventTable(amount.units="mg", time.units="hours") %>%
      add.dosing(start.time = T_start, dosing.to = 1, dose=DOSE_CIP, nbr.doses = 28,  dosing.interval=TAU) %>%
      add.dosing(start.time = T_start, dosing.to = 2, dose=DOSE_ERY, nbr.doses = 28,  dosing.interval=TAU) %>%
      add.sampling(seq(0,ST+T_start,DT))  %>%
      as.tbl()
    
    PK_inits_2cmt <- c(A_CIP = 0, A1_AB = 0,  A2_AB = 0);
    
    
    PK_sim    <- as.data.frame(PK_mod_ERY$run(PK_theta_ERY ,ev_PK_ERY ,     PK_inits_2cmt));
    
  }
  
  if(DRUG == "PEN"){
    
    #########################################
    #### PEN parameters ####################
    ########################################
    
    
    ### 1-CMT model by Komatsu et al
    pPEN_CL <- 0.21*CrCL
    SDPEN_CL <- 0.0835
    
    AB_CL <- pPEN_CL*exp(qnorm(0 , SDPEN_CL , p = 0.95))
    
    
    pPEN_V  <- 28.9
    SDPEN_V <- 0.104
    
    AB_V <- pPEN_V*exp(qnorm(0 , SDPEN_V , p = 0.95))
    
    
    AB_fu <- 0.40
    
    AB_ke  = AB_CL/AB_V
    
    
    MIC_AB_S  = p_MIC_AB_S  #MIC if sensitive WT (S)
    
    if(DOSE_scale == "CL" ){
      
      DOSE_PEN = 3000
      
    }else{  DOSE_PEN = CSS_AB*MIC_AB_S*AB_CL*TAU/AB_fu }

    
    
    
    
    #PEN model based 1-CMT model by Komatsu et al
    
    PK_mod_PEN<- RxODE({
      
      
      d/dt(A_CIP) =  -CIP_ke*A_CIP
      
      d/dt(A_AB) =  -AB_ke*A_AB
      
      CIP = A_CIP/CIP_V*CIP_fu
      AB  = A_AB/AB_V*AB_fu
      
      
    });
    
    
    PK_theta_PEN <- c(CIP_V  = CIP_V, 
                      CIP_ke = CIP_ke,
                      CIP_fu = CIP_fu,
                      
                      AB_V   = AB_V,
                      AB_fu  = AB_fu,
                      AB_ke  = AB_ke 
    )
    
    ev_PK_PEN <- eventTable(amount.units="mg", time.units="hours") %>%
      add.dosing(start.time = T_start, dosing.to = 1, dose=DOSE_CIP, nbr.doses = 28,  dosing.interval=TAU) %>%
      add.dosing(start.time = T_start, dosing.to = 2, dose=DOSE_PEN, nbr.doses = 28,  dosing.interval=TAU) %>%
      add.sampling(seq(0,ST+T_start,DT))  %>%
      as.tbl()
    
    PK_sim    <- as.data.frame(PK_mod_PEN$run(PK_theta_PEN ,ev_PK_PEN,    PK_inits_1cmt));
    
  }
  
  if(DRUG == "LNZ"){
    
    pLNZ_CL  <- 2.85*(CrCL/60.9)^0.618
    SDLNZ_CL <- 0.352 #CV
    
    AB_CL <- pLNZ_CL*exp(qnorm(0 , SDLNZ_CL , p = 0.95))
    #LNZ_CL <- pLNZ_CL
    
    pLNZ_V  <- 33.6*(BW/57.9)
    SDLNZ_V <- 0.308
    AB_V   <- pLNZ_V*exp(qnorm(0, SDLNZ_V, p = 0.95)) 
    #LNZ_V   <- pLNZ_V
    
    AB_fu <- 0.815  #Kratzer et al
    
    AB_ke = AB_CL/AB_V
    
    MIC_AB_S  = p_MIC_AB_S  #MIC if sensitive WT (S)
    #DOSE_LNZ = MIC_AB_S*LNZ_V*1
    #DOSE_LNZ= MIC_AB_S*AB_CL*TAU/AB_fu
    if(DOSE_scale == "CL" ){
      
      DOSE_LNZ = 600
      
    }else{  DOSE_LNZ = CSS_AB*MIC_AB_S*AB_CL*TAU/AB_fu }
    
    
    
    #LNZ model based on Sasaki et al 1-comp model
    PK_mod_LNZ<- RxODE({
      
      
      d/dt(A_CIP) = -CIP_ke*A_CIP
      d/dt(A_AB) =  -AB_ke*A_AB
      
      CIP = A_CIP/CIP_V*CIP_fu
      AB  = A_AB/AB_V*AB_fu
      
    });
    
    
    PK_theta_LNZ<- c( CIP_V   = CIP_V, 
                      CIP_ke = CIP_ke,
                      CIP_fu = CIP_fu,
                      AB_V   = AB_V, 
                      AB_ke  = AB_ke,
                      AB_fu  = AB_fu
    ) 
    
    
    ev_PK_LNZ <- eventTable(amount.units="mg", time.units="hours") %>%
      add.dosing(start.time = T_start, dosing.to = 1, dose=DOSE_CIP, nbr.doses = 28,  dosing.interval=TAU) %>%
      add.dosing(start.time = T_start, dosing.to = 2, dose=DOSE_LNZ, nbr.doses = 28,  dosing.interval=TAU) %>%
      add.sampling(seq(0,ST+T_start,DT))  %>%
      as.tbl()
    
    
    PK_sim    <- as.data.frame(PK_mod_LNZ$run(PK_theta_LNZ ,ev_PK_LNZ ,  PK_inits_1cmt));
    
    
  }
  
  print("PK OK")
  
  PK_model_list <- list(PK_sim)
  
  dose_reg <- c(DRUG)
  
  #print(names(PK_model_list))
  
  
  
  
  
  ##############
  ## PD Model ##
  ##############
  
  
  ##For 1COMP models
  
  if(DRUG != "ERY"){
    
    
    #ODE
    CS_mod<- RxODE({
      
      
      
      
      
      ####### PK######
      
      d/dt(A_CIP)  = -CIP_ke*A_CIP
      d/dt(A_AB)   = -AB_ke*A_AB
      
      #AB conc
      CIP = A_CIP/CIP_V*CIP_fu
      AB  =  A_AB/AB_V*AB_fu
      
      
      
      KG_S = KG_D39   #Yu et al
      
      
      KG_pS79Y = KG_D39*abs_KG_pS79Y/abs_KG_S
      KG_pS79F = KG_D39*abs_KG_pS79F/abs_KG_S
      KG_pD83Y = KG_D39*abs_KG_pD83Y/abs_KG_S
      KG_pD83N = KG_D39*abs_KG_pD83N/abs_KG_S
      
      KG_gS81Y = KG_D39*abs_KG_gS81Y/abs_KG_S
      KG_gS81F = KG_D39*abs_KG_gS81F/abs_KG_S
      KG_gE85K = KG_D39*abs_KG_gE85K/abs_KG_S
      KG_gE85G = KG_D39*abs_KG_gE85G/abs_KG_S
      
      KG_gS81YpS79Y = KG_D39*abs_KG_gS81YpS79Y/abs_KG_S
      KG_gS81YpS79F = KG_D39*abs_KG_gS81YpS79F/abs_KG_S
      KG_gS81FpS79Y = KG_D39*abs_KG_gS81FpS79Y/abs_KG_S
      KG_gS81FpS79F = KG_D39*abs_KG_gS81FpS79F/abs_KG_S
      KG_gS81FpD83Y = KG_D39*abs_KG_gS81FpD83Y/abs_KG_S
      KG_gS81FpD83N = KG_D39*abs_KG_gS81FpD83N/abs_KG_S
      KG_gE85KpS79Y = KG_D39*abs_KG_gE85KpS79Y/abs_KG_S
      KG_gE85GpS79F = KG_D39*abs_KG_gE85GpS79F/abs_KG_S
      
      ###PD#####
      
      #sum all bacaterial popualions     
      B_all = S + 
        pS79Y + pS79F + pD83Y + pD83N +
        gS81Y + gS81F + gE85K + gE85G +
        gS81YpS79Y + gS81YpS79F + gS81FpS79Y +
        gS81FpS79F + gS81FpD83Y +  gS81FpD83N + gE85KpS79Y + gE85GpS79F
      
      
      ######Sensitive wild type ####
      
      E_AB_S  = (1 - Gmin_AB/KG_S)*(AB/MIC_AB_S)^HILL_AB/((AB/MIC_AB_S)^HILL_AB - (Gmin_AB/KG_S))
      E_CIP_S = (1 - Gmin_CIP/KG_S)*(CIP/MIC_CIP_S)^HILL_CIP/((CIP/MIC_CIP_S)^HILL_CIP - (Gmin_CIP/KG_S))
      E_INTER_S = E_AB_S/(-(Gmin_AB/KG_S -1))*E_CIP_S/(-(Gmin_CIP/KG_S -1))*INTER*((-(Gmin_AB/KG_S -1))+(-(Gmin_CIP/KG_S -1)))
      
      d/dt(S) = S*(1-((B_all)/10^Bmax))*KG_S*(1 - (E_AB_S + E_CIP_S + E_INTER_S )) -
        
        GR_S_pS79Y/V -
        GR_S_pS79F/V - 
        GR_S_pD83Y/V - 
        GR_S_pD83N/V - 
        
        GR_S_gS81Y/V -
        GR_S_gS81F/V -
        GR_S_gE85K/V - 
        GR_S_gE85G/V -
        
        ke*S
      
      
      ###### Single resistant mutants with mutation in ParC ####
      #pS79Y
      E_AB_pS79Y  = (1 - Gmin_AB/KG_pS79Y)*(AB/MIC_AB_pS79Y)^HILL_AB/((AB/MIC_AB_pS79Y)^HILL_AB - (Gmin_AB/KG_pS79Y))
      E_CIP_pS79Y = (1 - Gmin_CIP/KG_pS79Y)*(CIP/(MIC_CIP_pS79Y))^HILL_CIP/((CIP/(MIC_CIP_pS79Y))^HILL_CIP - (Gmin_CIP/KG_pS79Y))
      E_INTER_pS79Y = E_AB_pS79Y/(-(Gmin_AB/KG_pS79Y -1))*E_CIP_pS79Y/(-(Gmin_CIP/KG_pS79Y -1))*INTER*((-(Gmin_AB/KG_pS79Y -1))+(-(Gmin_CIP/KG_pS79Y -1)))
      
      d/dt(pS79Y) = pS79Y*(1-((B_all)/10^Bmax))*KG_pS79Y*(1- (E_AB_pS79Y + E_CIP_pS79Y + E_INTER_pS79Y)) +
        
        
        GR_S_pS79Y/V - 
        GR_pS79Y_gS81YpS79Y/V -
        GR_pS79Y_gS81FpS79Y/V -
        GR_pS79Y_gE85KpS79Y/V -
        ke*pS79Y
      
      
      #pS79F
      E_AB_pS79F  = (1 - Gmin_AB/KG_pS79F)*(AB/MIC_AB_pS79F)^HILL_AB/((AB/MIC_AB_pS79F)^HILL_AB - (Gmin_AB/KG_pS79F))
      E_CIP_pS79F = (1 - Gmin_CIP/KG_pS79F)*(CIP/(MIC_CIP_pS79F))^HILL_CIP/((CIP/(MIC_CIP_pS79F))^HILL_CIP - (Gmin_CIP/KG_pS79F))
      E_INTER_pS79F = E_AB_pS79F/(-(Gmin_AB/KG_pS79F -1))*E_CIP_pS79F/(-(Gmin_CIP/KG_pS79F -1))*INTER*((-(Gmin_AB/KG_pS79F -1))+(-(Gmin_CIP/KG_pS79F -1)))
      
      d/dt(pS79F) = pS79F*(1-((B_all)/10^Bmax))*KG_pS79F*(1- (E_AB_pS79F + E_CIP_pS79F + E_INTER_pS79F)) +
        
        
        GR_S_pS79F/V - 
        GR_pS79F_gS81YpS79F/V -
        GR_pS79F_gS81FpS79F/V -
        GR_pS79F_gE85GpS79F/V -
        ke*pS79F
      
      #pD83Y
      E_AB_pD83Y  = (1 - Gmin_AB/KG_pD83Y)*(AB/MIC_AB_pD83Y)^HILL_AB/((AB/MIC_AB_pD83Y)^HILL_AB - (Gmin_AB/KG_pD83Y))
      E_CIP_pD83Y = (1 - Gmin_CIP/KG_pD83Y)*(CIP/(MIC_CIP_pD83Y))^HILL_CIP/((CIP/(MIC_CIP_pD83Y))^HILL_CIP - (Gmin_CIP/KG_pD83Y))
      E_INTER_pD83Y = E_AB_pD83Y/(-(Gmin_AB/KG_pD83Y -1))*E_CIP_pD83Y/(-(Gmin_CIP/KG_pD83Y -1))*INTER*((-(Gmin_AB/KG_pD83Y -1))+(-(Gmin_CIP/KG_pD83Y -1)))
      
      d/dt(pD83Y) = pD83Y*(1-((B_all)/10^Bmax))*KG_pD83Y*(1- (E_AB_pD83Y + E_CIP_pD83Y + E_INTER_pD83Y)) +
        
        
        GR_S_pD83Y/V - 
        GR_pD83Y_gS81FpD83Y/V -
        ke*pD83Y  
      
      #pD83N
      E_AB_pD83N  = (1 - Gmin_AB/KG_pD83N)*(AB/MIC_AB_pD83N)^HILL_AB/((AB/MIC_AB_pD83N)^HILL_AB - (Gmin_AB/KG_pD83N))
      E_CIP_pD83N = (1 - Gmin_CIP/KG_pD83N)*(CIP/(MIC_CIP_pD83N))^HILL_CIP/((CIP/(MIC_CIP_pD83N))^HILL_CIP - (Gmin_CIP/KG_pD83N))
      E_INTER_pD83N = E_AB_pD83N/(-(Gmin_AB/KG_pD83N -1))*E_CIP_pD83N/(-(Gmin_CIP/KG_pD83N -1))*INTER*((-(Gmin_AB/KG_pD83N -1))+(-(Gmin_CIP/KG_pD83N -1)))
      
      d/dt(pD83N) = pD83N*(1-((B_all)/10^Bmax))*KG_pD83N*(1- (E_AB_pD83N + E_CIP_pD83N + E_INTER_pD83N)) +
        
        
        GR_S_pD83N/V - 
        GR_pD83N_gS81FpD83N/V -
        ke*pD83N
      
      
      ###### Single resistant mutants with mutation in GyrA ####
      #gS81Y
      E_AB_gS81Y = (1 - Gmin_AB/KG_gS81Y)*(AB/MIC_AB_gS81Y)^HILL_AB/((AB/MIC_AB_gS81Y)^HILL_AB - (Gmin_AB/KG_gS81Y))
      E_CIP_gS81Y = (1 - Gmin_CIP/KG_gS81Y)*(CIP/(MIC_CIP_gS81Y))^HILL_CIP/((CIP/(MIC_CIP_gS81Y))^HILL_CIP - (Gmin_CIP/KG_gS81Y))
      E_INTER_gS81Y = E_AB_gS81Y/(-(Gmin_AB/KG_gS81Y -1))*E_CIP_gS81Y/(-(Gmin_CIP/KG_gS81Y -1))*INTER*((-(Gmin_AB/KG_gS81Y -1))+(-(Gmin_CIP/KG_gS81Y -1)))
      
      d/dt(gS81Y) = gS81Y*(1-((B_all)/10^Bmax))*KG_gS81Y*(1- (E_AB_gS81Y +  E_CIP_gS81Y  + E_INTER_gS81Y)) +
        
        
        GR_S_gS81Y/V - 
        GR_gS81Y_gS81YpS79Y/V -
        GR_gS81Y_gS81YpS79F/V -
        ke*gS81Y
      
      #gS81F
      E_AB_gS81F = (1 - Gmin_AB/KG_gS81F)*(AB/MIC_AB_gS81F)^HILL_AB/((AB/MIC_AB_gS81F)^HILL_AB - (Gmin_AB/KG_gS81F))
      E_CIP_gS81F = (1 - Gmin_CIP/KG_gS81F)*(CIP/(MIC_CIP_gS81F))^HILL_CIP/((CIP/(MIC_CIP_gS81F))^HILL_CIP - (Gmin_CIP/KG_gS81F))
      E_INTER_gS81F = E_AB_gS81F/(-(Gmin_AB/KG_gS81F -1))*E_CIP_gS81F/(-(Gmin_CIP/KG_gS81F -1))*INTER*((-(Gmin_AB/KG_gS81F -1))+(-(Gmin_CIP/KG_gS81F -1)))
      
      d/dt(gS81F) = gS81F*(1-((B_all)/10^Bmax))*KG_gS81F*(1- (E_AB_gS81F +  E_CIP_gS81F  + E_INTER_gS81F)) +
        
        
        GR_S_gS81F/V - 
        GR_gS81F_gS81FpS79Y/V -
        GR_gS81F_gS81FpS79F/V -
        GR_gS81F_gS81FpD83Y/V -
        GR_gS81F_gS81FpD83N/V -
        ke*gS81F
      
      #E85K
      E_AB_gE85K = (1 - Gmin_AB/KG_gE85K)*(AB/MIC_AB_gE85K)^HILL_AB/((AB/MIC_AB_gE85K)^HILL_AB - (Gmin_AB/KG_gE85K))
      E_CIP_gE85K = (1 - Gmin_CIP/KG_gE85K)*(CIP/(MIC_CIP_gE85K))^HILL_CIP/((CIP/(MIC_CIP_gE85K))^HILL_CIP - (Gmin_CIP/KG_gE85K))
      E_INTER_gE85K = E_AB_gE85K/(-(Gmin_AB/KG_gE85K -1))*E_CIP_gE85K/(-(Gmin_CIP/KG_gE85K -1))*INTER*((-(Gmin_AB/KG_gE85K -1))+(-(Gmin_CIP/KG_gE85K -1)))
      
      d/dt(gE85K) = gE85K*(1-((B_all)/10^Bmax))*KG_gE85K*(1- (E_AB_gE85K +  E_CIP_gE85K  + E_INTER_gE85K)) +
        
        
        GR_S_gE85K/V - 
        GR_gE85K_gE85KpS79Y/V -
        ke*gE85K
      
      #E85G
      E_AB_gE85G = (1 - Gmin_AB/KG_gE85G)*(AB/MIC_AB_gE85G)^HILL_AB/((AB/MIC_AB_gE85G)^HILL_AB - (Gmin_AB/KG_gE85G))
      E_CIP_gE85G = (1 - Gmin_CIP/KG_gE85G)*(CIP/(MIC_CIP_gE85G))^HILL_CIP/((CIP/(MIC_CIP_gE85G))^HILL_CIP - (Gmin_CIP/KG_gE85G))
      E_INTER_gE85G = E_AB_gE85G/(-(Gmin_AB/KG_gE85G -1))*E_CIP_gE85G/(-(Gmin_CIP/KG_gE85G -1))*INTER*((-(Gmin_AB/KG_gE85G -1))+(-(Gmin_CIP/KG_gE85G -1)))
      
      d/dt(gE85G) = gE85G*(1-((B_all)/10^Bmax))*KG_gE85G*(1- (E_AB_gE85G +  E_CIP_gE85G  + E_INTER_gE85G)) +
        
        
        GR_S_gE85G/V - 
        GR_gE85G_gE85GpS79F/V -
        ke*gE85G
      
      #### Double mutants with parC and gyrA  #### 
      
      #gS81YpS79Y
      E_AB_gS81YpS79Y  = (1 - Gmin_AB/KG_gS81YpS79Y)*(AB/(MIC_AB_gS81YpS79Y))^HILL_AB/((AB/(MIC_AB_gS81YpS79Y))^HILL_AB - (Gmin_AB/KG_gS81YpS79Y))
      E_CIP_gS81YpS79Y = (1 - Gmin_CIP/KG_gS81YpS79Y)*(CIP/MIC_CIP_gS81YpS79Y)^HILL_CIP/((CIP/MIC_CIP_gS81YpS79Y)^HILL_CIP - (Gmin_CIP/KG_gS81YpS79Y))
      E_INTER_gS81YpS79Y = E_AB_gS81YpS79Y/(-(Gmin_AB/KG_gS81YpS79Y-1))*E_CIP_gS81YpS79Y/(-(Gmin_CIP/KG_gS81YpS79Y -1))*INTER*((-(Gmin_AB/KG_gS81YpS79Y-1))+(-(Gmin_CIP/KG_gS81YpS79Y -1)))
      
      d/dt(gS81YpS79Y) = gS81YpS79Y*(1-((B_all)/10^Bmax))*KG_gS81YpS79Y*(1 - (E_AB_gS81YpS79Y + E_CIP_gS81YpS79Y + E_INTER_gS81YpS79Y)) +
        
        GR_pS79Y_gS81YpS79Y/V + 
        GR_gS81Y_gS81YpS79Y/V -
        ke*gS81YpS79Y
      
      #gS81YpS79F
      E_AB_gS81YpS79F  = (1 - Gmin_AB/KG_gS81YpS79F)*(AB/(MIC_AB_gS81YpS79F))^HILL_AB/((AB/(MIC_AB_gS81YpS79F))^HILL_AB - (Gmin_AB/KG_gS81YpS79F))
      E_CIP_gS81YpS79F = (1 - Gmin_CIP/KG_gS81YpS79F)*(CIP/MIC_CIP_gS81YpS79F)^HILL_CIP/((CIP/MIC_CIP_gS81YpS79F)^HILL_CIP - (Gmin_CIP/KG_gS81YpS79F))
      E_INTER_gS81YpS79F = E_AB_gS81YpS79F/(-(Gmin_AB/KG_gS81YpS79F-1))*E_CIP_gS81YpS79F/(-(Gmin_CIP/KG_gS81YpS79F -1))*INTER*((-(Gmin_AB/KG_gS81YpS79F-1))+(-(Gmin_CIP/KG_gS81YpS79F -1)))
      
      d/dt(gS81YpS79F) = gS81YpS79F*(1-((B_all)/10^Bmax))*KG_gS81YpS79F*(1 - (E_AB_gS81YpS79F + E_CIP_gS81YpS79F + E_INTER_gS81YpS79F)) +
        
        GR_pS79F_gS81YpS79F/V + 
        GR_gS81Y_gS81YpS79F/V -
        ke*gS81YpS79F   
      
      #gS81FpS79Y
      E_AB_gS81FpS79Y  = (1 - Gmin_AB/KG_gS81FpS79Y)*(AB/(MIC_AB_gS81FpS79Y))^HILL_AB/((AB/(MIC_AB_gS81FpS79Y))^HILL_AB - (Gmin_AB/KG_gS81FpS79Y))
      E_CIP_gS81FpS79Y = (1 - Gmin_CIP/KG_gS81FpS79Y)*(CIP/MIC_CIP_gS81FpS79Y)^HILL_CIP/((CIP/MIC_CIP_gS81FpS79Y)^HILL_CIP - (Gmin_CIP/KG_gS81FpS79Y))
      E_INTER_gS81FpS79Y = E_AB_gS81FpS79Y/(-(Gmin_AB/KG_gS81FpS79Y-1))*E_CIP_gS81FpS79Y/(-(Gmin_CIP/KG_gS81FpS79Y -1))*INTER*((-(Gmin_AB/KG_gS81FpS79Y-1))+(-(Gmin_CIP/KG_gS81FpS79Y -1)))
      
      d/dt(gS81FpS79Y) = gS81FpS79Y*(1-((B_all)/10^Bmax))*KG_gS81FpS79Y*(1 - (E_AB_gS81FpS79Y + E_CIP_gS81FpS79Y + E_INTER_gS81FpS79Y)) +
        
        GR_pS79Y_gS81FpS79Y/V + 
        GR_gS81F_gS81FpS79Y/V -
        ke*gS81FpS79Y 
      
      #gS81FpS79F
      E_AB_gS81FpS79F  = (1 - Gmin_AB/KG_gS81FpS79F)*(AB/(MIC_AB_gS81FpS79F))^HILL_AB/((AB/(MIC_AB_gS81FpS79F))^HILL_AB - (Gmin_AB/KG_gS81FpS79F))
      E_CIP_gS81FpS79F = (1 - Gmin_CIP/KG_gS81FpS79F)*(CIP/MIC_CIP_gS81FpS79F)^HILL_CIP/((CIP/MIC_CIP_gS81FpS79F)^HILL_CIP - (Gmin_CIP/KG_gS81FpS79F))
      E_INTER_gS81FpS79F = E_AB_gS81FpS79F/(-(Gmin_AB/KG_gS81FpS79F-1))*E_CIP_gS81FpS79F/(-(Gmin_CIP/KG_gS81FpS79F -1))*INTER*((-(Gmin_AB/KG_gS81FpS79F-1))+(-(Gmin_CIP/KG_gS81FpS79F -1)))
      
      d/dt(gS81FpS79F) = gS81FpS79F*(1-((B_all)/10^Bmax))*KG_gS81FpS79F*(1 - (E_AB_gS81FpS79F + E_CIP_gS81FpS79F + E_INTER_gS81FpS79F)) +
        
        GR_pS79F_gS81FpS79F/V + 
        GR_gS81F_gS81FpS79F/V -
        ke*gS81FpS79F
      
      #gS81FpD83Y
      E_AB_gS81FpD83Y  = (1 - Gmin_AB/KG_gS81FpD83Y)*(AB/(MIC_AB_gS81FpD83Y))^HILL_AB/((AB/(MIC_AB_gS81FpD83Y))^HILL_AB - (Gmin_AB/KG_gS81FpD83Y))
      E_CIP_gS81FpD83Y = (1 - Gmin_CIP/KG_gS81FpD83Y)*(CIP/MIC_CIP_gS81FpD83Y)^HILL_CIP/((CIP/MIC_CIP_gS81FpD83Y)^HILL_CIP - (Gmin_CIP/KG_gS81FpD83Y))
      E_INTER_gS81FpD83Y = E_AB_gS81FpD83Y/(-(Gmin_AB/KG_gS81FpD83Y-1))*E_CIP_gS81FpD83Y/(-(Gmin_CIP/KG_gS81FpD83Y -1))*INTER*((-(Gmin_AB/KG_gS81FpD83Y-1))+(-(Gmin_CIP/KG_gS81FpD83Y -1)))
      
      d/dt(gS81FpD83Y) = gS81FpD83Y*(1-((B_all)/10^Bmax))*KG_gS81FpD83Y*(1 - (E_AB_gS81FpD83Y + E_CIP_gS81FpD83Y + E_INTER_gS81FpD83Y)) +
        
        GR_pD83Y_gS81FpD83Y/V + 
        GR_gS81F_gS81FpD83Y/V -
        ke*gS81FpD83Y
      
      #gS81FpD83N
      E_AB_gS81FpD83N  = (1 - Gmin_AB/KG_gS81FpD83N)*(AB/(MIC_AB_gS81FpD83N))^HILL_AB/((AB/(MIC_AB_gS81FpD83N))^HILL_AB - (Gmin_AB/KG_gS81FpD83N))
      E_CIP_gS81FpD83N = (1 - Gmin_CIP/KG_gS81FpD83N)*(CIP/MIC_CIP_gS81FpD83N)^HILL_CIP/((CIP/MIC_CIP_gS81FpD83N)^HILL_CIP - (Gmin_CIP/KG_gS81FpD83N))
      E_INTER_gS81FpD83N = E_AB_gS81FpD83N/(-(Gmin_AB/KG_gS81FpD83N-1))*E_CIP_gS81FpD83N/(-(Gmin_CIP/KG_gS81FpD83N -1))*INTER*((-(Gmin_AB/KG_gS81FpD83N-1))+(-(Gmin_CIP/KG_gS81FpD83N -1)))
      
      d/dt(gS81FpD83N) = gS81FpD83N*(1-((B_all)/10^Bmax))*KG_gS81FpD83N*(1 - (E_AB_gS81FpD83N + E_CIP_gS81FpD83N + E_INTER_gS81FpD83N)) +
        
        GR_pD83N_gS81FpD83N/V + 
        GR_gS81F_gS81FpD83N/V -
        ke*gS81FpD83N
      
      #gE85KpS79Y
      E_AB_gE85KpS79Y  = (1 - Gmin_AB/KG_gE85KpS79Y)*(AB/(MIC_AB_gE85KpS79Y))^HILL_AB/((AB/(MIC_AB_gE85KpS79Y))^HILL_AB - (Gmin_AB/KG_gE85KpS79Y))
      E_CIP_gE85KpS79Y = (1 - Gmin_CIP/KG_gE85KpS79Y)*(CIP/MIC_CIP_gE85KpS79Y)^HILL_CIP/((CIP/MIC_CIP_gE85KpS79Y)^HILL_CIP - (Gmin_CIP/KG_gE85KpS79Y))
      E_INTER_gE85KpS79Y = E_AB_gE85KpS79Y/(-(Gmin_AB/KG_gE85KpS79Y-1))*E_CIP_gE85KpS79Y/(-(Gmin_CIP/KG_gE85KpS79Y -1))*INTER*((-(Gmin_AB/KG_gE85KpS79Y-1))+(-(Gmin_CIP/KG_gE85KpS79Y -1)))
      
      d/dt(gE85KpS79Y) = gE85KpS79Y*(1-((B_all)/10^Bmax))*KG_gE85KpS79Y*(1 - (E_AB_gE85KpS79Y + E_CIP_gE85KpS79Y + E_INTER_gE85KpS79Y)) +
        
        GR_pS79Y_gE85KpS79Y/V + 
        GR_gE85K_gE85KpS79Y/V -
        ke*gE85KpS79Y
      
      #gE85GpS79F
      E_AB_gE85GpS79F  = (1 - Gmin_AB/KG_gE85GpS79F)*(AB/(MIC_AB_gE85GpS79F))^HILL_AB/((AB/(MIC_AB_gE85GpS79F))^HILL_AB - (Gmin_AB/KG_gE85GpS79F))
      E_CIP_gE85GpS79F = (1 - Gmin_CIP/KG_gE85GpS79F)*(CIP/MIC_CIP_gE85GpS79F)^HILL_CIP/((CIP/MIC_CIP_gE85GpS79F)^HILL_CIP - (Gmin_CIP/KG_gE85GpS79F))
      E_INTER_gE85GpS79F = E_AB_gE85GpS79F/(-(Gmin_AB/KG_gE85GpS79F-1))*E_CIP_gE85GpS79F/(-(Gmin_CIP/KG_gE85GpS79F -1))*INTER*((-(Gmin_AB/KG_gE85GpS79F-1))+(-(Gmin_CIP/KG_gE85GpS79F -1)))
      
      d/dt(gE85GpS79F) = gE85GpS79F*(1-((B_all)/10^Bmax))*KG_gE85GpS79F*(1 - (E_AB_gE85GpS79F + E_CIP_gE85GpS79F + E_INTER_gE85GpS79F)) +
        
        GR_pS79F_gE85GpS79F/V + 
        GR_gE85G_gE85GpS79F/V -
        ke*gE85GpS79F
    });
    
    print("model constructed")
    ##### Parameters ####    
    
    S0  <- 10^eS0
    U   <- p_u
    V_blood <- 5*1000 #mL
    V   <- V_blood
    
    theta <- c( Bmax        = p_Bmax,    # maximum carrying capacity 
                abs_KG_S    = p_KG_S,    # maximal net growth S
                
                abs_KG_pS79Y = p_KG_pS79Y,    # maximal net growth pS79Y
                abs_KG_pS79F = p_KG_pS79F,    # maximal net growth pS79F
                abs_KG_pD83Y = p_KG_pD83Y,    # maximal net growth pD83Y
                abs_KG_pD83N = p_KG_pD83N,    # maximal net growth pD83N
                
                abs_KG_gS81Y = p_KG_gS81Y,    # maximal net growth gS81Y
                abs_KG_gS81F = p_KG_gS81F,    # maximal net growth gS81F
                abs_KG_gE85K = p_KG_gE85K,    # maximal net growth gE85K
                abs_KG_gE85G = p_KG_gE85G,    # maximal net growth gE85G
                
                abs_KG_gS81YpS79Y    = p_KG_gS81YpS79Y,    # maximal net growth gS81YpS79Y
                abs_KG_gS81YpS79F    = p_KG_gS81YpS79F,    # maximal net growth gS81YpS79F
                abs_KG_gS81FpS79Y    = p_KG_gS81FpS79Y,    # maximal net growth gS81FpS79Y
                abs_KG_gS81FpS79F    = p_KG_gS81FpS79F,    # maximal net growth gS81FpS79F
                abs_KG_gS81FpD83Y    = p_KG_gS81FpD83Y,    # maximal net growth gS81FpD83Y
                abs_KG_gS81FpD83N    = p_KG_gS81FpD83N,    # maximal net growth gS81FpD83N
                abs_KG_gE85KpS79Y    = p_KG_gE85KpS79Y,    # maximal net growth gE85KpS79Y
                abs_KG_gE85GpS79F    = p_KG_gE85GpS79F,    # maximal net growth gE85GpS79F
                KG_D39      = log(2)/(54/60), #D39
                
                
                
                Gmin_CIP = p_GMIN_CIP,
                HILL_CIP = p_HILL_CIP,
                
                Gmin_AB  = p_GMIN_AB,
                HILL_AB  = p_HILL_AB,
                
                INTER    = p_INTER, 
                
                MIC_CIP_S = p_MIC_CIP_S, #CIP MIC if sensitive WT (S)
                
                MIC_CIP_pS79Y = p_MIC_CIP_pS79Y, #CIP MIC if intermediate resistant pS79Y (parC)
                MIC_CIP_pS79F = p_MIC_CIP_pS79F, #CIP MIC if intermediate resistant pS79F (parC)
                MIC_CIP_pD83Y = p_MIC_CIP_pD83Y, #CIP MIC if intermediate resistant pD83Y (parC)
                MIC_CIP_pD83N = p_MIC_CIP_pD83N, #CIP MIC if intermediate resistant pD83N (parC)
                
                MIC_CIP_gS81Y = p_MIC_CIP_gS81Y, #CIP MIC if intermediate resistant gS81Y (gyrA)
                MIC_CIP_gS81F = p_MIC_CIP_gS81F, #CIP MIC if intermediate resistant gS81F (gyrA)
                MIC_CIP_gE85K = p_MIC_CIP_gE85K, #CIP MIC if intermediate resistant gE85K (gyrA)
                MIC_CIP_gE85G = p_MIC_CIP_gE85G, #CIP MIC if intermediate resistant gE85G (gyrA)
                
                MIC_CIP_gS81YpS79Y = p_MIC_CIP_gS81YpS79Y, #CIP MIC if resistant  gS81YpS79Y  (gryA + parC)
                MIC_CIP_gS81YpS79F = p_MIC_CIP_gS81YpS79F, #CIP MIC if resistant  gS81YpS79F  (gryA + parC)
                MIC_CIP_gS81FpS79Y = p_MIC_CIP_gS81FpS79Y, #CIP MIC if resistant  gS81FpS79Y  (gryA + parC)
                MIC_CIP_gS81FpS79F = p_MIC_CIP_gS81FpS79F, #CIP MIC if resistant  gS81FpS79F  (gryA + parC)
                MIC_CIP_gS81FpD83Y = p_MIC_CIP_gS81FpD83Y, #CIP MIC if resistant  gS81FpD83Y  (gryA + parC)
                MIC_CIP_gS81FpD83N = p_MIC_CIP_gS81FpD83N, #CIP MIC if resistant  gS81FpD83N  (gryA + parC)
                MIC_CIP_gE85KpS79Y = p_MIC_CIP_gE85KpS79Y, #CIP MIC if resistant  gE85KpS79Y  (gryA + parC)
                MIC_CIP_gE85GpS79F = p_MIC_CIP_gE85GpS79F, #CIP MIC if resistant  gE85GpS79F  (gryA + parC)
                
                MIC_AB_S  = p_MIC_AB_S,  #MIC if sensitive WT (S)
                
                MIC_AB_pS79Y  = p_MIC_AB_pS79Y,  #MIC if intermediate resistant pS79Y (parC)
                MIC_AB_pS79F  = p_MIC_AB_pS79F,  #MIC if intermediate resistant pS79F (parC)
                MIC_AB_pD83Y  = p_MIC_AB_pD83Y,  #MIC if intermediate resistant pD83Y (parC)
                MIC_AB_pD83N  = p_MIC_AB_pD83N,  #MIC if intermediate resistant pD83N (parC)
                
                MIC_AB_gS81Y  = p_MIC_AB_gS81Y,  #MIC if intermediate resistant gS81Y (gyrA)
                MIC_AB_gS81F  = p_MIC_AB_gS81F,  #MIC if intermediate resistant gS81F (gyrA)
                MIC_AB_gE85K  = p_MIC_AB_gE85K,  #MIC if intermediate resistant gE85K (gyrA)
                MIC_AB_gE85G  = p_MIC_AB_gE85G,  #MIC if intermediate resistant gE85G (gyrA)
                
                MIC_AB_gS81YpS79Y  = p_MIC_AB_gS81YpS79Y  , #MIC if resistant (R) (gyrA + parC)
                MIC_AB_gS81YpS79F  = p_MIC_AB_gS81YpS79F  , #MIC if resistant (R) (gyrA + parC)
                MIC_AB_gS81FpS79Y  = p_MIC_AB_gS81FpS79Y  , #MIC if resistant (R) (gyrA + parC)
                MIC_AB_gS81FpS79F  = p_MIC_AB_gS81FpS79F  , #MIC if resistant (R) (gyrA + parC)
                MIC_AB_gS81FpD83Y  = p_MIC_AB_gS81FpD83Y  , #MIC if resistant (R) (gyrA + parC)
                MIC_AB_gS81FpD83N  = p_MIC_AB_gS81FpD83N  , #MIC if resistant (R) (gyrA + parC)
                MIC_AB_gE85KpS79Y  = p_MIC_AB_gE85KpS79Y  , #MIC if resistant (R) (gyrA + parC)
                MIC_AB_gE85GpS79F  = p_MIC_AB_gE85GpS79F  , #MIC if resistant (R) (gyrA + parC)
                
                V       = p_V, 
                ke      = p_ke,
                CIP_ke  = CIP_ke,
                CIP_V   = CIP_V,
                CIP_fu  = CIP_fu,
                AB_ke   = AB_ke,
                AB_V    = AB_V,

                AB_fu   = AB_fu)    # PK elimination rate constant))
    
    #n = 100
    
    print("start run")
    
    
    #n_obs <- length(PK_1day$time)
    n_obs  <- ST*DT+1
    n_models <- length(PK_model_list)
    
    
    df_full_CS <-  foreach( ii = 1:n, .combine = "rbind", 
                            .packages = c("RxODE", "dplyr", "ggplot2", "tidyr", "patchwork"),
                            
                            .inorder = F,
                            .options.RNG = 123) %dorng%  {
                              
                              cat(paste("in index =", ii, "\n"), file = "start_log", append = T)
                              
                              i_time <- Sys.time() 
                              
                              df_model_CS <- data.frame(time  = NA,
                                                        S     = NA,
                                                        
                                                        pS79Y  = NA,
                                                        pS79F  = NA,
                                                        pD83Y  = NA,
                                                        pD83N  = NA,
                                                        
                                                        gS81Y  = NA,
                                                        gS81F  = NA,
                                                        gE85K  = NA,
                                                        gE85G  = NA,
                                                        
                                                        gS81YpS79Y     = NA,
                                                        gS81YpS79F     = NA,
                                                        gS81FpS79Y     = NA,
                                                        gS81FpS79F     = NA,
                                                        gS81FpD83Y     = NA,
                                                        gS81FpD83N     = NA,
                                                        gE85KpS79Y     = NA,
                                                        gE85GpS79F     = NA,
                                                        
                                                        A_CIP = NA,
                                                        CIP   = NA,
                                                        A_AB  = NA,
                                                        A2_AB = NA,
                                                        AB    = NA,
                                                        model = NA)
                              
                              for(i_mod in 1:length(PK_model_list)) {
                                #   #   
                                
                                # cat(paste("Started", i_mod), file = "first_loop_log", append = T)
                                ###### running the model ####                                
                                
                                PK_mod = PK_model_list[[i_mod]]
                                #print(PK_mod)
                                
                                
                                df_CS <- data.frame(time     = rep(x = NA, times = n_obs),
                                                    S        = rep(x = NA, times = n_obs),
                                                    
                                                    pS79Y     = rep(x = NA, times = n_obs),
                                                    pS79F     = rep(x = NA, times = n_obs),
                                                    pD83Y     = rep(x = NA, times = n_obs),
                                                    pD83N     = rep(x = NA, times = n_obs),
                                                    
                                                    gS81Y     = rep(x = NA, times = n_obs),
                                                    gS81F     = rep(x = NA, times = n_obs),
                                                    gE85K     = rep(x = NA, times = n_obs),
                                                    gE85G     = rep(x = NA, times = n_obs),
                                                    
                                                    gS81YpS79Y  = rep(x = NA, times = n_obs),
                                                    gS81YpS79F  = rep(x = NA, times = n_obs),
                                                    gS81FpS79Y  = rep(x = NA, times = n_obs),
                                                    gS81FpS79F  = rep(x = NA, times = n_obs),
                                                    gS81FpD83Y  = rep(x = NA, times = n_obs),
                                                    gS81FpD83N  = rep(x = NA, times = n_obs),
                                                    gE85KpS79Y  = rep(x = NA, times = n_obs),
                                                    gE85GpS79F  = rep(x = NA, times = n_obs),
                                                    
                                                    A_CIP    = rep(x = NA, times = n_obs),
                                                    CIP      = rep(x = NA, times = n_obs),
                                                    A_AB     = rep(x = NA, times = n_obs),
                                                   
                                                    AB       = rep(x = NA, times = n_obs))
                                
                                
                                
                                
                                
                                df_CS[1,] <- data.frame(time = 0, S = 10^eS0, 
                                                        pS79Y = 0,
                                                        pS79F = 0,
                                                        pD83Y = 0,
                                                        pD83N = 0,
                                                        
                                                        gS81Y = 0, 
                                                        gS81F = 0, 
                                                        gE85K = 0, 
                                                        gE85G = 0, 
                                                        
                                                        gS81YpS79Y = 0, 
                                                        gS81YpS79F = 0, 
                                                        gS81FpS79Y = 0, 
                                                        gS81FpS79F = 0, 
                                                        gS81FpD83Y = 0, 
                                                        gS81FpD83N = 0, 
                                                        gE85KpS79Y = 0, 
                                                        gE85GpS79F = 0, 
                                                        
                                                        A_CIP = PK_mod$A_CIP[1], CIP = PK_mod$CIP[1], 
                                                        A_AB  =  PK_mod$A_AB[1], 
                                                        AB = PK_mod$AB[1]);
                                
                                
                                # cat(paste("index =", ii, "modlel =", dose_reg[i_mod] ,
                                #           ", time = ",  df_CS$time[1], ", S = ",  df_CS$S[1], ", ParC = ",  df_CS$ParC[1],", GyrA = ",  df_CS$GyrA[1], ", R = ",  df_CS$R[1],
                                #           ", CIP = ",  df_CS$CIP[1], ", AB = ",  df_CS$AB[1], "\n"), file = "begining_log", append = T)
                                # 
                                
                                V = p_V
                                
                                for (i in 1:((ST+T_start)*DT)) {
                                 
                                  #Previous time points
                                  
                                  S_t    <- df_CS$S[i]
                                  
                                  pS79Y_t <- df_CS$pS79Y[i]
                                  pS79F_t <- df_CS$pS79F[i]
                                  pD83Y_t <- df_CS$pD83Y[i]
                                  pD83N_t <- df_CS$pD83N[i]
                                  
                                  gS81Y_t <- df_CS$gS81Y[i]
                                  gS81F_t <- df_CS$gS81F[i]
                                  gE85K_t <- df_CS$gE85K[i]
                                  gE85G_t <- df_CS$gE85G[i]
                                  
                                  gS81YpS79Y_t    <- df_CS$gS81YpS79Y[i]
                                  gS81YpS79F_t    <- df_CS$gS81YpS79F[i]
                                  gS81FpS79Y_t    <- df_CS$gS81FpS79Y[i]
                                  gS81FpS79F_t    <- df_CS$gS81FpS79F[i]
                                  gS81FpD83Y_t    <- df_CS$gS81FpD83Y[i]
                                  gS81FpD83N_t    <- df_CS$gS81FpD83N[i]
                                  gE85KpS79Y_t    <- df_CS$gE85KpS79Y[i]
                                  gE85GpS79F_t    <- df_CS$gE85GpS79F[i]
                                  
                                  CIP_t  <- PK_mod$CIP[i]
                                  AB_t   <- PK_mod$AB[i]
                                  
                                  A_CIP_t  <- PK_mod$A_CIP[i]
                                  A_AB_t   <- PK_mod$A_AB[i]
                            
                                  
                                  
                                  
                                  #-------------------
                                  ###### Mutations  #####
                                  
                                  
                                  
                                  # S to GyrA or ParC #####    
                                  
                                  if(is.na(as.integer( S_t*V )) & !is.na(S_t*V )) {
                    
                                    n_itr <- floor(S_t*V/10^9)
                                    
                                    res_t <- floor(S_t*V - n_itr*10^9)
                                    
                                    
                                    GR_S_pS79Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_S_pS79F <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_S_pD83Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_S_pD83N <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_S_gS81Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_S_gS81F <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_S_gE85K <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_S_gE85G <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    
                                    # cat(paste("in index =", ii, 
                                    #           "GR_S_pS79Y =" , GR_S_pS79Y, 
                                    #           "GR_S_pS79F =" , GR_S_pS79F, 
                                    #           "GR_S_pD83Y =" , GR_S_pD83Y, 
                                    #           "GR_S_pD83N =" , GR_S_pD83N, 
                                    #           "GR_S_gS81Y =" , GR_S_gS81Y, 
                                    #           "GR_S_gS81F =" , GR_S_gS81F, 
                                    #           "GR_S_gE85K =" , GR_S_gE85K, 
                                    #           "GR_S_gE85G =" , GR_S_gE85G, "\n"), file = "St_log", append = T)
                                    # 
                                    
                                  } else if (as.integer( S_t*V )>0) {
                                    
                                    
                                    GR_S_pS79Y <- rbinom(1, as.integer( S_t*V ), U)
                                    GR_S_pS79F <- rbinom(1, as.integer( S_t*V ), U)
                                    GR_S_pD83Y <- rbinom(1, as.integer( S_t*V ), U)
                                    GR_S_pD83N <- rbinom(1, as.integer( S_t*V ), U)
                                    GR_S_gS81Y <- rbinom(1, as.integer( S_t*V ), U)
                                    GR_S_gS81F <- rbinom(1, as.integer( S_t*V ), U)
                                    GR_S_gE85K <- rbinom(1, as.integer( S_t*V ), U)
                                    GR_S_gE85G <- rbinom(1, as.integer( S_t*V ), U)
                                    
                                  } else{
                                    
                                    GR_S_pS79Y <- 0
                                    GR_S_pS79F <- 0
                                    GR_S_pD83Y <- 0
                                    GR_S_pD83N <- 0
                                    GR_S_gS81Y <- 0
                                    GR_S_gS81F <- 0
                                    GR_S_gE85K <- 0
                                    GR_S_gE85G <- 0
                                    
                                  }
                                  
                                  
                                  ## Parc to R ####
                                  
                                  
                                  
                                  #pS79Y
                                  if(is.na(as.integer( pS79Y_t*V )) &! is.na(pS79Y_t*V )) {
                                    
                                    n_itr <- floor(pS79Y_t*V/10^9)
                                    
                                    res_t <- floor(pS79Y_t*V - n_itr*10^9)
                                    
                                    
                                    
                                    GR_pS79Y_gS81YpS79Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_pS79Y_gS81FpS79Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_pS79Y_gE85KpS79Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    
                                    # cat(paste("in index =", ii, 
                                    #           "GR_pS79Y_gS81YpS79Y =" , GR_pS79Y_gS81YpS79Y,
                                    #           "GR_pS79Y_gS81FpS79Y =" , GR_pS79Y_gS81FpS79Y,
                                    #           "GR_pS79Y_gE85KpS79Y =" , GR_pS79Y_gE85KpS79Y, "\n"), file = "pS79Yt_log", append = T)
                                    
                                  } else if (as.integer( pS79Y_t*V )>0) {
                                    
                                    GR_pS79Y_gS81YpS79Y <- rbinom(1, as.integer( pS79Y_t*V ), U)
                                    GR_pS79Y_gS81FpS79Y <- rbinom(1, as.integer( pS79Y_t*V ), U)
                                    GR_pS79Y_gE85KpS79Y <- rbinom(1, as.integer( pS79Y_t*V ), U)
                                    
                                  } else{
                                    
                                    
                                    GR_pS79Y_gS81YpS79Y <- 0
                                    GR_pS79Y_gS81FpS79Y <- 0
                                    GR_pS79Y_gE85KpS79Y <- 0
                                  }
                                  
                                  
                                  
                                  #pS79F
                                  if(is.na(as.integer( pS79F_t*V )) &! is.na(pS79F_t*V )) {
                                    
                                    n_itr <- floor(pS79F_t*V/10^9)
                                    
                                    res_t <- floor(pS79F_t*V - n_itr*10^9)
                                    
                                    
                                    
                                    GR_pS79F_gS81YpS79F <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_pS79F_gS81FpS79F <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_pS79F_gE85GpS79F <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    # cat(paste("in index =", ii, 
                                    #           "GR_pS79F_gS81YpS79F =" , GR_pS79F_gS81YpS79F,
                                    #           "GR_pS79F_gS81FpS79F =" , GR_pS79F_gS81FpS79F,
                                    #           "GR_pS79F_gE85GpS79F =" , GR_pS79F_gE85GpS79F, "\n"), file = "pS79Ft_log", append = T)
                                    
                                  } else if (as.integer( pS79F_t*V )>0) {
                                    
                                    GR_pS79F_gS81YpS79F <- rbinom(1, as.integer( pS79F_t*V ), U)
                                    GR_pS79F_gS81FpS79F <- rbinom(1, as.integer( pS79F_t*V ), U)
                                    GR_pS79F_gE85GpS79F <- rbinom(1, as.integer( pS79F_t*V ), U)
                                    
                                  } else{
                                    
                                    
                                    GR_pS79F_gS81YpS79F <- 0
                                    GR_pS79F_gS81FpS79F <- 0
                                    GR_pS79F_gE85GpS79F <- 0
                                  }
                                  
                                  
                                  
                                  #pD83Y
                                  if(is.na(as.integer( pD83Y_t*V ))&!is.na(pD83Y_t*V )) {
                                    
                                    n_itr <- floor(pD83Y_t*V/10^9)
                                    
                                    res_t <- floor(pD83Y_t*V - n_itr*10^9)
                                    
                                    
                                    
                                    GR_pD83Y_gS81FpD83Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    
                                    # cat(paste("in index =", ii, 
                                    #           "GR_pD83Y_gS81FpD83Y =" , GR_pD83Y_gS81FpD83Y,
                                    #           "\n"), file = "pD83Y_log", append = T)
                                    # 
                                    
                                  } else if (as.integer( pD83Y_t*V )>0) {
                                    
                                    GR_pD83Y_gS81FpD83Y <- rbinom(1, as.integer( pD83Y_t*V ), U)
                                    
                                    
                                  } else{
                                    
                                    
                                    GR_pD83Y_gS81FpD83Y <- 0
                                    
                                  }
                                  
                                  
                                  
                                  #pD83N
                                  if(is.na(as.integer( pD83N_t*V ))&!is.na(pD83N_t*V )) {
                                    
                                    n_itr <- floor(pD83N_t*V/10^9)
                                    
                                    res_t <- floor(pD83N_t*V - n_itr*10^9)
                                    
                                    
                                    
                                    GR_pD83N_gS81FpD83N <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    # cat(paste("in index =", ii, 
                                    #           "GR_pD83N_gS81FpD83N =" , GR_pD83N_gS81FpD83N,
                                    #           "\n"), file = "pD83N_log", append = T)
                                    
                                  } else if (as.integer( pD83N_t*V )>0) {
                                    
                                    GR_pD83N_gS81FpD83N <- rbinom(1, as.integer( pD83N_t*V ), U)
                                    
                                    
                                  } else{
                                    
                                    
                                    GR_pD83N_gS81FpD83N <- 0
                                    
                                  } 
                                  
                                  
                                  ## GyrA to R ####
                                  
                                  #gS81Y
                                  if(is.na(as.integer( gS81Y_t*V )) &!is.na(gS81Y_t*V )) {
                                    
                                    n_itr <- floor(gS81Y_t*V/10^9)
                                    
                                    res_t <- floor(gS81Y_t*V - n_itr*10^9)
                                    
                                    GR_gS81Y_gS81YpS79Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_gS81Y_gS81YpS79F <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    
                                    GR_pD83N_gS81FpD83N <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    # cat(paste("in index =", ii, 
                                    #           "GR_gS81Y_gS81YpS79Y = ", GR_gS81Y_gS81YpS79Y,
                                    #           "GR_gS81Y_gS81YpS79F = ", GR_gS81Y_gS81YpS79F,
                                    #        
                                    #           "\n"), file = "gS81Y_log", append = T)
                                    
                                  } else if (as.integer( gS81Y_t*V )>0) {
                                    
                                    GR_gS81Y_gS81YpS79Y <- rbinom(1, as.integer( gS81Y_t*V ), U)
                                    GR_gS81Y_gS81YpS79F <- rbinom(1, as.integer( gS81Y_t*V ), U)
                                    
                                    
                                  } else{
                                    
                                    
                                    GR_gS81Y_gS81YpS79Y <- 0
                                    GR_gS81Y_gS81YpS79F <- 0
                                    
                                  }
                                  
                                  
                                  #gS81F
                                  if(is.na(as.integer( gS81F_t*V )) &! is.na(gS81F_t*V )) {
                                    
                                    n_itr <- floor(gS81F_t*V/10^9)
                                    
                                    res_t <- floor(gS81F_t*V - n_itr*10^9)
                                    
                                    GR_gS81F_gS81FpS79Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_gS81F_gS81FpS79F <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_gS81F_gS81FpD83Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_gS81F_gS81FpD83N <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    
                                  } else if (as.integer( gS81F_t*V )>0) {
                                    
                                    GR_gS81F_gS81FpS79Y <- rbinom(1, as.integer( gS81F_t*V ), U)
                                    GR_gS81F_gS81FpS79F <- rbinom(1, as.integer( gS81F_t*V ), U)
                                    GR_gS81F_gS81FpD83Y <- rbinom(1, as.integer( gS81F_t*V ), U)
                                    GR_gS81F_gS81FpD83N <- rbinom(1, as.integer( gS81F_t*V ), U)
                                    
                                  } else{
                                    
                                    
                                    GR_gS81F_gS81FpS79Y <- 0
                                    GR_gS81F_gS81FpS79F <- 0
                                    GR_gS81F_gS81FpD83Y <- 0
                                    GR_gS81F_gS81FpD83N <- 0
                                  }
                                  
                                  
                                  #gE85K
                                  if(is.na(as.integer( gE85K_t*V )) &! is.na(gE85K_t*V )) {
                                    
                                    n_itr <- floor(gE85K_t*V/10^9)
                                    
                                    res_t <- floor(gE85K_t*V - n_itr*10^9)
                                    
                                    GR_gE85K_gE85KpS79Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    
                                    
                                    
                                  } else if (as.integer( gE85K_t*V )>0) {
                                    
                                    GR_gE85K_gE85KpS79Y <- rbinom(1, as.integer( gE85K_t*V ), U)
                                    
                                    
                                    
                                  } else{
                                    
                                    GR_gE85K_gE85KpS79Y <- 0
                                    
                                    
                                  }
                                  
                                  
                                  #gE85G
                                  if(is.na(as.integer( gE85G_t*V )) &!is.na(gE85G_t*V )) {
                                    
                                    n_itr <- floor(gE85G_t*V/10^9)
                                    
                                    res_t <- floor(gE85G_t*V - n_itr*10^9)
                                    
                                    GR_gE85G_gE85GpS79F <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    
                                    
                                    
                                  } else if (as.integer( gE85G_t*V )>0) {
                                    
                                    GR_gE85G_gE85GpS79F <- rbinom(1, as.integer( gE85G_t*V ), U)
                                    
                                    
                                    
                                  } else{
                                    
                                    GR_gE85G_gE85GpS79F <- 0
                                    
                                    
                                  }
                                  
                                  
                                  

                                  # cat(paste("index =", ii, "time_step=", i,#  "model =", dose_reg[i_mod] ,
                                  #          # ", GR_S_ParC", GR_S_ParC, ", GR_S_GyrA = ", GR_S_GyrA, ", GR_ParC_R = ",
                                  #           #GR_ParC_R, ", GR_GyrA_R = ", GR_GyrA_R, 
                                  #           "\n"), file = "mut_log", append = T)


                                  
                                  
                                  
                                  ev <- eventTable(amount.units="mg", time.units="hours") %>%
                                    add.sampling(seq(0,1))  %>%
                                    mutate(# S
                                      GR_S_pS79Y = GR_S_pS79Y,
                                      GR_S_pS79F = GR_S_pS79F,
                                      GR_S_pD83Y = GR_S_pD83Y,
                                      GR_S_pD83N = GR_S_pD83N,
                                      GR_S_gS81Y = GR_S_gS81Y,
                                      GR_S_gS81F = GR_S_gS81F,
                                      GR_S_gE85K = GR_S_gE85K,
                                      GR_S_gE85G = GR_S_gE85G,
                                      #parC to R
                                      GR_pS79Y_gS81YpS79Y = GR_pS79Y_gS81YpS79Y,
                                      GR_pS79Y_gS81FpS79Y = GR_pS79Y_gS81FpS79Y,
                                      GR_pS79Y_gE85KpS79Y = GR_pS79Y_gE85KpS79Y,
                                      GR_pS79F_gS81YpS79F = GR_pS79F_gS81YpS79F,
                                      GR_pS79F_gS81FpS79F = GR_pS79F_gS81FpS79F,
                                      GR_pS79F_gE85GpS79F = GR_pS79F_gE85GpS79F,
                                      GR_pD83Y_gS81FpD83Y = GR_pD83Y_gS81FpD83Y,
                                      GR_pD83N_gS81FpD83N = GR_pD83N_gS81FpD83N,
                                      #GyrA to R
                                      GR_gS81Y_gS81YpS79Y = GR_gS81Y_gS81YpS79Y,
                                      GR_gS81Y_gS81YpS79F = GR_gS81Y_gS81YpS79F,
                                      GR_gS81F_gS81FpS79Y = GR_gS81F_gS81FpS79Y,
                                      GR_gS81F_gS81FpS79F = GR_gS81F_gS81FpS79F,
                                      GR_gS81F_gS81FpD83Y = GR_gS81F_gS81FpD83Y,
                                      GR_gS81F_gS81FpD83N = GR_gS81F_gS81FpD83N,
                                      GR_gE85K_gE85KpS79Y = GR_gE85K_gE85KpS79Y,
                                      GR_gE85G_gE85GpS79F = GR_gE85G_gE85GpS79F) %>%   
                                    
                                    as.tbl()
                                  
                                  
                                  
                                  t_inits <- c(S = S_t, 
                                               pS79Y = pS79Y_t, 
                                               pS79F = pS79F_t,
                                               pD83Y = pD83Y_t,
                                               pD83N = pD83N_t,
                                               
                                               gS81Y = gS81Y_t,
                                               gS81F = gS81F_t, 
                                               gE85K = gE85K_t, 
                                               gE85G = gE85G_t, 
                                               
                                               gS81YpS79Y = gS81YpS79Y_t,
                                               gS81YpS79F = gS81YpS79F_t,
                                               gS81FpS79Y = gS81FpS79Y_t,
                                               gS81FpS79F = gS81FpS79F_t,
                                               gS81FpD83Y = gS81FpD83Y_t,
                                               gS81FpD83N = gS81FpD83N_t,
                                               gE85KpS79Y = gE85KpS79Y_t,
                                               gE85GpS79F = gE85GpS79F_t,
                                               A_CIP = A_CIP_t, CIP = CIP_t, A_AB = A_AB_t,  AB = AB_t);
                                  
                                  # cat(paste("index =", ii, "time_step=", i,  "modlel =", dose_reg[i_mod] ,
                                  #           ", tinits, S = ",  t_inits[1], ", ParC = ",  t_inits[2], ", GyrA = ",  t_inits[3], ", R = ",  t_inits[4],
                                  #           ", A_CIP = ",  t_inits[5], ", CIP = ",  t_inits[6], ", A_AB = ",  t_inits[7], ", AB = ",  t_inits[8], "\n"), file = "t_inits_log", append = T)
                                  # 
                                  
                                  
                                  x_CS   <- as.data.frame(CS_mod$run(theta, ev,  t_inits)) %>%
                                    mutate(time = time + i-1)  %>% 
                                    select(time , S , 
                                           pS79Y,
                                           pS79F,
                                           pD83Y,
                                           pD83N,
                                           
                                           gS81Y,
                                           gS81F,
                                           gE85K,
                                           gE85G,
                                           
                                           gS81YpS79Y,
                                           gS81YpS79F,
                                           gS81FpS79Y,
                                           gS81FpS79F,
                                           gS81FpD83Y,
                                           gS81FpD83N,
                                           gE85KpS79Y,
                                           gE85GpS79F,
                                           
                                           A_CIP, CIP , A_AB, AB);
                                  
                                  
                                  df_CS[i:(i+1),] <- x_CS
                                  
                                  
                                  # 
                                  # cat(paste("index =", ii, "time_step=", i,  "modlel =", dose_reg[i_mod] ,
                                  #           ", time = ",  df_CS$time[1], ", S = ",  df_CS$S[1], ", ParC = ",  df_CS$ParC[1], ", GyrA = ",  df_CS$GyrA[1], ", R = ",  df_CS$R[1],
                                  #           ", CIP = ",  df_CS$CIP[1], ", AB = ",  df_CS$AB[1], "\n"), file = "mid_2_log", append = T)
                                  # 
                                  
                                  
                                  
                                }
                                
                                
                                
                                df_CS$model <- dose_reg[i_mod] 
                                
                                df_model_CS <- df_model_CS %>%
                                  bind_rows(df_CS)
                                
                                # cat(paste("index =", ii,
                                #            "\n"), file = "post_bind_log", append = T)
                              }
                              
                              
                              
                              
                              df_model_CS$index <- ii
                              
                              # 
                              d_time <- round( Sys.time()- i_time )
                              
                              # cat(paste("index =", ii,
                              #           ", S =", round(min(df_model_CS$S, na.rm = T)),", time = ",  d_time , "\n"), file = "out_log", append = T)
                              # 
                              
                              #length(df_CS$time
                              
                              return(df_model_CS)
                              
                              #full_CS_df[(n_obs*(ii-1)),] <- df_CS
                              
                            }
    
    
  }
  
  #sink()
  
  
  ### if 2 CMT comp
  
  if(DRUG == "ERY"){
   print("ERY go") 
    
    #ODE
    CS_mod<- RxODE({
      
      
      ####### PK######
      
      d/dt(A_CIP)  =  -CIP_ke*A_CIP
      d/dt(A_AB)   =  -AB_ke*A_AB    - AB_k12*A_AB + AB_k21*A2_AB
      d/dt(A2_AB)  =   AB_k12*A_AB   - AB_k21*A2_AB
      
      
      #AB conc
      CIP =  A_CIP/CIP_V*CIP_fu
      AB  =  A_AB/AB_V*AB_fu
      
      
      
      
      KG_S = KG_D39   #Yu et al

       
      KG_pS79Y = KG_D39*abs_KG_pS79Y/abs_KG_S
      KG_pS79F = KG_D39*abs_KG_pS79F/abs_KG_S
      KG_pD83Y = KG_D39*abs_KG_pD83Y/abs_KG_S
      KG_pD83N = KG_D39*abs_KG_pD83N/abs_KG_S
      
      KG_gS81Y = KG_D39*abs_KG_gS81Y/abs_KG_S
      KG_gS81F = KG_D39*abs_KG_gS81F/abs_KG_S
      KG_gE85K = KG_D39*abs_KG_gE85K/abs_KG_S
      KG_gE85G = KG_D39*abs_KG_gE85G/abs_KG_S
      
      KG_gS81YpS79Y = KG_D39*abs_KG_gS81YpS79Y/abs_KG_S
      KG_gS81YpS79F = KG_D39*abs_KG_gS81YpS79F/abs_KG_S
      KG_gS81FpS79Y = KG_D39*abs_KG_gS81FpS79Y/abs_KG_S
      KG_gS81FpS79F = KG_D39*abs_KG_gS81FpS79F/abs_KG_S
      KG_gS81FpD83Y = KG_D39*abs_KG_gS81FpD83Y/abs_KG_S
      KG_gS81FpD83N = KG_D39*abs_KG_gS81FpD83N/abs_KG_S
      KG_gE85KpS79Y = KG_D39*abs_KG_gE85KpS79Y/abs_KG_S
      KG_gE85GpS79F = KG_D39*abs_KG_gE85GpS79F/abs_KG_S
      
      ###PD#####
  
  #sum all bacaterial popualions     
      B_all = S + 
        pS79Y + pS79F + pD83Y + pD83N +
        gS81Y + gS81F + gE85K + gE85G +
        gS81YpS79Y + gS81YpS79F + gS81FpS79Y +
        gS81FpS79F + gS81FpD83Y +  gS81FpD83N + gE85KpS79Y + gE85GpS79F
        
      
######Sensitive wild type ####
     
      E_AB_S  = (1 - Gmin_AB/KG_S)*(AB/MIC_AB_S)^HILL_AB/((AB/MIC_AB_S)^HILL_AB - (Gmin_AB/KG_S))
      E_CIP_S = (1 - Gmin_CIP/KG_S)*(CIP/MIC_CIP_S)^HILL_CIP/((CIP/MIC_CIP_S)^HILL_CIP - (Gmin_CIP/KG_S))
      E_INTER_S = E_AB_S/(-(Gmin_AB/KG_S -1))*E_CIP_S/(-(Gmin_CIP/KG_S -1))*INTER*((-(Gmin_AB/KG_S -1))+(-(Gmin_CIP/KG_S -1)))
      
      d/dt(S) = S*(1-((B_all)/10^Bmax))*KG_S*(1 - (E_AB_S + E_CIP_S + E_INTER_S )) -
        
        GR_S_pS79Y/V -
        GR_S_pS79F/V - 
        GR_S_pD83Y/V - 
        GR_S_pD83N/V - 
        
        GR_S_gS81Y/V -
        GR_S_gS81F/V -
        GR_S_gE85K/V - 
        GR_S_gE85G/V -
  
        ke*S
      
      
 ###### Single resistant mutants with mutation in ParC ####
      #pS79Y
      E_AB_pS79Y  = (1 - Gmin_AB/KG_pS79Y)*(AB/MIC_AB_pS79Y)^HILL_AB/((AB/MIC_AB_pS79Y)^HILL_AB - (Gmin_AB/KG_pS79Y))
      E_CIP_pS79Y = (1 - Gmin_CIP/KG_pS79Y)*(CIP/(MIC_CIP_pS79Y))^HILL_CIP/((CIP/(MIC_CIP_pS79Y))^HILL_CIP - (Gmin_CIP/KG_pS79Y))
      E_INTER_pS79Y = E_AB_pS79Y/(-(Gmin_AB/KG_pS79Y -1))*E_CIP_pS79Y/(-(Gmin_CIP/KG_pS79Y -1))*INTER*((-(Gmin_AB/KG_pS79Y -1))+(-(Gmin_CIP/KG_pS79Y -1)))
      
      d/dt(pS79Y) = pS79Y*(1-((B_all)/10^Bmax))*KG_pS79Y*(1- (E_AB_pS79Y + E_CIP_pS79Y + E_INTER_pS79Y)) +
        
    
        GR_S_pS79Y/V - 
        GR_pS79Y_gS81YpS79Y/V -
        GR_pS79Y_gS81FpS79Y/V -
        GR_pS79Y_gE85KpS79Y/V -
        ke*pS79Y
      
      
      #pS79F
      E_AB_pS79F  = (1 - Gmin_AB/KG_pS79F)*(AB/MIC_AB_pS79F)^HILL_AB/((AB/MIC_AB_pS79F)^HILL_AB - (Gmin_AB/KG_pS79F))
      E_CIP_pS79F = (1 - Gmin_CIP/KG_pS79F)*(CIP/(MIC_CIP_pS79F))^HILL_CIP/((CIP/(MIC_CIP_pS79F))^HILL_CIP - (Gmin_CIP/KG_pS79F))
      E_INTER_pS79F = E_AB_pS79F/(-(Gmin_AB/KG_pS79F -1))*E_CIP_pS79F/(-(Gmin_CIP/KG_pS79F -1))*INTER*((-(Gmin_AB/KG_pS79F -1))+(-(Gmin_CIP/KG_pS79F -1)))
      
      d/dt(pS79F) = pS79F*(1-((B_all)/10^Bmax))*KG_pS79F*(1- (E_AB_pS79F + E_CIP_pS79F + E_INTER_pS79F)) +
        
        
        GR_S_pS79F/V - 
        GR_pS79F_gS81YpS79F/V -
        GR_pS79F_gS81FpS79F/V -
        GR_pS79F_gE85GpS79F/V -
        ke*pS79F
      
      #pD83Y
      E_AB_pD83Y  = (1 - Gmin_AB/KG_pD83Y)*(AB/MIC_AB_pD83Y)^HILL_AB/((AB/MIC_AB_pD83Y)^HILL_AB - (Gmin_AB/KG_pD83Y))
      E_CIP_pD83Y = (1 - Gmin_CIP/KG_pD83Y)*(CIP/(MIC_CIP_pD83Y))^HILL_CIP/((CIP/(MIC_CIP_pD83Y))^HILL_CIP - (Gmin_CIP/KG_pD83Y))
      E_INTER_pD83Y = E_AB_pD83Y/(-(Gmin_AB/KG_pD83Y -1))*E_CIP_pD83Y/(-(Gmin_CIP/KG_pD83Y -1))*INTER*((-(Gmin_AB/KG_pD83Y -1))+(-(Gmin_CIP/KG_pD83Y -1)))
      
      d/dt(pD83Y) = pD83Y*(1-((B_all)/10^Bmax))*KG_pD83Y*(1- (E_AB_pD83Y + E_CIP_pD83Y + E_INTER_pD83Y)) +
        
        
        GR_S_pD83Y/V - 
        GR_pD83Y_gS81FpD83Y/V -
        ke*pD83Y  
      
      #pD83N
      E_AB_pD83N  = (1 - Gmin_AB/KG_pD83N)*(AB/MIC_AB_pD83N)^HILL_AB/((AB/MIC_AB_pD83N)^HILL_AB - (Gmin_AB/KG_pD83N))
      E_CIP_pD83N = (1 - Gmin_CIP/KG_pD83N)*(CIP/(MIC_CIP_pD83N))^HILL_CIP/((CIP/(MIC_CIP_pD83N))^HILL_CIP - (Gmin_CIP/KG_pD83N))
      E_INTER_pD83N = E_AB_pD83N/(-(Gmin_AB/KG_pD83N -1))*E_CIP_pD83N/(-(Gmin_CIP/KG_pD83N -1))*INTER*((-(Gmin_AB/KG_pD83N -1))+(-(Gmin_CIP/KG_pD83N -1)))
      
      d/dt(pD83N) = pD83N*(1-((B_all)/10^Bmax))*KG_pD83N*(1- (E_AB_pD83N + E_CIP_pD83N + E_INTER_pD83N)) +
        
        
        GR_S_pD83N/V - 
        GR_pD83N_gS81FpD83N/V -
        ke*pD83N
      
      
 ###### Single resistant mutants with mutation in GyrA ####
      #gS81Y
      E_AB_gS81Y = (1 - Gmin_AB/KG_gS81Y)*(AB/MIC_AB_gS81Y)^HILL_AB/((AB/MIC_AB_gS81Y)^HILL_AB - (Gmin_AB/KG_gS81Y))
      E_CIP_gS81Y = (1 - Gmin_CIP/KG_gS81Y)*(CIP/(MIC_CIP_gS81Y))^HILL_CIP/((CIP/(MIC_CIP_gS81Y))^HILL_CIP - (Gmin_CIP/KG_gS81Y))
      E_INTER_gS81Y = E_AB_gS81Y/(-(Gmin_AB/KG_gS81Y -1))*E_CIP_gS81Y/(-(Gmin_CIP/KG_gS81Y -1))*INTER*((-(Gmin_AB/KG_gS81Y -1))+(-(Gmin_CIP/KG_gS81Y -1)))
      
      d/dt(gS81Y) = gS81Y*(1-((B_all)/10^Bmax))*KG_gS81Y*(1- (E_AB_gS81Y +  E_CIP_gS81Y  + E_INTER_gS81Y)) +
        
        
        GR_S_gS81Y/V - 
        GR_gS81Y_gS81YpS79Y/V -
        GR_gS81Y_gS81YpS79F/V -
        ke*gS81Y
      
      #gS81F
      E_AB_gS81F = (1 - Gmin_AB/KG_gS81F)*(AB/MIC_AB_gS81F)^HILL_AB/((AB/MIC_AB_gS81F)^HILL_AB - (Gmin_AB/KG_gS81F))
      E_CIP_gS81F = (1 - Gmin_CIP/KG_gS81F)*(CIP/(MIC_CIP_gS81F))^HILL_CIP/((CIP/(MIC_CIP_gS81F))^HILL_CIP - (Gmin_CIP/KG_gS81F))
      E_INTER_gS81F = E_AB_gS81F/(-(Gmin_AB/KG_gS81F -1))*E_CIP_gS81F/(-(Gmin_CIP/KG_gS81F -1))*INTER*((-(Gmin_AB/KG_gS81F -1))+(-(Gmin_CIP/KG_gS81F -1)))
      
      d/dt(gS81F) = gS81F*(1-((B_all)/10^Bmax))*KG_gS81F*(1- (E_AB_gS81F +  E_CIP_gS81F  + E_INTER_gS81F)) +
        
        
        GR_S_gS81F/V - 
        GR_gS81F_gS81FpS79Y/V -
        GR_gS81F_gS81FpS79F/V -
        GR_gS81F_gS81FpD83Y/V -
        GR_gS81F_gS81FpD83N/V -
        ke*gS81F
      
      #E85K
      E_AB_gE85K = (1 - Gmin_AB/KG_gE85K)*(AB/MIC_AB_gE85K)^HILL_AB/((AB/MIC_AB_gE85K)^HILL_AB - (Gmin_AB/KG_gE85K))
      E_CIP_gE85K = (1 - Gmin_CIP/KG_gE85K)*(CIP/(MIC_CIP_gE85K))^HILL_CIP/((CIP/(MIC_CIP_gE85K))^HILL_CIP - (Gmin_CIP/KG_gE85K))
      E_INTER_gE85K = E_AB_gE85K/(-(Gmin_AB/KG_gE85K -1))*E_CIP_gE85K/(-(Gmin_CIP/KG_gE85K -1))*INTER*((-(Gmin_AB/KG_gE85K -1))+(-(Gmin_CIP/KG_gE85K -1)))
      
      d/dt(gE85K) = gE85K*(1-((B_all)/10^Bmax))*KG_gE85K*(1- (E_AB_gE85K +  E_CIP_gE85K  + E_INTER_gE85K)) +
        
        
        GR_S_gE85K/V - 
        GR_gE85K_gE85KpS79Y/V -
        ke*gE85K
      
      #E85G
      E_AB_gE85G = (1 - Gmin_AB/KG_gE85G)*(AB/MIC_AB_gE85G)^HILL_AB/((AB/MIC_AB_gE85G)^HILL_AB - (Gmin_AB/KG_gE85G))
      E_CIP_gE85G = (1 - Gmin_CIP/KG_gE85G)*(CIP/(MIC_CIP_gE85G))^HILL_CIP/((CIP/(MIC_CIP_gE85G))^HILL_CIP - (Gmin_CIP/KG_gE85G))
      E_INTER_gE85G = E_AB_gE85G/(-(Gmin_AB/KG_gE85G -1))*E_CIP_gE85G/(-(Gmin_CIP/KG_gE85G -1))*INTER*((-(Gmin_AB/KG_gE85G -1))+(-(Gmin_CIP/KG_gE85G -1)))
      
      d/dt(gE85G) = gE85G*(1-((B_all)/10^Bmax))*KG_gE85G*(1- (E_AB_gE85G +  E_CIP_gE85G  + E_INTER_gE85G)) +
        
        
        GR_S_gE85G/V - 
        GR_gE85G_gE85GpS79F/V -
        ke*gE85G
      
  #### Double mutants with parC and gyrA  #### 
      
      #gS81YpS79Y
      E_AB_gS81YpS79Y  = (1 - Gmin_AB/KG_gS81YpS79Y)*(AB/(MIC_AB_gS81YpS79Y))^HILL_AB/((AB/(MIC_AB_gS81YpS79Y))^HILL_AB - (Gmin_AB/KG_gS81YpS79Y))
      E_CIP_gS81YpS79Y = (1 - Gmin_CIP/KG_gS81YpS79Y)*(CIP/MIC_CIP_gS81YpS79Y)^HILL_CIP/((CIP/MIC_CIP_gS81YpS79Y)^HILL_CIP - (Gmin_CIP/KG_gS81YpS79Y))
      E_INTER_gS81YpS79Y = E_AB_gS81YpS79Y/(-(Gmin_AB/KG_gS81YpS79Y-1))*E_CIP_gS81YpS79Y/(-(Gmin_CIP/KG_gS81YpS79Y -1))*INTER*((-(Gmin_AB/KG_gS81YpS79Y-1))+(-(Gmin_CIP/KG_gS81YpS79Y -1)))
      
      d/dt(gS81YpS79Y) = gS81YpS79Y*(1-((B_all)/10^Bmax))*KG_gS81YpS79Y*(1 - (E_AB_gS81YpS79Y + E_CIP_gS81YpS79Y + E_INTER_gS81YpS79Y)) +
        
        GR_pS79Y_gS81YpS79Y/V + 
        GR_gS81Y_gS81YpS79Y/V -
        ke*gS81YpS79Y
      
      #gS81YpS79F
      E_AB_gS81YpS79F  = (1 - Gmin_AB/KG_gS81YpS79F)*(AB/(MIC_AB_gS81YpS79F))^HILL_AB/((AB/(MIC_AB_gS81YpS79F))^HILL_AB - (Gmin_AB/KG_gS81YpS79F))
      E_CIP_gS81YpS79F = (1 - Gmin_CIP/KG_gS81YpS79F)*(CIP/MIC_CIP_gS81YpS79F)^HILL_CIP/((CIP/MIC_CIP_gS81YpS79F)^HILL_CIP - (Gmin_CIP/KG_gS81YpS79F))
      E_INTER_gS81YpS79F = E_AB_gS81YpS79F/(-(Gmin_AB/KG_gS81YpS79F-1))*E_CIP_gS81YpS79F/(-(Gmin_CIP/KG_gS81YpS79F -1))*INTER*((-(Gmin_AB/KG_gS81YpS79F-1))+(-(Gmin_CIP/KG_gS81YpS79F -1)))
      
      d/dt(gS81YpS79F) = gS81YpS79F*(1-((B_all)/10^Bmax))*KG_gS81YpS79F*(1 - (E_AB_gS81YpS79F + E_CIP_gS81YpS79F + E_INTER_gS81YpS79F)) +
        
        GR_pS79F_gS81YpS79F/V + 
        GR_gS81Y_gS81YpS79F/V -
        ke*gS81YpS79F   
      
      #gS81FpS79Y
      E_AB_gS81FpS79Y  = (1 - Gmin_AB/KG_gS81FpS79Y)*(AB/(MIC_AB_gS81FpS79Y))^HILL_AB/((AB/(MIC_AB_gS81FpS79Y))^HILL_AB - (Gmin_AB/KG_gS81FpS79Y))
      E_CIP_gS81FpS79Y = (1 - Gmin_CIP/KG_gS81FpS79Y)*(CIP/MIC_CIP_gS81FpS79Y)^HILL_CIP/((CIP/MIC_CIP_gS81FpS79Y)^HILL_CIP - (Gmin_CIP/KG_gS81FpS79Y))
      E_INTER_gS81FpS79Y = E_AB_gS81FpS79Y/(-(Gmin_AB/KG_gS81FpS79Y-1))*E_CIP_gS81FpS79Y/(-(Gmin_CIP/KG_gS81FpS79Y -1))*INTER*((-(Gmin_AB/KG_gS81FpS79Y-1))+(-(Gmin_CIP/KG_gS81FpS79Y -1)))
      
      d/dt(gS81FpS79Y) = gS81FpS79Y*(1-((B_all)/10^Bmax))*KG_gS81FpS79Y*(1 - (E_AB_gS81FpS79Y + E_CIP_gS81FpS79Y + E_INTER_gS81FpS79Y)) +
        
        GR_pS79Y_gS81FpS79Y/V + 
        GR_gS81F_gS81FpS79Y/V -
        ke*gS81FpS79Y 
      
      #gS81FpS79F
      E_AB_gS81FpS79F  = (1 - Gmin_AB/KG_gS81FpS79F)*(AB/(MIC_AB_gS81FpS79F))^HILL_AB/((AB/(MIC_AB_gS81FpS79F))^HILL_AB - (Gmin_AB/KG_gS81FpS79F))
      E_CIP_gS81FpS79F = (1 - Gmin_CIP/KG_gS81FpS79F)*(CIP/MIC_CIP_gS81FpS79F)^HILL_CIP/((CIP/MIC_CIP_gS81FpS79F)^HILL_CIP - (Gmin_CIP/KG_gS81FpS79F))
      E_INTER_gS81FpS79F = E_AB_gS81FpS79F/(-(Gmin_AB/KG_gS81FpS79F-1))*E_CIP_gS81FpS79F/(-(Gmin_CIP/KG_gS81FpS79F -1))*INTER*((-(Gmin_AB/KG_gS81FpS79F-1))+(-(Gmin_CIP/KG_gS81FpS79F -1)))
      
      d/dt(gS81FpS79F) = gS81FpS79F*(1-((B_all)/10^Bmax))*KG_gS81FpS79F*(1 - (E_AB_gS81FpS79F + E_CIP_gS81FpS79F + E_INTER_gS81FpS79F)) +
        
        GR_pS79F_gS81FpS79F/V + 
        GR_gS81F_gS81FpS79F/V -
        ke*gS81FpS79F
      
      #gS81FpD83Y
      E_AB_gS81FpD83Y  = (1 - Gmin_AB/KG_gS81FpD83Y)*(AB/(MIC_AB_gS81FpD83Y))^HILL_AB/((AB/(MIC_AB_gS81FpD83Y))^HILL_AB - (Gmin_AB/KG_gS81FpD83Y))
      E_CIP_gS81FpD83Y = (1 - Gmin_CIP/KG_gS81FpD83Y)*(CIP/MIC_CIP_gS81FpD83Y)^HILL_CIP/((CIP/MIC_CIP_gS81FpD83Y)^HILL_CIP - (Gmin_CIP/KG_gS81FpD83Y))
      E_INTER_gS81FpD83Y = E_AB_gS81FpD83Y/(-(Gmin_AB/KG_gS81FpD83Y-1))*E_CIP_gS81FpD83Y/(-(Gmin_CIP/KG_gS81FpD83Y -1))*INTER*((-(Gmin_AB/KG_gS81FpD83Y-1))+(-(Gmin_CIP/KG_gS81FpD83Y -1)))
      
      d/dt(gS81FpD83Y) = gS81FpD83Y*(1-((B_all)/10^Bmax))*KG_gS81FpD83Y*(1 - (E_AB_gS81FpD83Y + E_CIP_gS81FpD83Y + E_INTER_gS81FpD83Y)) +
        
        GR_pD83Y_gS81FpD83Y/V + 
        GR_gS81F_gS81FpD83Y/V -
        ke*gS81FpD83Y
      
      #gS81FpD83N
      E_AB_gS81FpD83N  = (1 - Gmin_AB/KG_gS81FpD83N)*(AB/(MIC_AB_gS81FpD83N))^HILL_AB/((AB/(MIC_AB_gS81FpD83N))^HILL_AB - (Gmin_AB/KG_gS81FpD83N))
      E_CIP_gS81FpD83N = (1 - Gmin_CIP/KG_gS81FpD83N)*(CIP/MIC_CIP_gS81FpD83N)^HILL_CIP/((CIP/MIC_CIP_gS81FpD83N)^HILL_CIP - (Gmin_CIP/KG_gS81FpD83N))
      E_INTER_gS81FpD83N = E_AB_gS81FpD83N/(-(Gmin_AB/KG_gS81FpD83N-1))*E_CIP_gS81FpD83N/(-(Gmin_CIP/KG_gS81FpD83N -1))*INTER*((-(Gmin_AB/KG_gS81FpD83N-1))+(-(Gmin_CIP/KG_gS81FpD83N -1)))
      
      d/dt(gS81FpD83N) = gS81FpD83N*(1-((B_all)/10^Bmax))*KG_gS81FpD83N*(1 - (E_AB_gS81FpD83N + E_CIP_gS81FpD83N + E_INTER_gS81FpD83N)) +
        
        GR_pD83N_gS81FpD83N/V + 
        GR_gS81F_gS81FpD83N/V -
        ke*gS81FpD83N
      
      #gE85KpS79Y
      E_AB_gE85KpS79Y  = (1 - Gmin_AB/KG_gE85KpS79Y)*(AB/(MIC_AB_gE85KpS79Y))^HILL_AB/((AB/(MIC_AB_gE85KpS79Y))^HILL_AB - (Gmin_AB/KG_gE85KpS79Y))
      E_CIP_gE85KpS79Y = (1 - Gmin_CIP/KG_gE85KpS79Y)*(CIP/MIC_CIP_gE85KpS79Y)^HILL_CIP/((CIP/MIC_CIP_gE85KpS79Y)^HILL_CIP - (Gmin_CIP/KG_gE85KpS79Y))
      E_INTER_gE85KpS79Y = E_AB_gE85KpS79Y/(-(Gmin_AB/KG_gE85KpS79Y-1))*E_CIP_gE85KpS79Y/(-(Gmin_CIP/KG_gE85KpS79Y -1))*INTER*((-(Gmin_AB/KG_gE85KpS79Y-1))+(-(Gmin_CIP/KG_gE85KpS79Y -1)))
      
      d/dt(gE85KpS79Y) = gE85KpS79Y*(1-((B_all)/10^Bmax))*KG_gE85KpS79Y*(1 - (E_AB_gE85KpS79Y + E_CIP_gE85KpS79Y + E_INTER_gE85KpS79Y)) +
        
        GR_pS79Y_gE85KpS79Y/V + 
        GR_gE85K_gE85KpS79Y/V -
        ke*gE85KpS79Y
      
      #gE85GpS79F
      E_AB_gE85GpS79F  = (1 - Gmin_AB/KG_gE85GpS79F)*(AB/(MIC_AB_gE85GpS79F))^HILL_AB/((AB/(MIC_AB_gE85GpS79F))^HILL_AB - (Gmin_AB/KG_gE85GpS79F))
      E_CIP_gE85GpS79F = (1 - Gmin_CIP/KG_gE85GpS79F)*(CIP/MIC_CIP_gE85GpS79F)^HILL_CIP/((CIP/MIC_CIP_gE85GpS79F)^HILL_CIP - (Gmin_CIP/KG_gE85GpS79F))
      E_INTER_gE85GpS79F = E_AB_gE85GpS79F/(-(Gmin_AB/KG_gE85GpS79F-1))*E_CIP_gE85GpS79F/(-(Gmin_CIP/KG_gE85GpS79F -1))*INTER*((-(Gmin_AB/KG_gE85GpS79F-1))+(-(Gmin_CIP/KG_gE85GpS79F -1)))
      
      d/dt(gE85GpS79F) = gE85GpS79F*(1-((B_all)/10^Bmax))*KG_gE85GpS79F*(1 - (E_AB_gE85GpS79F + E_CIP_gE85GpS79F + E_INTER_gE85GpS79F)) +
        
        GR_pS79F_gE85GpS79F/V + 
        GR_gE85G_gE85GpS79F/V -
        ke*gE85GpS79F
    });
    print("ERY PD model") 
##### Parameters ####    
    
    S0  <- 10^eS0
    U   <- p_u
    V_blood <- 5*1000 #mL
    V   <- V_blood
    
    theta <- c( Bmax        = p_Bmax,    # maximum carrying capacity 
                abs_KG_S    = p_KG_S,    # maximal net growth S
                
                abs_KG_pS79Y = p_KG_pS79Y,    # maximal net growth pS79Y
                abs_KG_pS79F = p_KG_pS79F,    # maximal net growth pS79F
                abs_KG_pD83Y = p_KG_pD83Y,    # maximal net growth pD83Y
                abs_KG_pD83N = p_KG_pD83N,    # maximal net growth pD83N
                
                abs_KG_gS81Y = p_KG_gS81Y,    # maximal net growth gS81Y
                abs_KG_gS81F = p_KG_gS81F,    # maximal net growth gS81F
                abs_KG_gE85K = p_KG_gE85K,    # maximal net growth gE85K
                abs_KG_gE85G = p_KG_gE85G,    # maximal net growth gE85G
                
                abs_KG_gS81YpS79Y    = p_KG_gS81YpS79Y,    # maximal net growth gS81YpS79Y
                abs_KG_gS81YpS79F    = p_KG_gS81YpS79F,    # maximal net growth gS81YpS79F
                abs_KG_gS81FpS79Y    = p_KG_gS81FpS79Y,    # maximal net growth gS81FpS79Y
                abs_KG_gS81FpS79F    = p_KG_gS81FpS79F,    # maximal net growth gS81FpS79F
                abs_KG_gS81FpD83Y    = p_KG_gS81FpD83Y,    # maximal net growth gS81FpD83Y
                abs_KG_gS81FpD83N    = p_KG_gS81FpD83N,    # maximal net growth gS81FpD83N
                abs_KG_gE85KpS79Y    = p_KG_gE85KpS79Y,    # maximal net growth gE85KpS79Y
                abs_KG_gE85GpS79F    = p_KG_gE85GpS79F,    # maximal net growth gE85GpS79F
                KG_D39      = log(2)/(54/60), #D39
                
            
                
                Gmin_CIP = p_GMIN_CIP,
                HILL_CIP = p_HILL_CIP,
                
                Gmin_AB  = p_GMIN_AB,
                HILL_AB  = p_HILL_AB,
                
                INTER    = p_INTER, 
                
                MIC_CIP_S = p_MIC_CIP_S, #CIP MIC if sensitive WT (S)
                
                MIC_CIP_pS79Y = p_MIC_CIP_pS79Y, #CIP MIC if intermediate resistant pS79Y (parC)
                MIC_CIP_pS79F = p_MIC_CIP_pS79F, #CIP MIC if intermediate resistant pS79F (parC)
                MIC_CIP_pD83Y = p_MIC_CIP_pD83Y, #CIP MIC if intermediate resistant pD83Y (parC)
                MIC_CIP_pD83N = p_MIC_CIP_pD83N, #CIP MIC if intermediate resistant pD83N (parC)
                
                MIC_CIP_gS81Y = p_MIC_CIP_gS81Y, #CIP MIC if intermediate resistant gS81Y (gyrA)
                MIC_CIP_gS81F = p_MIC_CIP_gS81F, #CIP MIC if intermediate resistant gS81F (gyrA)
                MIC_CIP_gE85K = p_MIC_CIP_gE85K, #CIP MIC if intermediate resistant gE85K (gyrA)
                MIC_CIP_gE85G = p_MIC_CIP_gE85G, #CIP MIC if intermediate resistant gE85G (gyrA)
                
                MIC_CIP_gS81YpS79Y = p_MIC_CIP_gS81YpS79Y, #CIP MIC if resistant  gS81YpS79Y  (gryA + parC)
                MIC_CIP_gS81YpS79F = p_MIC_CIP_gS81YpS79F, #CIP MIC if resistant  gS81YpS79F  (gryA + parC)
                MIC_CIP_gS81FpS79Y = p_MIC_CIP_gS81FpS79Y, #CIP MIC if resistant  gS81FpS79Y  (gryA + parC)
                MIC_CIP_gS81FpS79F = p_MIC_CIP_gS81FpS79F, #CIP MIC if resistant  gS81FpS79F  (gryA + parC)
                MIC_CIP_gS81FpD83Y = p_MIC_CIP_gS81FpD83Y, #CIP MIC if resistant  gS81FpD83Y  (gryA + parC)
                MIC_CIP_gS81FpD83N = p_MIC_CIP_gS81FpD83N, #CIP MIC if resistant  gS81FpD83N  (gryA + parC)
                MIC_CIP_gE85KpS79Y = p_MIC_CIP_gE85KpS79Y, #CIP MIC if resistant  gE85KpS79Y  (gryA + parC)
                MIC_CIP_gE85GpS79F = p_MIC_CIP_gE85GpS79F, #CIP MIC if resistant  gE85GpS79F  (gryA + parC)
                
                MIC_AB_S  = p_MIC_AB_S,  #MIC if sensitive WT (S)
                
                MIC_AB_pS79Y  = p_MIC_AB_pS79Y,  #MIC if intermediate resistant pS79Y (parC)
                MIC_AB_pS79F  = p_MIC_AB_pS79F,  #MIC if intermediate resistant pS79F (parC)
                MIC_AB_pD83Y  = p_MIC_AB_pD83Y,  #MIC if intermediate resistant pD83Y (parC)
                MIC_AB_pD83N  = p_MIC_AB_pD83N,  #MIC if intermediate resistant pD83N (parC)
                
                MIC_AB_gS81Y  = p_MIC_AB_gS81Y,  #MIC if intermediate resistant gS81Y (gyrA)
                MIC_AB_gS81F  = p_MIC_AB_gS81F,  #MIC if intermediate resistant gS81F (gyrA)
                MIC_AB_gE85K  = p_MIC_AB_gE85K,  #MIC if intermediate resistant gE85K (gyrA)
                MIC_AB_gE85G  = p_MIC_AB_gE85G,  #MIC if intermediate resistant gE85G (gyrA)
                
                MIC_AB_gS81YpS79Y  = p_MIC_AB_gS81YpS79Y  , #MIC if resistant (R) (gyrA + parC)
                MIC_AB_gS81YpS79F  = p_MIC_AB_gS81YpS79F  , #MIC if resistant (R) (gyrA + parC)
                MIC_AB_gS81FpS79Y  = p_MIC_AB_gS81FpS79Y  , #MIC if resistant (R) (gyrA + parC)
                MIC_AB_gS81FpS79F  = p_MIC_AB_gS81FpS79F  , #MIC if resistant (R) (gyrA + parC)
                MIC_AB_gS81FpD83Y  = p_MIC_AB_gS81FpD83Y  , #MIC if resistant (R) (gyrA + parC)
                MIC_AB_gS81FpD83N  = p_MIC_AB_gS81FpD83N  , #MIC if resistant (R) (gyrA + parC)
                MIC_AB_gE85KpS79Y  = p_MIC_AB_gE85KpS79Y  , #MIC if resistant (R) (gyrA + parC)
                MIC_AB_gE85GpS79F  = p_MIC_AB_gE85GpS79F  , #MIC if resistant (R) (gyrA + parC)
                
                V       = p_V, 
                ke      = p_ke,
                CIP_ke  = CIP_ke,
                CIP_V   = CIP_V,
                CIP_fu  = CIP_fu,
                AB_ke   = AB_ke,
                AB_k12  = AB_k12,
                AB_V    = AB_V,
                AB_k21  = AB_k21,
                AB_fu   = AB_fu)    # PK elimination rate constant))
    
    #n = 100
    
    print("run ERY model") 
    
    
    #n_obs <- length(PK_1day$time)
    n_obs  <- ST*DT+1
    n_models <- length(PK_model_list)
    
    
    df_full_CS <-  foreach( ii = 1:n, .combine = "rbind", 
                            .packages = c("RxODE", "dplyr", "ggplot2", "tidyr", "patchwork"),
                            
                            .inorder = F,
                            .options.RNG = 123) %dorng%  {
                              
                              cat(paste("in index =", ii, "\n"), file = "start_log", append = T)
                              
                              i_time <- Sys.time() 
                              
                              df_model_CS <- data.frame(time  = NA,
                                                        S     = NA,
                                                        
                                                        pS79Y  = NA,
                                                        pS79F  = NA,
                                                        pD83Y  = NA,
                                                        pD83N  = NA,
                                                        
                                                        gS81Y  = NA,
                                                        gS81F  = NA,
                                                        gE85K  = NA,
                                                        gE85G  = NA,
                                                        
                                                        gS81YpS79Y     = NA,
                                                        gS81YpS79F     = NA,
                                                        gS81FpS79Y     = NA,
                                                        gS81FpS79F     = NA,
                                                        gS81FpD83Y     = NA,
                                                        gS81FpD83N     = NA,
                                                        gE85KpS79Y     = NA,
                                                        gE85GpS79F     = NA,
                                                        
                                                        A_CIP = NA,
                                                        CIP   = NA,
                                                        A_AB  = NA,
                                                        A2_AB = NA,
                                                        AB    = NA,
                                                        model = NA)
                              
                              for(i_mod in 1:length(PK_model_list)) {
                                #   #   
                                
                                cat(paste("Started", i_mod), file = "first_loop_log", append = T)
###### running the model ####                                
                                
                                PK_mod = PK_model_list[[i_mod]]
                                #print(PK_mod)
                                
                                
                                df_CS <- data.frame(time     = rep(x = NA, times = n_obs),
                                                    S        = rep(x = NA, times = n_obs),
                                                    
                                                    pS79Y     = rep(x = NA, times = n_obs),
                                                    pS79F     = rep(x = NA, times = n_obs),
                                                    pD83Y     = rep(x = NA, times = n_obs),
                                                    pD83N     = rep(x = NA, times = n_obs),
                                                    
                                                    gS81Y     = rep(x = NA, times = n_obs),
                                                    gS81F     = rep(x = NA, times = n_obs),
                                                    gE85K     = rep(x = NA, times = n_obs),
                                                    gE85G     = rep(x = NA, times = n_obs),
                                                    
                                                    gS81YpS79Y  = rep(x = NA, times = n_obs),
                                                    gS81YpS79F  = rep(x = NA, times = n_obs),
                                                    gS81FpS79Y  = rep(x = NA, times = n_obs),
                                                    gS81FpS79F  = rep(x = NA, times = n_obs),
                                                    gS81FpD83Y  = rep(x = NA, times = n_obs),
                                                    gS81FpD83N  = rep(x = NA, times = n_obs),
                                                    gE85KpS79Y  = rep(x = NA, times = n_obs),
                                                    gE85GpS79F  = rep(x = NA, times = n_obs),
                                                    
                                                    A_CIP    = rep(x = NA, times = n_obs),
                                                    CIP      = rep(x = NA, times = n_obs),
                                                    A_AB     = rep(x = NA, times = n_obs),
                                                    A2_AB    = rep(x = NA, times = n_obs),
                                                    AB       = rep(x = NA, times = n_obs))
                                
                                
                                
                                
                                
                                df_CS[1,] <- data.frame(time = 0, S = 10^eS0, 
                                                        pS79Y = 0,
                                                        pS79F = 0,
                                                        pD83Y = 0,
                                                        pD83N = 0,
                                                        
                                                        gS81Y = 0, 
                                                        gS81F = 0, 
                                                        gE85K = 0, 
                                                        gE85G = 0, 
                                                        
                                                        gS81YpS79Y = 0, 
                                                        gS81YpS79F = 0, 
                                                        gS81FpS79Y = 0, 
                                                        gS81FpS79F = 0, 
                                                        gS81FpD83Y = 0, 
                                                        gS81FpD83N = 0, 
                                                        gE85KpS79Y = 0, 
                                                        gE85GpS79F = 0, 
                                                        
                                                        A_CIP = PK_mod$A_CIP[1], CIP = PK_mod$CIP[1], 
                                                        A_AB  =  PK_mod$A_AB[1], A2_AB = PK_mod$A2_AB[1], 
                                                        AB = PK_mod$AB[1]);
                                
                                
                                # cat(paste("index =", ii, "modlel =", dose_reg[i_mod] ,
                                #           ", time = ",  df_CS$time[1], ", S = ",  df_CS$S[1], ", ",
                                #           "CIP = ",  df_CS$CIP[1], ", AB = ",  df_CS$AB[1], "\n"), file = "begining_log", append = T)
                                # 
                                
                                # cat(paste("index =", ii, "modlel =", dose_reg[i_mod] ,
                                #           ", time = ",  df_CS$time[1], ", S = ",  df_CS$S[1], ", ParC = ",  df_CS$ParC[1],", GyrA = ",  df_CS$GyrA[1], ", R = ",  df_CS$R[1],
                                #           ", CIP = ",  df_CS$CIP[1], ", AB = ",  df_CS$AB[1], "\n"), file = "begining_log", append = T)
                                # 
                                
                                V = p_V
                               
                                for (i in 1:((ST+T_start)*DT)) {
                                  
                                  #Previous time points
                                  
                                  S_t    <- df_CS$S[i]
                                  
                                  pS79Y_t <- df_CS$pS79Y[i]
                                  pS79F_t <- df_CS$pS79F[i]
                                  pD83Y_t <- df_CS$pD83Y[i]
                                  pD83N_t <- df_CS$pD83N[i]
                                  
                                  gS81Y_t <- df_CS$gS81Y[i]
                                  gS81F_t <- df_CS$gS81F[i]
                                  gE85K_t <- df_CS$gE85K[i]
                                  gE85G_t <- df_CS$gE85G[i]
                                  
                                  gS81YpS79Y_t    <- df_CS$gS81YpS79Y[i]
                                  gS81YpS79F_t    <- df_CS$gS81YpS79F[i]
                                  gS81FpS79Y_t    <- df_CS$gS81FpS79Y[i]
                                  gS81FpS79F_t    <- df_CS$gS81FpS79F[i]
                                  gS81FpD83Y_t    <- df_CS$gS81FpD83Y[i]
                                  gS81FpD83N_t    <- df_CS$gS81FpD83N[i]
                                  gE85KpS79Y_t    <- df_CS$gE85KpS79Y[i]
                                  gE85GpS79F_t    <- df_CS$gE85GpS79F[i]
                                  
                                  CIP_t  <- PK_mod$CIP[i]
                                  AB_t   <- PK_mod$AB[i]
                                  
                                  A_CIP_t  <- PK_mod$A_CIP[i]
                                  A_AB_t   <- PK_mod$A_AB[i]
                                  A2_AB_t  <- PK_mod$A2_AB[i]
                                  
                                  
                                  
                                  
                                  #-------------------
  ###### Mutations  #####
                                  
                                  
                                  
                              # S to GyrA or ParC #####    
                                  
                                  if(is.na(as.integer( S_t*V ))) {
                                    
                                    n_itr <- floor(S_t*V/10^9)
                                    
                                    res_t <- floor(S_t*V - n_itr*10^9)
                                
                                    
                                      GR_S_pS79Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                      GR_S_pS79F <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                      GR_S_pD83Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                      GR_S_pD83N <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                      GR_S_gS81Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                      GR_S_gS81F <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                      GR_S_gE85K <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                      GR_S_gE85G <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                      
                                    
                                    
                                  } else if (as.integer( S_t*V )>0) {
                                    
                             
                                    GR_S_pS79Y <- rbinom(1, as.integer( S_t*V ), U)
                                    GR_S_pS79F <- rbinom(1, as.integer( S_t*V ), U)
                                    GR_S_pD83Y <- rbinom(1, as.integer( S_t*V ), U)
                                    GR_S_pD83N <- rbinom(1, as.integer( S_t*V ), U)
                                    GR_S_gS81Y <- rbinom(1, as.integer( S_t*V ), U)
                                    GR_S_gS81F <- rbinom(1, as.integer( S_t*V ), U)
                                    GR_S_gE85K <- rbinom(1, as.integer( S_t*V ), U)
                                    GR_S_gE85G <- rbinom(1, as.integer( S_t*V ), U)
                                    
                                  } else{
                              
                                    GR_S_pS79Y <- 0
                                    GR_S_pS79F <- 0
                                    GR_S_pD83Y <- 0
                                    GR_S_pD83N <- 0
                                    GR_S_gS81Y <- 0
                                    GR_S_gS81F <- 0
                                    GR_S_gE85K <- 0
                                    GR_S_gE85G <- 0
                                    
                                  }
                                  
                                  
                                  ## Parc to R ####
                                  
                                  
                   
                                  #pS79Y
                                  if(is.na(as.integer( pS79Y_t*V ))) {
                                    
                                    n_itr <- floor(pS79Y_t*V/10^9)
                                    
                                    res_t <- floor(pS79Y_t*V - n_itr*10^9)
                                    
                                
                                    
                                      GR_pS79Y_gS81YpS79Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                      GR_pS79Y_gS81FpS79Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                      GR_pS79Y_gE85KpS79Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    
                                  } else if (as.integer( pS79Y_t*V )>0) {
                                    
                                    GR_pS79Y_gS81YpS79Y <- rbinom(1, as.integer( pS79Y_t*V ), U)
                                    GR_pS79Y_gS81FpS79Y <- rbinom(1, as.integer( pS79Y_t*V ), U)
                                    GR_pS79Y_gE85KpS79Y <- rbinom(1, as.integer( pS79Y_t*V ), U)
                                    
                                  } else{
                              
                                    
                                    GR_pS79Y_gS81YpS79Y <- 0
                                    GR_pS79Y_gS81FpS79Y <- 0
                                    GR_pS79Y_gE85KpS79Y <- 0
                                  }
                                  
                                  
                            
                                  #pS79F
                                  if(is.na(as.integer( pS79F_t*V ))) {
                                    
                                    n_itr <- floor(pS79F_t*V/10^9)
                                    
                                    res_t <- floor(pS79F_t*V - n_itr*10^9)
                                    
                          
                                    
                                    GR_pS79F_gS81YpS79F <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_pS79F_gS81FpS79F <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_pS79F_gE85GpS79F <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    
                                  } else if (as.integer( pS79F_t*V )>0) {
                                
                                   GR_pS79F_gS81YpS79F <- rbinom(1, as.integer( pS79F_t*V ), U)
                                   GR_pS79F_gS81FpS79F <- rbinom(1, as.integer( pS79F_t*V ), U)
                                   GR_pS79F_gE85GpS79F <- rbinom(1, as.integer( pS79F_t*V ), U)
                                    
                                  } else{
                                    
                                    
                                    GR_pS79F_gS81YpS79F <- 0
                                    GR_pS79F_gS81FpS79F <- 0
                                    GR_pS79F_gE85GpS79F <- 0
                                  }
                                  
                                
                                  
                                  #pD83Y
                                  if(is.na(as.integer( pD83Y_t*V ))) {
                                    
                                    n_itr <- floor(pD83Y_t*V/10^9)
                                    
                                    res_t <- floor(pD83Y_t*V - n_itr*10^9)
                                    
                                    
                                    
                                    GR_pD83Y_gS81FpD83Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                               
                                    
                                  } else if (as.integer( pD83Y_t*V )>0) {
                                    
                                    GR_pD83Y_gS81FpD83Y <- rbinom(1, as.integer( pD83Y_t*V ), U)
                                
                                    
                                  } else{
                                    
                                    
                                    GR_pD83Y_gS81FpD83Y <- 0
                              
                                  }
                                  
                                  
                             
                                  #pD83N
                                  if(is.na(as.integer( pD83N_t*V ))) {
                                    
                                    n_itr <- floor(pD83N_t*V/10^9)
                                    
                                    res_t <- floor(pD83N_t*V - n_itr*10^9)
                                    
                                    
                                    
                                    GR_pD83N_gS81FpD83N <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    
                                    
                                  } else if (as.integer( pD83N_t*V )>0) {
                                    
                                    GR_pD83N_gS81FpD83N <- rbinom(1, as.integer( pD83N_t*V ), U)
                                    
                                    
                                  } else{
                                    
                                    
                                    GR_pD83N_gS81FpD83N <- 0
                                    
                                  } 
                                  
                                  
                                  ## GyrA to R ####
                                  
                                  #gS81Y
                                  if(is.na(as.integer( gS81Y_t*V ))) {
                                    
                                    n_itr <- floor(gS81Y_t*V/10^9)
                                    
                                    res_t <- floor(gS81Y_t*V - n_itr*10^9)
                                    
                                    GR_gS81Y_gS81YpS79Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_gS81Y_gS81YpS79F <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                 
                                    
                                  } else if (as.integer( gS81Y_t*V )>0) {
                                    
                                    GR_gS81Y_gS81YpS79Y <- rbinom(1, as.integer( gS81Y_t*V ), U)
                                    GR_gS81Y_gS81YpS79F <- rbinom(1, as.integer( gS81Y_t*V ), U)
                               
                                    
                                  } else{
                                    
                                    
                                    GR_gS81Y_gS81YpS79Y <- 0
                                    GR_gS81Y_gS81YpS79F <- 0
                                 
                                  }
                                  
                      
                                  #gS81F
                                  if(is.na(as.integer( gS81F_t*V ))) {
                                    
                                    n_itr <- floor(gS81F_t*V/10^9)
                                    
                                    res_t <- floor(gS81F_t*V - n_itr*10^9)
                                   
                                    GR_gS81F_gS81FpS79Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_gS81F_gS81FpS79F <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_gS81F_gS81FpD83Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_gS81F_gS81FpD83N <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    
                                  } else if (as.integer( gS81F_t*V )>0) {
                                    
                                    GR_gS81F_gS81FpS79Y <- rbinom(1, as.integer( gS81F_t*V ), U)
                                    GR_gS81F_gS81FpS79F <- rbinom(1, as.integer( gS81F_t*V ), U)
                                    GR_gS81F_gS81FpD83Y <- rbinom(1, as.integer( gS81F_t*V ), U)
                                    GR_gS81F_gS81FpD83N <- rbinom(1, as.integer( gS81F_t*V ), U)
                                    
                                  } else{
                                    
                                  
                                    GR_gS81F_gS81FpS79Y <- 0
                                    GR_gS81F_gS81FpS79F <- 0
                                    GR_gS81F_gS81FpD83Y <- 0
                                    GR_gS81F_gS81FpD83N <- 0
                                  }
                                  
                           
                                  #gE85K
                                  if(is.na(as.integer( gE85K_t*V ))) {
                                    
                                    n_itr <- floor(gE85K_t*V/10^9)
                                    
                                    res_t <- floor(gE85K_t*V - n_itr*10^9)
                                    
                                    GR_gE85K_gE85KpS79Y <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                   
                                    
                                    
                                  } else if (as.integer( gE85K_t*V )>0) {
                                    
                                    GR_gE85K_gE85KpS79Y <- rbinom(1, as.integer( gE85K_t*V ), U)
                             
                                    
                                    
                                  } else{
                                    
                                    GR_gE85K_gE85KpS79Y <- 0
                         
                                    
                                  }
                                  
                           
                                  #gE85G
                                  if(is.na(as.integer( gE85G_t*V ))) {
                                    
                                    n_itr <- floor(gE85G_t*V/10^9)
                                    
                                    res_t <- floor(gE85G_t*V - n_itr*10^9)
                                    
                                    GR_gE85G_gE85GpS79F <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    
                                    
                                    
                                  } else if (as.integer( gE85G_t*V )>0) {
                                    
                                    GR_gE85G_gE85GpS79F <- rbinom(1, as.integer( gE85G_t*V ), U)
                                    
                                    
                                    
                                  } else{
                                    
                                    GR_gE85G_gE85GpS79F <- 0
                                    
                                    
                                  }
                                  

                                  # cat(paste("index =", ii, "time_step=", i,  
                                  #           "\n"), file = "mut_log", append = T)

                                  
                                  # 
                                  # cat(paste("index =", ii, "time_step=", i,  "model =", dose_reg[i_mod] ,
                                  #           ", GR_S_ParC", GR_S_ParC, ", GR_S_GyrA = ", GR_S_GyrA, ", GR_ParC_R = ", GR_ParC_R, ", GR_GyrA_R = ", GR_GyrA_R, "\n"), file = "mut_log", append = T)
                                  # 
                                  
                        
                                  
                                  
                                  ev <- eventTable(amount.units="mg", time.units="hours") %>%
                                    add.sampling(seq(0,1))  %>%
                                    mutate(# S
                                      GR_S_pS79Y = GR_S_pS79Y,
                                      GR_S_pS79F = GR_S_pS79F,
                                      GR_S_pD83Y = GR_S_pD83Y,
                                      GR_S_pD83N = GR_S_pD83N,
                                      GR_S_gS81Y = GR_S_gS81Y,
                                      GR_S_gS81F = GR_S_gS81F,
                                      GR_S_gE85K = GR_S_gE85K,
                                      GR_S_gE85G = GR_S_gE85G,
                                      #parC to R
                                      GR_pS79Y_gS81YpS79Y = GR_pS79Y_gS81YpS79Y,
                                      GR_pS79Y_gS81FpS79Y = GR_pS79Y_gS81FpS79Y,
                                      GR_pS79Y_gE85KpS79Y = GR_pS79Y_gE85KpS79Y,
                                      GR_pS79F_gS81YpS79F = GR_pS79F_gS81YpS79F,
                                      GR_pS79F_gS81FpS79F = GR_pS79F_gS81FpS79F,
                                      GR_pS79F_gE85GpS79F = GR_pS79F_gE85GpS79F,
                                      GR_pD83Y_gS81FpD83Y = GR_pD83Y_gS81FpD83Y,
                                      GR_pD83N_gS81FpD83N = GR_pD83N_gS81FpD83N,
                                      #GyrA to R
                                      GR_gS81Y_gS81YpS79Y = GR_gS81Y_gS81YpS79Y,
                                      GR_gS81Y_gS81YpS79F = GR_gS81Y_gS81YpS79F,
                                      GR_gS81F_gS81FpS79Y = GR_gS81F_gS81FpS79Y,
                                      GR_gS81F_gS81FpS79F = GR_gS81F_gS81FpS79F,
                                      GR_gS81F_gS81FpD83Y = GR_gS81F_gS81FpD83Y,
                                      GR_gS81F_gS81FpD83N = GR_gS81F_gS81FpD83N,
                                      GR_gE85K_gE85KpS79Y = GR_gE85K_gE85KpS79Y,
                                      GR_gE85G_gE85GpS79F = GR_gE85G_gE85GpS79F) %>%   
                                                                               
                                    as.tbl()
                                  
                                  
                                  
                                  t_inits <- c(S = S_t, 
                                               pS79Y = pS79Y_t, 
                                               pS79F = pS79F_t,
                                               pD83Y = pD83Y_t,
                                               pD83N = pD83N_t,
                                               
                                               gS81Y = gS81Y_t,
                                               gS81F = gS81F_t, 
                                               gE85K = gE85K_t, 
                                               gE85G = gE85G_t, 
                                               
                                               gS81YpS79Y = gS81YpS79Y_t,
                                               gS81YpS79F = gS81YpS79F_t,
                                               gS81FpS79Y = gS81FpS79Y_t,
                                               gS81FpS79F = gS81FpS79F_t,
                                               gS81FpD83Y = gS81FpD83Y_t,
                                               gS81FpD83N = gS81FpD83N_t,
                                               gE85KpS79Y = gE85KpS79Y_t,
                                               gE85GpS79F = gE85GpS79F_t,
                                               A_CIP = A_CIP_t, CIP = CIP_t, A_AB = A_AB_t,  AB = AB_t);
                                  
                                  # cat(paste("index =", ii, "time_step=", i,   "\n"), file = "t_inits_log", append = T)

                                  
                                  # cat(paste("index =", ii, "time_step=", i,  "modlel =", dose_reg[i_mod] ,
                                  #           ", tinits, S = ",  t_inits[1], ", ParC = ",  t_inits[2], ", GyrA = ",  t_inits[3], ", R = ",  t_inits[4],
                                  #           ", A_CIP = ",  t_inits[5], ", CIP = ",  t_inits[6], ", A_AB = ",  t_inits[7], ", AB = ",  t_inits[8], "\n"), file = "t_inits_log", append = T)
                                  # 
                                  
                                  
                                  x_CS   <- as.data.frame(CS_mod$run(theta, ev,  t_inits)) %>%
                                    mutate(time = time + i-1)  %>% 
                                    select(time , S , 
                                           pS79Y,
                                           pS79F,
                                           pD83Y,
                                           pD83N,
                                           
                                           gS81Y,
                                           gS81F,
                                           gE85K,
                                           gE85G,
                                           
                                           gS81YpS79Y,
                                           gS81YpS79F,
                                           gS81FpS79Y,
                                           gS81FpS79F,
                                           gS81FpD83Y,
                                           gS81FpD83N,
                                           gE85KpS79Y,
                                           gE85GpS79F,
                                         
                                           A_CIP, CIP , A_AB, A2_AB, AB);
                                  
                                  
                                  df_CS[i:(i+1),] <- x_CS
                                  
                                  
                                  # 
                                  # cat(paste("index =", ii, "time_step=", i,  "model =", dose_reg[i_mod] ,
                                  #           ", time = ",  df_CS$time[1], ", S = ",  df_CS$S[1], ", ParC = ",  df_CS$ParC[1], ", GyrA = ",  df_CS$GyrA[1], ", R = ",  df_CS$R[1],
                                  #           ", CIP = ",  df_CS$CIP[1], ", AB = ",  df_CS$AB[1], "\n"), file = "mid_2_log", append = T)
                                  # 
                                  
                                  
                                  
                                }
                                
                                
                                
                                df_CS$model <- dose_reg[i_mod] 
                                
                                df_model_CS <- df_model_CS %>%
                                  bind_rows(df_CS)
                                
                              }
                              
                              
                              
                              
                              df_model_CS$index <- ii
                              
                              # 
                              d_time <- round( Sys.time()- i_time )
                              
                              cat(paste("index =", ii,
                                        ", S =", round(min(df_model_CS$S, na.rm = T)),", time = ",  d_time , "\n"), file = "out_log", append = T)


                              #length(df_CS$time
                              
                              return(df_model_CS)
                              
                              #full_CS_df[(n_obs*(ii-1)),] <- df_CS
                              cat(paste("index =", ii, "\n"), file = "out_return_log", append = T)
                              
                            }
    
    # cat(paste("index =", ii,
    #           ", S =", round(min(df_model_CS$S, na.rm = T)),", time = ",  d_time , "\n"), file = "out_2_log", append = T)
    
    
  }
  
  print("Model done")
  
  #print(head(df_full_CS))
  
  mean_dat <-  df_full_CS %>% 
    select(time , S , pS79Y,
           pS79F,
           pD83Y,
           pD83N,
           gS81Y,
           gS81F,
           gE85K,
           gE85G,
           gS81YpS79Y,
           gS81YpS79F,
           gS81FpS79Y,
           gS81FpS79F,
           gS81FpD83Y,
           gS81FpD83N,
           gE85KpS79Y,
           gE85GpS79F, A_CIP, CIP , A_AB, AB, index, model) %>% 
    gather(value = "CFU", key = "Population", - time, -CIP, -A_CIP, -AB, -A_AB, -index, -model) %>% 
    group_by(time, model, index) %>%
    mutate(total = sum(CFU)) %>%
    ungroup() %>%
    mutate(CFU_ratio = CFU/total) %>%
    mutate(B_pop = ifelse(Population == "S", "WT",
                          ifelse(grepl("g", Population, ignore.case = F) & grepl("p", Population, ignore.case = F), "R",
                                 ifelse(grepl("g", Population, ignore.case = F), "GyrA","ParC")))) %>%
   ungroup() %>%
    group_by(model, index, time) %>% 
    mutate(CFU_total = sum(CFU, na.rm = T)) %>%  #calculate  total CFU per realization, time point and dosing regimen
    ungroup() %>% 
    group_by(time, model, Population) %>% 
    
    mutate(CFU_MEDIAN = median(CFU, na.rm = T),
           CFU_SD   = sd(CFU, na.rm = T), 
           CFU_95   = quantile(CFU, .95, na.rm = T),
           CFU_05   = quantile(CFU, .05, na.rm = T),
           mean_ratio = mean(CFU_ratio, na.rm = T)) %>% 
    ungroup() %>% 
    group_by( Population, model, index) %>% 
    mutate(T_R = min(ifelse(CFU >= 10^eS0, #S0,
                            time, NA), na.rm = T)) %>% 
    ungroup() %>% 
    group_by(Population, model) %>% 

    ungroup() %>% 
    group_by(Population, model) %>%
    mutate(End_CFU = ifelse(time == ST+T_start, CFU, NA),
           End_T_CFU = ifelse(time == ST+T_start, CFU_total, NA),
           day_id  = ifelse(is.wholenumber(time/24), index, 0),
           Day_CFU = ifelse(is.wholenumber(time/24), CFU, NA) ,
           Day_T_CFU = ifelse(is.wholenumber(time/24), CFU_total, NA),
           mean_ratio = mean(CFU_ratio, na.rm = T),
           CFU_T_MEDIAN = median(CFU_total, na.rm = T),
           CFU_T_SD   = sd(CFU_total, na.rm = T), 
           CFU_T_95   = quantile(CFU_total, .95, na.rm = T),
           CFU_T_05   = quantile(CFU_total, .05, na.rm = T),) %>% 
    
    mutate(R_Dev = sum(End_CFU >= 10^eS0, na.rm = T),
           R_T_Dev = sum(End_T_CFU >= 10^eS0, na.rm = T),
           R_Day_Dev = sum(Day_CFU >= 10^eS0, na.rm = T),
           R_T_Day_Dev = sum(Day_T_CFU >= 10^eS0, na.rm = T)) %>%
    ungroup() %>% 
    group_by(time, model, B_pop, index) %>% 
    mutate(B_CFU = sum(CFU, na.rm = T),
           B_pop_id = 1:n()) %>% 
    ungroup() %>% 
    group_by(time, model, B_pop) %>% 
           
    mutate(B_CFU_MEDIAN = median(B_CFU, na.rm = T),
           B_CFU_SD   = sd(B_CFU, na.rm = T), 
           B_CFU_95   = quantile(B_CFU, .95, na.rm = T),
           B_CFU_05   = quantile(B_CFU, .05, na.rm = T)) %>% 
    ungroup() %>% 
    group_by(B_pop, model) %>%
   
    mutate(B_End_CFU = ifelse(time == ST+T_start, B_CFU, NA),
           B_Day_CFU = ifelse(is.wholenumber(time/24), B_CFU, NA)) %>% 
    mutate(B_R_Dev = sum(B_End_CFU >= 10^eS0 & B_pop_id == 1, na.rm = T),
           
           B_R_Day_Dev = sum(B_Day_CFU >= 10^eS0 & B_pop_id == 1, na.rm = T)) %>%
    ungroup() %>% 
    group_by(time, model, B_pop, index) %>% 
    mutate(B_CFU = sum(CFU, na.rm = T),
           B_pop_id = 1:n()) %>% 
    ungroup() %>% 
    group_by(time, model, B_pop) %>% 
           
    mutate(B_CFU_MEDIAN = median(B_CFU, na.rm = T),
           B_CFU_SD   = sd(B_CFU, na.rm = T), 
           B_CFU_95   = quantile(B_CFU, .95, na.rm = T),
           B_CFU_05   = quantile(B_CFU, .05, na.rm = T)) %>% 
    ungroup() %>% 
    group_by(B_pop, model) %>%
   
    mutate(B_End_CFU = ifelse(time == ST+T_start, B_CFU, NA),
           B_Day_CFU = ifelse(is.wholenumber(time/24), B_CFU, NA)) %>% 
    mutate(B_R_Dev = sum(B_End_CFU >= 10^eS0 & B_pop_id == 1, na.rm = T),
           
           B_R_Day_Dev = sum(B_Day_CFU >= 10^eS0 & B_pop_id == 1, na.rm = T)) %>%
    ungroup() %>% 
    
    # tot R
    mutate(R_pop = ifelse(Population == "S", "WT", "R")) %>% 
    group_by(time, model, index, R_pop) %>% 
    mutate(R_CFU = sum(CFU, na.rm = T),
           R_pop_id = 1:n()) %>% 
    ungroup() %>% 
    group_by(time, model, R_pop) %>% 
    
    mutate(R_CFU_MEDIAN = median(R_CFU, na.rm = T),
           R_CFU_SD   = sd(R_CFU, na.rm = T), 
           R_CFU_95   = quantile(R_CFU, .95, na.rm = T),
           R_CFU_05   = quantile(R_CFU, .05, na.rm = T)) %>% 
    ungroup() %>% 
    group_by(R_pop, model) %>%
    
    mutate(R_End_CFU = ifelse(time == ST+T_start, R_CFU, NA),
           R_Day_CFU = ifelse(is.wholenumber(time/24), R_CFU, NA)) %>% 
    mutate(R_R_Dev = sum(R_End_CFU >= 10^eS0 & R_pop_id == 1, na.rm = T),
           
           R_R_Day_Dev = sum(R_Day_CFU >= 10^eS0 & R_pop_id == 1, na.rm = T)) %>%
    ungroup() %>% 
    
  
    distinct(Population, time, model, day_id, .keep_all = T) %>% 
    select(time, CIP, AB, Population, model, index, day_id, B_pop, R_pop,
           CFU_MEDIAN, CFU_SD, CFU_95, CFU_05, mean_ratio , 
           Day_CFU, Day_T_CFU, CFU_T_MEDIAN, CFU_T_SD, CFU_T_95, CFU_T_05, mean_ratio , 
           End_CFU, End_T_CFU, R_Dev, R_T_Dev, R_Day_Dev, R_T_Day_Dev,
           B_CFU_MEDIAN, B_CFU_SD, B_CFU_95, B_CFU_05, 
           B_Day_CFU,  
           B_End_CFU, B_R_Dev,  B_R_Day_Dev, 
           R_CFU_MEDIAN, R_CFU_SD, R_CFU_95, R_CFU_05, 
           R_Day_CFU,  
           R_End_CFU, R_R_Dev,  R_R_Day_Dev)%>% 
    filter(!is.na(model))
  
  

  
  
  
  run_t   <-  Sys.time() - start_t 
  print(run_t)
  
  # if(OUT == T){
  #   write.csv( mean_dat, paste0("Results/", Sys.Date(), "ID_", sim_ID, "_CS_model_$S_output.csv"))
  # }
  # 
  
  #return(all_res) 
  return(mean_dat)
}
