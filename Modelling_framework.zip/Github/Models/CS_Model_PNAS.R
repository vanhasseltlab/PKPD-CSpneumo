#################################
# #### CS PKPD model framework ##
## S.pneumoniae D39 adaptation ##  
####      FQ resistant         ##
##  Combination treatment for  ##    
##    CIP + ERY. LNZ or PEN    ##
##      With interaction       ##
#         Model script         ##
##    Written by Linda Aulin   ##
#################################



CS_model <- function( p_Bmax = 10, OUT = F, sim_ID = "", DRUG , CSS_CIP = 1, CSS_AB = 1, DOSE_scale = "CL", p_KG_S, p_KG_ParC, p_KG_GyrA, p_KG_R, p_GMIN_CIP, p_HILL_CIP, p_GMIN_AB, p_HILL_AB, p_INTER, p_MIC_CIP_S, p_MIC_CIP_ParC, p_MIC_CIP_GyrA, p_MIC_CIP_R, p_MIC_AB_S, p_MIC_AB_ParC, p_MIC_AB_GyrA , p_MIC_AB_R, p_V  = 100, p_ke = 0, p_u  = 1.4*10^-8, eS0  = 9, n = 10, DT = 1, ST = 24) {
  
  start_t <- Sys.time()
  
  is.wholenumber <- function(x, tol = .Machine$double.eps^0.5)  abs(x - round(x)) < tol  # need to check for whole numbers later
  
  
  ##############
  ## PK Model ##
  ##############
  

  #Covariates:
  BW   <- 70 #KG
  CrCL <- 75
  
  TAU  <- 12 #h
  T_start <- 0 #h
  
  
  ##################################
  ########## CIP parameters ########
  ##################################
  pCIP_CL <- 8+0.21*CrCL
  SDCIP_CL <- 0.186   #CV
  
  # CIP_CL <- pCIP_CL*exp(qnorm(0, SDCIP_CL, p = 0.95))
  CIP_CL  <- pCIP_CL
  
  pCIP_V  <-22.7+0.86*BW
  SDCIP_V <- 0.14     
  
  #CIP_V <- pCIP_V*qnorm(0 ,SDCIP_V , p = 0.95)
  CIP_V <- pCIP_V
  
  CIP_ke <- CIP_CL/CIP_V 
  CIP_fu <- 0.7 #Zhanel et al (review)
  
  
  
  MIC_CIP_S = p_MIC_CIP_S
 
  if(DOSE_scale == "CL" ){
   
     DOSE_CIP <- 500
    
  }else{ DOSE_CIP = CSS_CIP*MIC_CIP_S*CIP_CL*TAU/CIP_fu }


  
  PK_inits_1cmt <- c(A_CIP = 0, A_AB = 0);
  
  #CIP model based on Cios et al. 1-comp CIP elderly patients
  
  if(DRUG == "CIP") {
    
    #CIP_V <- pCIP_V*qnorm(0 ,SDCIP_V , p = 0.95)
    AB_V <- pCIP_V
    
    AB_ke <- CIP_CL/CIP_V 
    AB_fu <- 0.7 #Zhanel et al (review)
    
    
    PK_mod_CIP<- RxODE({
      
      
      d/dt(A_CIP) = -CIP_ke*A_CIP
      d/dt(A_AB) =  0
      
      CIP = A_CIP/CIP_V*CIP_fu
      AB  = A_AB
      
    });
    
    PK_theta_CIP <- c(CIP_V = CIP_V, 
                      CIP_ke= CIP_ke,
                      CIP_fu = CIP_fu ) #MIC if sensitive WT (S)) # PK elimination rate constant)
    
    ev_PK_CIP <- eventTable(amount.units="mg", time.units="hours") %>%
      add.dosing(start.time = T_start, dosing.to = 1, dose=DOSE_CIP, nbr.doses = 28,  dosing.interval=TAU) %>%
      add.sampling(seq(0,ST+T_start,DT))  %>%
      as.tbl()
    
    
    
    PK_sim    <- as.data.frame(PK_mod_CIP$run(PK_theta_CIP ,ev_PK_CIP ,     PK_inits_1cmt));
    
  }
  
  if(DRUG == "ERY"){
    
    ################################################
    ##### ERY , no IIV avaliable ###################
    ##ERY model based on Nielsen et al 2-comp model#
    ################################################
    
    #parameters
    AB_V  <- 34.9 #L
    AB_CL <-22.8
    AB_V2 <- 20.7
    AB_Q  <- 16.9
    AB_fu <- 0.16
    
    AB_ke  = AB_CL/AB_V
    AB_k12 = AB_Q/AB_V
    AB_k21 = AB_Q/AB_V2
    
    
    MIC_AB_S  = p_MIC_AB_S  #MIC if sensitive WT (S)
    
    if(DOSE_scale == "CL" ){
      
      DOSE_ERY = 600
      
    }else{  DOSE_ERY = CSS_AB*MIC_AB_S*AB_CL*TAU/AB_fu }
    
    

   
    
    PK_mod_ERY<- RxODE({
      
      
      d/dt(A_CIP) =  -CIP_ke*A_CIP
      d/dt(A_AB) =   -AB_ke*A_AB   - AB_k12*A_AB + AB_k21*A2_AB
      d/dt(A2_AB) =   AB_k12*A_AB - AB_k21*A2_AB
      
      CIP = A_CIP/CIP_V*CIP_fu
      AB  = A_AB/AB_V*AB_fu
      
    });
    
    
    
    
    PK_theta_ERY <- c(CIP_V  = CIP_V, 
                      CIP_ke = CIP_ke,
                      CIP_fu = CIP_fu,
                      AB_V   = AB_V,
                      AB_V2  = AB_V2,
                      AB_fu  = AB_fu,
                      AB_ke  = AB_ke ,
                      AB_k12 = AB_k12,
                      AB_k21 = AB_k21#,
                      
                      #MIC_CIP_S = p_MIC_CIP_S, #CIP MIC if resistant  (R)  (gryA + parC)
                      #MIC_AB_S  = p_MIC_AB_S  #MIC if sensitive WT (S)
    ) 
    
    
    ev_PK_ERY <- eventTable(amount.units="mg", time.units="hours") %>%
      add.dosing(start.time = T_start, dosing.to = 1, dose=DOSE_CIP, nbr.doses = 28,  dosing.interval=TAU) %>%
      add.dosing(start.time = T_start, dosing.to = 2, dose=DOSE_ERY, nbr.doses = 28,  dosing.interval=TAU) %>%
      add.sampling(seq(0,ST+T_start,DT))  %>%
      as.tbl()
    
    PK_inits_2cmt <- c(A_CIP = 0, A1_AB = 0,  A2_AB = 0);
    
    
    PK_sim    <- as.data.frame(PK_mod_ERY$run(PK_theta_ERY ,ev_PK_ERY ,     PK_inits_2cmt));
    
  }
  
  if(DRUG == "PEN"){
    
    #########################################
    #### PEN parameters ####################
    ########################################
    
    
    ### 1-CMT model by Komatsu et al
    pPEN_CL <- 0.21*CrCL
    SDPEN_CL <- 0.0835
    
    AB_CL <- pPEN_CL*exp(qnorm(0 , SDPEN_CL , p = 0.95))
    
    
    pPEN_V  <- 28.9
    SDPEN_V <- 0.104
    
    AB_V <- pPEN_V*exp(qnorm(0 , SDPEN_V , p = 0.95))
    
    
    AB_fu <- 0.40
    
    AB_ke  = AB_CL/AB_V
    
    
    MIC_AB_S  = p_MIC_AB_S  #MIC if sensitive WT (S)
    
    if(DOSE_scale == "CL" ){
      
      DOSE_PEN = 3000
      
    }else{  DOSE_PEN = CSS_AB*MIC_AB_S*AB_CL*TAU/AB_fu }

    
    
    
    
    #PEN model based 1-CMT model by Komatsu et al
    
    PK_mod_PEN<- RxODE({
      
      
      d/dt(A_CIP) =  -CIP_ke*A_CIP
      
      d/dt(A_AB) =  -AB_ke*A_AB
      
      CIP = A_CIP/CIP_V*CIP_fu
      AB  = A_AB/AB_V*AB_fu
      
      
    });
    
    
    PK_theta_PEN <- c(CIP_V  = CIP_V, 
                      CIP_ke = CIP_ke,
                      CIP_fu = CIP_fu,
                      
                      AB_V   = AB_V,
                      AB_fu  = AB_fu,
                      AB_ke  = AB_ke 
    )
    
    ev_PK_PEN <- eventTable(amount.units="mg", time.units="hours") %>%
      add.dosing(start.time = T_start, dosing.to = 1, dose=DOSE_CIP, nbr.doses = 28,  dosing.interval=TAU) %>%
      add.dosing(start.time = T_start, dosing.to = 2, dose=DOSE_PEN, nbr.doses = 28,  dosing.interval=TAU) %>%
      add.sampling(seq(0,ST+T_start,DT))  %>%
      as.tbl()
    
    PK_sim    <- as.data.frame(PK_mod_PEN$run(PK_theta_PEN ,ev_PK_PEN,    PK_inits_1cmt));
    
  }
  
  if(DRUG == "LNZ"){
    
    pLNZ_CL  <- 2.85*(CrCL/60.9)^0.618
    SDLNZ_CL <- 0.352 #CV
    
    AB_CL <- pLNZ_CL*exp(qnorm(0 , SDLNZ_CL , p = 0.95))
    #LNZ_CL <- pLNZ_CL
    
    pLNZ_V  <- 33.6*(BW/57.9)
    SDLNZ_V <- 0.308
    AB_V   <- pLNZ_V*exp(qnorm(0, SDLNZ_V, p = 0.95)) 
    #LNZ_V   <- pLNZ_V
    
    AB_fu <- 0.815  #Kratzer et al
    
    AB_ke = AB_CL/AB_V
    
    MIC_AB_S  = p_MIC_AB_S  #MIC if sensitive WT (S)
    #DOSE_LNZ = MIC_AB_S*LNZ_V*1
    #DOSE_LNZ= MIC_AB_S*AB_CL*TAU/AB_fu
    if(DOSE_scale == "CL" ){
      
      DOSE_LNZ = 600
      
    }else{  DOSE_LNZ = CSS_AB*MIC_AB_S*AB_CL*TAU/AB_fu }
    
    
    
    #LNZ model based on Sasaki et al 1-comp model
    PK_mod_LNZ<- RxODE({
      
      
      d/dt(A_CIP) = -CIP_ke*A_CIP
      d/dt(A_AB) =  -AB_ke*A_AB
      
      CIP = A_CIP/CIP_V*CIP_fu
      AB  = A_AB/AB_V*AB_fu
      
    });
    
    
    PK_theta_LNZ<- c( CIP_V   = CIP_V, 
                      CIP_ke = CIP_ke,
                      CIP_fu = CIP_fu,
                      AB_V   = AB_V, 
                      AB_ke  = AB_ke,
                      AB_fu  = AB_fu
    ) 
    
    
    ev_PK_LNZ <- eventTable(amount.units="mg", time.units="hours") %>%
      add.dosing(start.time = T_start, dosing.to = 1, dose=DOSE_CIP, nbr.doses = 28,  dosing.interval=TAU) %>%
      add.dosing(start.time = T_start, dosing.to = 2, dose=DOSE_LNZ, nbr.doses = 28,  dosing.interval=TAU) %>%
      add.sampling(seq(0,ST+T_start,DT))  %>%
      as.tbl()
    
    
    PK_sim    <- as.data.frame(PK_mod_LNZ$run(PK_theta_LNZ ,ev_PK_LNZ ,  PK_inits_1cmt));
    
    
  }
  
  print("PK OK")
  
  PK_model_list <- list(PK_sim)
  
  dose_reg <- c(DRUG)
  
  #print(names(PK_model_list))
  
  
  
  
  
  ##############
  ## PD Model ##
  ##############
  
  
  ##For 1COMP models
  
  if(DRUG != "ERY"){
    
    
    #ODE
    CS_mod<- RxODE({
      
      
      
      
      
      ####### PK######
      
      d/dt(A_CIP)  = -CIP_ke*A_CIP
      d/dt(A_AB)   = -AB_ke*A_AB
      
      #AB conc
      CIP = A_CIP/CIP_V*CIP_fu
      AB  =  A_AB/AB_V*AB_fu
      
      
      
      
      KG_S    = KG_D39   #Yu et al
      KG_ParC = KG_D39*abs_KG_ParC/abs_KG_S
      KG_GyrA = KG_D39*abs_KG_GyrA/abs_KG_S
      KG_R    = KG_D39*abs_KG_R/abs_KG_S
      
     
      
      #Sensitive wild type
      
      E_AB_S  = (1 - Gmin_AB/KG_S)*(AB/MIC_AB_S)^HILL_AB/((AB/MIC_AB_S)^HILL_AB - (Gmin_AB/KG_S))
      E_CIP_S = (1 - Gmin_CIP/KG_S)*(CIP/MIC_CIP_S)^HILL_CIP/((CIP/MIC_CIP_S)^HILL_CIP - (Gmin_CIP/KG_S))
      
      E_INTER_S = E_AB_S/(-(Gmin_AB/KG_S -1))*E_CIP_S/(-(Gmin_CIP/KG_S -1))*INTER*((-(Gmin_AB/KG_S -1))+(-(Gmin_CIP/KG_S -1)))
      
      d/dt(S) = S*(1-((S+ParC+GyrA+R)/10^Bmax))*KG_S*(1 - (E_AB_S + E_CIP_S + E_INTER_S )) -
                                                           
        GR_S_ParC/V -
        GR_S_GyrA/V -
        ke*S
      
      
      # Single resistant mutants with mutation in ParC
      E_AB_ParC  = (1 - Gmin_AB/KG_ParC)*(AB/MIC_AB_ParC)^HILL_AB/((AB/MIC_AB_ParC)^HILL_AB - (Gmin_AB/KG_ParC))
      E_CIP_ParC = (1 - Gmin_CIP/KG_ParC)*(CIP/(MIC_CIP_ParC))^HILL_CIP/((CIP/(MIC_CIP_ParC))^HILL_CIP - (Gmin_CIP/KG_ParC))
      E_INTER_ParC = E_AB_ParC/(-(Gmin_AB/KG_ParC -1))*E_CIP_ParC/(-(Gmin_CIP/KG_ParC -1))*INTER*((-(Gmin_AB/KG_ParC -1))+(-(Gmin_CIP/KG_ParC -1)))

      d/dt(ParC) = ParC*(1-((S+ParC+GyrA+R)/10^Bmax))*KG_ParC*(1- (E_AB_ParC + E_CIP_ParC + E_INTER_ParC)) +

                                                                 
        GR_S_ParC/V -
        GR_ParC_R/V -
        ke*ParC

      # 
      # Single resistant mutants with mutaion in GyrA
      E_AB_GyrA = (1 - Gmin_AB/KG_GyrA)*(AB/MIC_AB_GyrA)^HILL_AB/((AB/MIC_AB_GyrA)^HILL_AB - (Gmin_AB/KG_GyrA))
      E_CIP_GyrA = (1 - Gmin_CIP/KG_GyrA)*(CIP/(MIC_CIP_GyrA))^HILL_CIP/((CIP/(MIC_CIP_GyrA))^HILL_CIP - (Gmin_CIP/KG_GyrA))
      E_INTER_GyrA = E_AB_GyrA/(-(Gmin_AB/KG_GyrA -1))*E_CIP_GyrA/(-(Gmin_CIP/KG_GyrA -1))*INTER*((-(Gmin_AB/KG_GyrA -1))+(-(Gmin_CIP/KG_GyrA -1)))

      d/dt(GyrA) = GyrA*(1-((S+ParC+GyrA+R)/10^Bmax))*KG_GyrA*(1- (E_AB_GyrA +  E_CIP_GyrA  + E_INTER_GyrA)) +


        GR_S_GyrA/V -
        GR_GyrA_R/V -
        ke*GyrA


      # Single resistant mutants to antibiotic B
      E_AB_R  = (1 - Gmin_AB/KG_R)*(AB/(MIC_AB_R))^HILL_AB/((AB/(MIC_AB_R))^HILL_AB - (Gmin_AB/KG_R))
      E_CIP_R = (1 - Gmin_CIP/KG_R)*(CIP/MIC_CIP_R)^HILL_CIP/((CIP/MIC_CIP_R)^HILL_CIP - (Gmin_CIP/KG_R))
      E_INTER_R = E_AB_R/(-(Gmin_AB/KG_R-1))*E_CIP_R/(-(Gmin_CIP/KG_R -1))*INTER*((-(Gmin_AB/KG_R-1))+(-(Gmin_CIP/KG_R -1)))

      d/dt(R) = R*(1-((S+ParC+GyrA+R)/10^Bmax))*KG_R*(1 - (E_AB_R + E_CIP_R + E_INTER_R)) +

        GR_ParC_R/V +
        GR_GyrA_R/V -
        ke*R

      
      
      
    });
    
    print("PD model conctructed")
    
    S0  <- 10^eS0
    U   <- p_u
    
    V   <- p_V
    
    theta <- c( Bmax = p_Bmax,    # maximum carrying capacity 
                abs_KG_S     = p_KG_S,    # maximal net growth S
                abs_KG_ParC  = p_KG_ParC,    # maximal net growth I
                abs_KG_GyrA  = p_KG_GyrA,    # maximal net growth I
                abs_KG_R     = p_KG_R,    # maximal net growth R
                KG_D39       = log(2)/(54/60), #D39
                
               
                
                Gmin_CIP = p_GMIN_CIP,
                HILL_CIP = p_HILL_CIP,
                
                Gmin_AB  = p_GMIN_AB,
                HILL_AB  = p_HILL_AB,
                
                INTER    = p_INTER, 
                
                MIC_CIP_S = p_MIC_CIP_S, #CIP MIC if sensitive WT (S)
                MIC_CIP_ParC = p_MIC_CIP_ParC, #CIP MIC if intermediate resistant (I) (parC)
                MIC_CIP_GyrA = p_MIC_CIP_GyrA, #CIP MIC if intermediate resistant (I) (gyrA)
                MIC_CIP_R = p_MIC_CIP_R, #CIP MIC if resistant  (R)  (gryA + parC)
                MIC_AB_S  = p_MIC_AB_S,  #MIC if sensitive WT (S)
                MIC_AB_ParC  = p_MIC_AB_ParC,  #MIC if intermediate resistant (I) (parC)
                MIC_AB_GyrA  = p_MIC_AB_GyrA,  #MIC if intermediate resistant (I) (gyrA)
                MIC_AB_R  = p_MIC_AB_R  , #MIC if resistant (R) (gyrA + parC)
                
                V     = p_V, 
                ke    = p_ke,
                CIP_ke = CIP_ke,
                CIP_V  = CIP_V,
                CIP_fu = CIP_fu,
                AB_ke  = AB_ke,
                AB_V   = AB_V,
                AB_fu = AB_fu)    # PK elimination rate constant))
    
    #n = 100
    
    print("theta list done")
    
    
    
    
    #n_obs <- length(PK_1day$time)
    n_obs  <- ST*DT+1
    n_models <- length(PK_model_list)
    
    print("starting paralleisation")
    df_full_CS <-  foreach( ii = 1:n, .combine = "rbind", 
                            .packages = c("RxODE", "dplyr", "ggplot2", "tidyr", "patchwork"),
                            
                            .inorder = F,
                            .options.RNG = 123) %dorng%  {
                              
                              #cat(paste("in index =", ii, "\n"), file = "start_log", append = T)
                              
                              i_time <- Sys.time() 
                              
                              df_model_CS <- data.frame(time  = NA,
                                                        S     = NA,
                                                        ParC  = NA,
                                                        R     = NA,
                                                        GyrA  = NA,
                                                        A_CIP = NA,
                                                        CIP   = NA,
                                                        A_AB  = NA,
                                                        AB    = NA,
                                                        model = NA)
                              
                              for(i_mod in 1:length(PK_model_list)) {
                                #   #   
                                PK_mod = PK_model_list[[i_mod]]
                                #print(PK_mod)
                                
                                
                                df_CS <- data.frame(time     = rep(x = NA, times = n_obs),
                                                    S        = rep(x = NA, times = n_obs),
                                                    ParC     = rep(x = NA, times = n_obs),
                                                    GyrA     = rep(x = NA, times = n_obs),
                                                    R        = rep(x = NA, times = n_obs),
                                                    A_CIP    = rep(x = NA, times = n_obs),
                                                    CIP      = rep(x = NA, times = n_obs),
                                                    A_AB     = rep(x = NA, times = n_obs),
                                                    AB       = rep(x = NA, times = n_obs))
                                
                                
                                
                                
                                
                                df_CS[1,] <- data.frame(time = 0, S = 10^eS0, ParC = 0, GyrA = 0, R = 0, 
                                                        A_CIP = PK_mod$A_CIP[1], CIP = PK_mod$CIP[1], 
                                                        A_AB = PK_mod$A_AB[1], AB = PK_mod$AB[1]);
                                
                                
                                # cat(paste("index =", ii, "modlel =", dose_reg[i_mod] ,
                                #           ", time = ",  df_CS$time[1], ", S = ",  df_CS$S[1], ", ParC = ",  df_CS$ParC[1],", GyrA = ",  df_CS$GyrA[1], ", R = ",  df_CS$R[1],
                                #           ", CIP = ",  df_CS$CIP[1], ", AB = ",  df_CS$AB[1], "\n"), file = "start_log", append = T)
                                # 
                                
                                V = p_V
                                #########
                                for (i in 1:(ST*DT)) {
                                  
                                  #Previous time points
                                  
                                  S_t    <- df_CS$S[i]
                                  ParC_t <- df_CS$ParC[i]
                                  GyrA_t <- df_CS$GyrA[i]
                                  R_t    <- df_CS$R[i]
                                  
                                  CIP_t  <- PK_mod$CIP[i]
                                  AB_t   <- PK_mod$AB[i]
                                  
                                  A_CIP_t  <- PK_mod$A_CIP[i]
                                  A_AB_t   <- PK_mod$A_AB[i]
                                  
                                  
                                  
                                  
                                  #-------------------
                                  # Mutations
                                  
                                  
                                  
                                  
                                  if(is.na(as.integer( S_t*V ))) {
                                    
                                    n_itr <- floor(S_t*V/10^9)
                                    
                                    res_t <- floor(S_t*V - n_itr*10^9)
                                    
                                    GR_S_ParC  <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_S_GyrA  <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    
                                    
                                  } else if (as.integer( S_t*V )>0) {
                                    
                                    GR_S_ParC    <- rbinom(1, as.integer( S_t*V ), U)
                                    GR_S_GyrA    <- rbinom(1, as.integer( S_t*V ), U)
                                    
                                  } else{
                                    GR_S_ParC     <- 0
                                    GR_S_GyrA     <- 0
                                  }
                                  
                                  
                                  
                                  
                                  
                                  
                                  if(is.na(as.integer( ParC_t*V ))) {
                                    
                                    n_itr <- floor(ParC_t*V/10^9)
                                    
                                    res_t <- floor(ParC_t*V - n_itr*10^9)
                                    
                                    GR_ParC_R  <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    
                                    
                                  } else if (as.integer( ParC_t*V )>0) {
                                    
                                    GR_ParC_R   <- rbinom(1, as.integer( ParC_t*V ), U)
                                    
                                  } else{
                                    GR_ParC_R   <- 0
                                  }
                                  
                                  
                                  
                                  if(is.na(as.integer( GyrA_t*V ))) {
                                    
                                    n_itr <- floor(GyrA_t*V/10^9)
                                    
                                    res_t <- floor(GyrA_t*V - n_itr*10^9)
                                    
                                    GR_GyrA_R  <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    
                                    
                                  } else if (as.integer( GyrA_t*V )>0) {
                                    
                                    GR_GyrA_R   <- rbinom(1, as.integer( GyrA_t*V ), U)
                                    
                                  } else{
                                    GR_GyrA_R   <- 0
                                  }
                                  
                                  
                                  
                                  
                                  # cat(paste("index =", ii, "time_step=", i,  "model =", dose_reg[i_mod] ,
                                  #           ", GR_S_ParC", GR_S_ParC, ", GR_S_GyrA = ", GR_S_GyrA, ", GR_ParC_R = ", GR_ParC_R, ", GR_GyrA_R = ", GR_GyrA_R, "\n"), file = "mut_log", append = T)
                                  # 
                                  
                                  
                                  ev <- eventTable(amount.units="mg", time.units="hours") %>%
                                    add.sampling(seq(0,1))  %>%
                                    mutate(GR_S_ParC  = GR_S_ParC,
                                           GR_S_GyrA  = GR_S_GyrA,
                                           GR_ParC_R  = GR_ParC_R,
                                           GR_GyrA_R  = GR_GyrA_R) %>% 
                                    as.tbl()
                                  
                                  
                                  
                                  t_inits <- c(S = S_t, ParC = ParC_t, GyrA = GyrA_t, R = R_t,
                                               A_CIP = A_CIP_t, CIP = CIP_t, A_AB = A_AB_t,  AB = AB_t);
                                  
                                  # cat(paste("index =", ii, "time_step=", i,  "modlel =", dose_reg[i_mod] ,
                                  #           ", tinits, S = ",  t_inits[1], ", ParC = ",  t_inits[2], ", GyrA = ",  t_inits[3], ", R = ",  t_inits[4],
                                  #           ", A_CIP = ",  t_inits[5], ", CIP = ",  t_inits[6], ", A_AB = ",  t_inits[7], ", AB = ",  t_inits[8], "\n"), file = "t_inits_log", append = T)
                                  # 
                                  
                                  
                                  x_CS   <- as.data.frame(CS_mod$run(theta, ev,  t_inits)) %>%
                                    mutate(time = time + i-1)  %>% 
                                    select(time , S , ParC, GyrA, R ,A_CIP, CIP , A_AB, AB);
                                  
                                  
                                  df_CS[i:(i+1),] <- x_CS
                                  
                                  
                                  
                                  # cat(paste("index =", ii, "time_step=", i,  "modlel =", dose_reg[i_mod] ,
                                  #           ", time = ",  df_CS$time[1], ", S = ",  df_CS$S[1], ", ParC = ",  df_CS$ParC[1], ", GyrA = ",  df_CS$GyrA[1], ", R = ",  df_CS$R[1],
                                  #           ", CIP = ",  df_CS$CIP[1], ", AB = ",  df_CS$AB[1], "\n"), file = "mid_2_log", append = T)
                                  # 
                                  
                                  
                                  
                                }
                                
                                
                                
                                df_CS$model <- dose_reg[i_mod] 
                                
                                df_model_CS <- df_model_CS %>%
                                  bind_rows(df_CS)
                                
                              }
                              
                              
                              
                              
                              df_model_CS$index <- ii
                              
                              # 
                              d_time <- round( Sys.time()- i_time )
                              
                              #cat(paste("index =", ii,
                               #         ", S =", round(min(df_model_CS$S, na.rm = T)),", time = ",  d_time , "\n"), file = "out_log", append = T)
                              
                              
                              #length(df_CS$time
                              
                              return(df_model_CS)
                              
                              #full_CS_df[(n_obs*(ii-1)),] <- df_CS
                              
                            }
    
  }
  
  #sink()
  
  
  ### if 2 CMT comp
  
  if(DRUG == "ERY"){
    
    
    #ODE
    CS_mod<- RxODE({
      
      
      ####### PK######
      
      d/dt(A_CIP)  =  -CIP_ke*A_CIP
      d/dt(A_AB)   =  -AB_ke*A_AB    - AB_k12*A_AB + AB_k21*A2_AB
      d/dt(A2_AB)  =   AB_k12*A_AB   - AB_k21*A2_AB
      
      
      #AB conc
      CIP =  A_CIP/CIP_V*CIP_fu
      AB  =  A_AB/AB_V*AB_fu
      
      
      
      
      KG_S = KG_D39   #Yu et al
      KG_ParC = KG_D39*abs_KG_ParC/abs_KG_S
      KG_GyrA = KG_D39*abs_KG_GyrA/abs_KG_S
      KG_R    = KG_D39*abs_KG_R/abs_KG_S
      
      ###PD#####
  
      
      
      
      #Sensitive wild type
      
      E_AB_S  = (1 - Gmin_AB/KG_S)*(AB/MIC_AB_S)^HILL_AB/((AB/MIC_AB_S)^HILL_AB - (Gmin_AB/KG_S))
      E_CIP_S = (1 - Gmin_CIP/KG_S)*(CIP/MIC_CIP_S)^HILL_CIP/((CIP/MIC_CIP_S)^HILL_CIP - (Gmin_CIP/KG_S))
      E_INTER_S = E_AB_S/(-(Gmin_AB/KG_S -1))*E_CIP_S/(-(Gmin_CIP/KG_S -1))*INTER*((-(Gmin_AB/KG_S -1))+(-(Gmin_CIP/KG_S -1)))
      
      d/dt(S) = S*(1-((S+ParC+GyrA+R)/10^Bmax))*KG_S*(1 - (E_AB_S + E_CIP_S + E_INTER_S )) -
        
        GR_S_ParC/V -
        GR_S_GyrA/V -
        ke*S
      
      
      # Single resistant mutants with mutation in ParC
      E_AB_ParC  = (1 - Gmin_AB/KG_ParC)*(AB/MIC_AB_ParC)^HILL_AB/((AB/MIC_AB_ParC)^HILL_AB - (Gmin_AB/KG_ParC))
      E_CIP_ParC = (1 - Gmin_CIP/KG_ParC)*(CIP/(MIC_CIP_ParC))^HILL_CIP/((CIP/(MIC_CIP_ParC))^HILL_CIP - (Gmin_CIP/KG_ParC))
      E_INTER_ParC = E_AB_ParC/(-(Gmin_AB/KG_ParC -1))*E_CIP_ParC/(-(Gmin_CIP/KG_ParC -1))*INTER*((-(Gmin_AB/KG_ParC -1))+(-(Gmin_CIP/KG_ParC -1)))
      
      d/dt(ParC) = ParC*(1-((S+ParC+GyrA+R)/10^Bmax))*KG_ParC*(1- (E_AB_ParC + E_CIP_ParC + E_INTER_ParC)) +
        
    
        GR_S_ParC/V - 
        GR_ParC_R/V -
        ke*ParC
      
      
      # Single resistant mutants with mutaion in GyrA
      E_AB_GyrA = (1 - Gmin_AB/KG_GyrA)*(AB/MIC_AB_GyrA)^HILL_AB/((AB/MIC_AB_GyrA)^HILL_AB - (Gmin_AB/KG_GyrA))
      E_CIP_GyrA = (1 - Gmin_CIP/KG_GyrA)*(CIP/(MIC_CIP_GyrA))^HILL_CIP/((CIP/(MIC_CIP_GyrA))^HILL_CIP - (Gmin_CIP/KG_GyrA))
      E_INTER_GyrA = E_AB_GyrA/(-(Gmin_AB/KG_GyrA -1))*E_CIP_GyrA/(-(Gmin_CIP/KG_GyrA -1))*INTER*((-(Gmin_AB/KG_GyrA -1))+(-(Gmin_CIP/KG_GyrA -1)))
      
      d/dt(GyrA) = GyrA*(1-((S+ParC+GyrA+R)/10^Bmax))*KG_GyrA*(1- (E_AB_GyrA +  E_CIP_GyrA  + E_INTER_GyrA)) +
        
        
        GR_S_GyrA/V - 
        GR_GyrA_R/V -
        ke*GyrA
      
      
      # Single resistant mutants to antibiotic B
      E_AB_R  = (1 - Gmin_AB/KG_R)*(AB/(MIC_AB_R))^HILL_AB/((AB/(MIC_AB_R))^HILL_AB - (Gmin_AB/KG_R))
      E_CIP_R = (1 - Gmin_CIP/KG_R)*(CIP/MIC_CIP_R)^HILL_CIP/((CIP/MIC_CIP_R)^HILL_CIP - (Gmin_CIP/KG_R))
      E_INTER_R = E_AB_R/(-(Gmin_AB/KG_R-1))*E_CIP_R/(-(Gmin_CIP/KG_R -1))*INTER*((-(Gmin_AB/KG_R-1))+(-(Gmin_CIP/KG_R -1)))
      
      d/dt(R) = R*(1-((S+ParC+GyrA+R)/10^Bmax))*KG_R*(1 - (E_AB_R + E_CIP_R + E_INTER_R)) +
        
        GR_ParC_R/V + 
        GR_GyrA_R/V -
        ke*R
      
      
      
    });
    
    
    
    S0  <- 10^eS0
    U   <- p_u
    V_blood <- 5*1000 #mL
    V   <- V_blood
    
    theta <- c( Bmax        = p_Bmax,    # maximum carrying capacity 
                abs_KG_S    = p_KG_S,    # maximal net growth S
                abs_KG_ParC = p_KG_ParC,    # maximal net growth I
                abs_KG_GyrA = p_KG_GyrA,    # maximal net growth I
                abs_KG_R    = p_KG_R,    # maximal net growth R
                KG_D39      = log(2)/(54/60), #D39
                
            
                
                Gmin_CIP = p_GMIN_CIP,
                HILL_CIP = p_HILL_CIP,
                
                Gmin_AB  = p_GMIN_AB,
                HILL_AB  = p_HILL_AB,
                
                INTER    = p_INTER, 
                
                MIC_CIP_S = p_MIC_CIP_S, #CIP MIC if sensitive WT (S)
                MIC_CIP_ParC = p_MIC_CIP_ParC, #CIP MIC if intermediate resistant (I) (parC)
                MIC_CIP_GyrA = p_MIC_CIP_GyrA, #CIP MIC if intermediate resistant (I) (gyrA)
                MIC_CIP_R = p_MIC_CIP_R, #CIP MIC if resistant  (R)  (gryA + parC)
                MIC_AB_S  = p_MIC_AB_S,  #MIC if sensitive WT (S)
                MIC_AB_ParC  = p_MIC_AB_ParC,  #MIC if intermediate resistant (I) (parC)
                MIC_AB_GyrA  = p_MIC_AB_GyrA,  #MIC if intermediate resistant (I) (gyrA)
                MIC_AB_R  = p_MIC_AB_R  , #MIC if resistant (R) (gyrA + parC)
                
                V       = p_V, 
                ke      = p_ke,
                CIP_ke  = CIP_ke,
                CIP_V   = CIP_V,
                CIP_fu  = CIP_fu,
                AB_ke   = AB_ke,
                AB_k12  = AB_k12,
                AB_V    = AB_V,
                AB_k21  = AB_k21,
                AB_fu   = AB_fu)    # PK elimination rate constant))
    
    #n = 100
    
    
    
    #n_obs <- length(PK_1day$time)
    n_obs  <- ST*DT+1
    n_models <- length(PK_model_list)
    
    
    df_full_CS <-  foreach( ii = 1:n, .combine = "rbind", 
                            .packages = c("RxODE", "dplyr", "ggplot2", "tidyr"),
                            
                            .inorder = F,
                            .options.RNG = 123) %dorng%  {
                              
                              #cat(paste("in index =", ii, "\n"), file = "start_log", append = T)
                              
                              i_time <- Sys.time() 
                              
                              df_model_CS <- data.frame(time  = NA,
                                                        S     = NA,
                                                        ParC  = NA,
                                                        R     = NA,
                                                        GyrA  = NA,
                                                        A_CIP = NA,
                                                        CIP   = NA,
                                                        A_AB  = NA,
                                                        A2_AB = NA,
                                                        AB    = NA,
                                                        model = NA)
                              
                              for(i_mod in 1:length(PK_model_list)) {
                                #   #   
                                
                                #cat(paste("Started", i_mod), file = "first_loop_log", append = T)
                                
                                
                                PK_mod = PK_model_list[[i_mod]]
                                #print(PK_mod)
                                
                                
                                df_CS <- data.frame(time     = rep(x = NA, times = n_obs),
                                                    S        = rep(x = NA, times = n_obs),
                                                    ParC     = rep(x = NA, times = n_obs),
                                                    GyrA     = rep(x = NA, times = n_obs),
                                                    R        = rep(x = NA, times = n_obs),
                                                    A_CIP    = rep(x = NA, times = n_obs),
                                                    CIP      = rep(x = NA, times = n_obs),
                                                    A_AB     = rep(x = NA, times = n_obs),
                                                    A2_AB    = rep(x = NA, times = n_obs),
                                                    AB       = rep(x = NA, times = n_obs))
                                
                                
                                
                                
                                
                                df_CS[1,] <- data.frame(time = 0, S = 10^eS0, ParC = 0, GyrA = 0, R = 0, 
                                                        A_CIP = PK_mod$A_CIP[1], CIP = PK_mod$CIP[1], 
                                                        A_AB  =  PK_mod$A_AB[1], A2_AB = PK_mod$A2_AB[1], 
                                                        AB = PK_mod$AB[1]);
                                
                                
                                #cat(paste("index =", ii, "modlel =", dose_reg[i_mod] ,
                                  #        ", time = ",  df_CS$time[1], ", S = ",  df_CS$S[1], ", ParC = ",  df_CS$ParC[1],", GyrA = ",  df_CS$GyrA[1], ", R = ",  df_CS$R[1],
                                   #       ", CIP = ",  df_CS$CIP[1], ", AB = ",  df_CS$AB[1], "\n"), file = "begining_log", append = T)
                                
                                
                                V = p_V
                                #########
                                for (i in 1:((ST+T_start)*DT)) {
                                  
                                  #Previous time points
                                  
                                  S_t    <- df_CS$S[i]
                                  ParC_t <- df_CS$ParC[i]
                                  GyrA_t <- df_CS$GyrA[i]
                                  R_t    <- df_CS$R[i]
                                  
                                  CIP_t  <- PK_mod$CIP[i]
                                  AB_t   <- PK_mod$AB[i]
                                  
                                  A_CIP_t  <- PK_mod$A_CIP[i]
                                  A_AB_t   <- PK_mod$A_AB[i]
                                  A2_AB_t  <- PK_mod$A2_AB[i]
                                  
                                  
                                  
                                  
                                  #-------------------
                                  # Mutations
                                  
                                  
                                  
                                  
                                  if(is.na(as.integer( S_t*V ))) {
                                    
                                    n_itr <- floor(S_t*V/10^9)
                                    
                                    res_t <- floor(S_t*V - n_itr*10^9)
                                    
                                    GR_S_ParC  <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    GR_S_GyrA  <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    
                                    
                                  } else if (as.integer( S_t*V )>0) {
                                    
                                    GR_S_ParC    <- rbinom(1, as.integer( S_t*V ), U)
                                    GR_S_GyrA    <- rbinom(1, as.integer( S_t*V ), U)
                                    
                                  } else{
                                    GR_S_ParC     <- 0
                                    GR_S_GyrA     <- 0
                                  }
                                  
                                  
                                  
                                  
                                  
                                  
                                  if(is.na(as.integer( ParC_t*V ))) {
                                    
                                    n_itr <- floor(ParC_t*V/10^9)
                                    
                                    res_t <- floor(ParC_t*V - n_itr*10^9)
                                    
                                    GR_ParC_R  <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    
                                    
                                  } else if (as.integer( ParC_t*V )>0) {
                                    
                                    GR_ParC_R   <- rbinom(1, as.integer( ParC_t*V ), U)
                                    
                                  } else{
                                    GR_ParC_R   <- 0
                                  }
                                  
                                  
                                  
                                  if(is.na(as.integer( GyrA_t*V ))) {
                                    
                                    n_itr <- floor(GyrA_t*V/10^9)
                                    
                                    res_t <- floor(GyrA_t*V - n_itr*10^9)
                                    
                                    GR_GyrA_R  <- sum(rbinom(n_itr, 10^9, U), rbinom( 1, res_t, U))
                                    
                                    
                                  } else if (as.integer( GyrA_t*V )>0) {
                                    
                                    GR_GyrA_R   <- rbinom(1, as.integer( GyrA_t*V ), U)
                                    
                                  } else{
                                    GR_GyrA_R   <- 0
                                  }
                                  
                                  
                                  
                                  
                                  #cat(paste("index =", ii, "time_step=", i,  "model =", dose_reg[i_mod] ,
                                   #         ", GR_S_ParC", GR_S_ParC, ", GR_S_GyrA = ", GR_S_GyrA, ", GR_ParC_R = ", GR_ParC_R, ", GR_GyrA_R = ", GR_GyrA_R, "\n"), file = "mut_log", append = T)
                                  
                                  
                                  
                                  ev <- eventTable(amount.units="mg", time.units="hours") %>%
                                    add.sampling(seq(0,1))  %>%
                                    mutate(GR_S_ParC  = GR_S_ParC,
                                           GR_S_GyrA  = GR_S_GyrA,
                                           GR_ParC_R  = GR_ParC_R,
                                           GR_GyrA_R  = GR_GyrA_R) %>% 
                                    as.tbl()
                                  
                                  
                                  
                                  t_inits <- c(S = S_t, ParC = ParC_t, GyrA = GyrA_t, R = R_t,
                                               A_CIP = A_CIP_t, CIP = CIP_t, A_AB = A_AB_t,  AB = AB_t);
                                  
                                  # cat(paste("index =", ii, "time_step=", i,  "modlel =", dose_reg[i_mod] ,
                                  #           ", tinits, S = ",  t_inits[1], ", ParC = ",  t_inits[2], ", GyrA = ",  t_inits[3], ", R = ",  t_inits[4],
                                  #           ", A_CIP = ",  t_inits[5], ", CIP = ",  t_inits[6], ", A_AB = ",  t_inits[7], ", AB = ",  t_inits[8], "\n"), file = "t_inits_log", append = T)
                                  # 
                                  
                                  
                                  x_CS   <- as.data.frame(CS_mod$run(theta, ev,  t_inits)) %>%
                                    mutate(time = time + i-1)  %>% 
                                    select(time , S , ParC, GyrA, R ,A_CIP, CIP , A_AB, A2_AB, AB);
                                  
                                  
                                  df_CS[i:(i+1),] <- x_CS
                                  
                                  
                                  
                                  # cat(paste("index =", ii, "time_step=", i,  "modlel =", dose_reg[i_mod] ,
                                  #           ", time = ",  df_CS$time[1], ", S = ",  df_CS$S[1], ", ParC = ",  df_CS$ParC[1], ", GyrA = ",  df_CS$GyrA[1], ", R = ",  df_CS$R[1],
                                  #           ", CIP = ",  df_CS$CIP[1], ", AB = ",  df_CS$AB[1], "\n"), file = "mid_2_log", append = T)
                                  # 
                                  
                                  
                                  
                                }
                                
                                
                                
                                df_CS$model <- dose_reg[i_mod] 
                                
                                df_model_CS <- df_model_CS %>%
                                  bind_rows(df_CS)
                                
                              }
                              
                              
                              
                              
                              df_model_CS$index <- ii
                              
                              # 
                              d_time <- round( Sys.time()- i_time )
                              
                              # cat(paste("index =", ii,
                              #           ", S =", round(min(df_model_CS$S, na.rm = T)),", time = ",  d_time , "\n"), file = "out_log", append = T)
                              # 
                              
                              #length(df_CS$time
                              
                              return(df_model_CS)
                              
                              #full_CS_df[(n_obs*(ii-1)),] <- df_CS
                              
                            }
    
  }
  
  
  
  #print(head(df_full_CS))
  
  mean_dat <-  df_full_CS %>% 
    select(time , S , ParC, GyrA, R , A_CIP, CIP , A_AB, AB, index, model) %>% 
    gather(value = "CFU", key = "Population", - time, -CIP, -A_CIP, -AB, -A_AB, -index, -model) %>% 
    group_by(time, model, index) %>%
    mutate(total = sum(CFU)) %>%
    ungroup() %>%
    mutate(CFU_ratio = CFU/total) %>%
    mutate(Order = ifelse(Population == "S", 1,
                          ifelse(Population == "ParC", 2,
                                 ifelse(Population == "GyrA", 3, 4)))) %>%
    mutate(Population = reorder(Population, Order)) %>% 
    ungroup() %>%
    group_by(model, index, time) %>% 
    mutate(CFU_total = sum(CFU, na.rm = T)) %>%  #calculate  total CFU per realization, time point and dosing regimen
    ungroup() %>% 
    group_by(time, model, Population) %>% 
    
    mutate(CFU_MEDIAN = median(CFU, na.rm = T),
           CFU_SD   = sd(CFU, na.rm = T), 
           CFU_95   = quantile(CFU, .95, na.rm = T),
           CFU_05   = quantile(CFU, .05, na.rm = T),
           mean_ratio = mean(CFU_ratio, na.rm = T)) %>% 
    ungroup() %>% 
    group_by( Population, model, index) %>% 
    mutate(T_R = min(ifelse(CFU >= 10^eS0, #S0,
                            time, NA), na.rm = T)) %>% 
    ungroup() %>% 
    group_by(Population, model) %>% 
    # mutate(T_R_MEDIAN = median(T_R, na.rm = T),
    #        T_R_MEAN = mean(T_R, na.rm = T),
    #        T_R_SD   = sd(T_R, na.rm = T), 
    #        T_R_SE   = sd(T_R, na.rm = T)/sqrt(n),
    #        T_R_95   = quantile(T_R, .95, na.rm = T),
    #        T_R_05   = quantile(T_R, .05, na.rm = T)) %>% 
    ungroup() %>% 
    group_by(Population, model) %>%
    mutate(End_CFU = ifelse(time == ST+T_start, CFU, NA),
           End_T_CFU = ifelse(time == ST+T_start, CFU_total, NA),
           day_id  = ifelse(is.wholenumber(time/24), index, 0),
           Day_CFU = ifelse(is.wholenumber(time/24), CFU, NA) ,
           Day_T_CFU = ifelse(is.wholenumber(time/24), CFU_total, NA),
           mean_ratio = mean(CFU_ratio, na.rm = T),
           CFU_T_MEDIAN = median(CFU_total, na.rm = T),
           CFU_T_SD   = sd(CFU_total, na.rm = T), 
           CFU_T_95   = quantile(CFU_total, .95, na.rm = T),
           CFU_T_05   = quantile(CFU_total, .05, na.rm = T),) %>% 
    
    mutate(R_Dev = sum(End_CFU >= 10^eS0, na.rm = T),
           R_T_Dev = sum(End_T_CFU >= 10^eS0, na.rm = T),
           R_Day_Dev = sum(Day_CFU >= 10^eS0, na.rm = T),
           R_T_Day_Dev = sum(Day_T_CFU >= 10^eS0, na.rm = T)) %>%
    ungroup() %>% 
    
    distinct(Population, time, model, day_id, .keep_all = T) %>% 
    select(time, CIP, AB, Population, model, CFU_MEDIAN, CFU_SD, CFU_95, CFU_05, mean_ratio , 
           Day_CFU, Day_T_CFU, CFU_T_MEDIAN, CFU_T_SD, CFU_T_95, CFU_T_05, mean_ratio , index, day_id,
           End_CFU, End_T_CFU, R_Dev, R_T_Dev, R_Day_Dev, R_T_Day_Dev)%>% 
    filter(!is.na(model))
  
  
  #print(head(mean_dat))

  
  
  
  run_t   <-  Sys.time() - start_t 
  print(run_t)
  
  if(OUT == T){
    write.csv( mean_dat, paste0("Results/", Sys.Date(), "ID_", sim_ID, "_CS_model_$S_output.csv"))
  }
  
  
  #return(all_res) 
  return(mean_dat)
}
