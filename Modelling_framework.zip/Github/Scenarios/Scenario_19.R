#################################
### CS model with random draw ###
###    Sequential PK and PD   ###
###        Linda Aulin        ###
#####       20200129        #####
#################################
# Adapted for S.pneumo data    ##
####       20200416          ####
##### Including 17states    #####
### WT, parC, gyrA, parC+gyrA ###
# # # #  FREE-4-ALL  # # # # # ##
#################################



# Load packages

library(doParallel)
library(doRNG)
library(readxl)
library(RxODE)
library(dplyr)
library(tidyr)
library(ggplot2)
#library(patchwork)

#Set wd

setwd("/home/linda/LA_12_D39/")
wd <- getwd()


# set scenario

Scenario_n <- 19
#FREE 4 ALL

nodelist<-rep("localhost",47) # 60 cores
cl<-makePSOCKcluster(nodelist, outfile='log.txt') 
registerDoParallel(cl)
clusterCall(cl, function(x) .libPaths(x), .libPaths())

# clusterEvalQ(cl, setwd("/home/linda/D39_CS/")) # set work dir correctly to each cluster instance
clusterEvalQ(cl, "/home/linda/LA_12_D39/") # set work dir correctly to each cluster instance

#----------

model_dat <- read.csv("Data/model_input.csv", stringsAsFactors = F) %>% 
  filter(AB == "PEN") %>% 
  mutate(Strain_ParC_KG = gsub("ParC:", "p", Strain_ParC),
         Strain_GyrA_KG = gsub("GyrA:", "g", Strain_GyrA),
         Strain_ParC_CIP = gsub("ParC:", "p", Strain_ParC),
         Strain_GyrA_CIP = gsub("GyrA:", "g", Strain_GyrA),
         Strain_ParC_AB = gsub("ParC:", "p", Strain_ParC),
         Strain_GyrA_AB = gsub("GyrA:", "g", Strain_GyrA)) %>% 
  mutate(Strain_R_KG = paste0(Strain_GyrA_KG , Strain_ParC_KG),
         Strain_R_CIP = paste0(Strain_GyrA_CIP , Strain_ParC_CIP),
         Strain_R_AB = paste0(Strain_GyrA_AB , Strain_ParC_AB)) %>% 
  pivot_wider( names_from = Strain_ParC_KG, values_from = KG_ParC, names_prefix = "KG_") %>% 
  pivot_wider( names_from = Strain_GyrA_KG, values_from = KG_GyrA, names_prefix = "KG_") %>% 
  pivot_wider( names_from = Strain_R_KG, values_from = KG_R, names_prefix = "KG_") %>% 
  pivot_wider( names_from = Strain_ParC_CIP, values_from = MIC_CIP_ParC, names_prefix = "MIC_CIP_") %>% 
  pivot_wider( names_from = Strain_GyrA_CIP, values_from = MIC_CIP_GyrA, names_prefix = "MIC_CIP_") %>% 
  pivot_wider( names_from = Strain_R_CIP, values_from    = MIC_CIP_R, names_prefix    = "MIC_CIP_") %>% 
  pivot_wider( names_from = Strain_ParC_AB, values_from = MIC_AB_ParC, names_prefix = "MIC_AB_") %>% 
  pivot_wider( names_from = Strain_GyrA_AB, values_from = MIC_AB_GyrA, names_prefix = "MIC_AB_") %>% 
  pivot_wider( names_from = Strain_R_AB, values_from    = MIC_AB_R, names_prefix    = "MIC_AB_") %>% 
  select(-c(1:3, 5:8, 17:18)) %>% 
  summarise_all(max, na.rm = T) %>% 
  mutate( CSS_CIP  = 0.5,
           CSS_AB   = 1) #,
          # KG_pS79Y      = KG_S,
          # KG_pS79F      = KG_S,
          # KG_pD83Y      = KG_S,
          # KG_pD83N      = KG_S,
          # KG_gS81Y      = KG_S,
          # KG_gS81F      = KG_S,
          # KG_gE85K      = KG_S,
          # KG_gE85G      = KG_S,
          # KG_gS81YpS79Y = KG_S,
          # KG_gS81YpS79F = KG_S,
          # KG_gS81FpS79Y = KG_S,
          # KG_gS81FpS79F = KG_S,
          # KG_gS81FpD83Y = KG_S,
          # KG_gS81FpD83N = KG_S,
          # KG_gE85KpS79Y = KG_S,
          # KG_gE85GpS79F = KG_S,
          # MIC_AB_pS79Y      = MIC_AB_S,
          # MIC_AB_pS79F      = MIC_AB_S,
          # MIC_AB_pD83Y      = MIC_AB_S,
          # MIC_AB_pD83N      = MIC_AB_S,
          # MIC_AB_gS81Y      = MIC_AB_S,
          # MIC_AB_gS81F      = MIC_AB_S,
          # MIC_AB_gE85K      = MIC_AB_S,
          # MIC_AB_gE85G      = MIC_AB_S,
          # MIC_AB_gS81YpS79Y = MIC_AB_S,
          # MIC_AB_gS81YpS79F = MIC_AB_S,
          # MIC_AB_gS81FpS79Y = MIC_AB_S,
          # MIC_AB_gS81FpS79F = MIC_AB_S,
          # MIC_AB_gS81FpD83Y = MIC_AB_S,
          # MIC_AB_gS81FpD83N = MIC_AB_S,
          # MIC_AB_gE85KpS79Y = MIC_AB_S,
          # MIC_AB_gE85GpS79F = MIC_AB_S)


saveRDS(model_dat, file = paste0("/home/linda/LA_12_D39/Results/Scenario_", Scenario_n, "_input.rds" ))





source("Scripts/CS_Model_PNAS_free4all_2.R")


sim  <- CS_model(
  DRUG       = model_dat$AB                           ,
  DOSE_scale = "MIC"                                  ,
  CSS_CIP             = model_dat$CSS_CIP             ,
  CSS_AB              = model_dat$CSS_AB              ,
  p_KG_S              = model_dat$KG_S                ,
  p_KG_pS79Y          = model_dat$KG_pS79Y            ,
  p_KG_pS79F          = model_dat$KG_pS79F            , 
  p_KG_pD83Y          = model_dat$KG_pD83Y            , 
  p_KG_pD83N          = model_dat$KG_pD83N            , 
  p_KG_gS81Y          = model_dat$KG_gS81Y            , 
  p_KG_gS81F          = model_dat$KG_gS81F            , 
  p_KG_gE85K          = model_dat$KG_gE85K            , 
  p_KG_gE85G          = model_dat$KG_gE85G            , 
  p_KG_gS81YpS79Y     = model_dat$KG_gS81YpS79Y       , 
  p_KG_gS81YpS79F     = model_dat$KG_gS81YpS79F       , 
  p_KG_gS81FpS79Y     = model_dat$KG_gS81FpS79Y       , 
  p_KG_gS81FpS79F     = model_dat$KG_gS81FpS79F       , 
  p_KG_gS81FpD83Y     = model_dat$KG_gS81FpD83Y       ,
  p_KG_gS81FpD83N     = model_dat$KG_gS81FpD83N       ,
  p_KG_gE85KpS79Y     = model_dat$KG_gE85KpS79Y       , 
  p_KG_gE85GpS79F     = model_dat$KG_gE85GpS79F       , 
  p_GMIN_CIP          = model_dat$Gmin_CIP            , 
  p_HILL_CIP          = model_dat$HILL_CIP          , 
  p_GMIN_AB           = model_dat$Gmin_AB           , 
  p_HILL_AB           = model_dat$HILL_AB           , 
  p_INTER             = model_dat$INTER             , 
  p_MIC_CIP_S             = model_dat$MIC_CIP_S         , 
  p_MIC_CIP_pS79Y         = model_dat$MIC_CIP_pS79Y     , 
  p_MIC_CIP_pS79F         = model_dat$MIC_CIP_pS79F     , 
  p_MIC_CIP_pD83Y         = model_dat$MIC_CIP_pD83Y     , 
  p_MIC_CIP_pD83N         = model_dat$MIC_CIP_pD83N     , 
  p_MIC_CIP_gS81Y         = model_dat$MIC_CIP_gS81Y     , 
  p_MIC_CIP_gS81F         = model_dat$MIC_CIP_gS81F     , 
  p_MIC_CIP_gE85K         = model_dat$MIC_CIP_gE85K     , 
  p_MIC_CIP_gE85G         = model_dat$MIC_CIP_gE85G     , 
  p_MIC_CIP_gS81YpS79Y    = model_dat$MIC_CIP_gS81YpS79Y    , 
  p_MIC_CIP_gS81YpS79F    = model_dat$MIC_CIP_gS81YpS79F    , 
  p_MIC_CIP_gS81FpS79Y    = model_dat$MIC_CIP_gS81FpS79Y    , 
  p_MIC_CIP_gS81FpS79F    = model_dat$MIC_CIP_gS81FpS79F    , 
  p_MIC_CIP_gS81FpD83Y    = model_dat$MIC_CIP_gS81FpD83Y    , 
  p_MIC_CIP_gS81FpD83N    = model_dat$MIC_CIP_gS81FpD83N    , 
  p_MIC_CIP_gE85KpS79Y    = model_dat$MIC_CIP_gE85KpS79Y    , 
  p_MIC_CIP_gE85GpS79F    = model_dat$MIC_CIP_gE85GpS79F    , 
  p_MIC_AB_S          = model_dat$MIC_AB_S          , 
  p_MIC_AB_pS79Y      = model_dat$MIC_AB_pS79Y      , 
  p_MIC_AB_pS79F      = model_dat$MIC_AB_pS79F      , 
  p_MIC_AB_pD83Y      = model_dat$MIC_AB_pD83Y      , 
  p_MIC_AB_pD83N      = model_dat$MIC_AB_pD83N      , 
  p_MIC_AB_gS81Y      = model_dat$MIC_AB_gS81Y      , 
  p_MIC_AB_gS81F      = model_dat$MIC_AB_gS81F      , 
  p_MIC_AB_gE85K      = model_dat$MIC_AB_gE85K      , 
  p_MIC_AB_gE85G      = model_dat$MIC_AB_gE85G      , 
  p_MIC_AB_gS81YpS79Y = model_dat$MIC_AB_gS81YpS79Y , 
  p_MIC_AB_gS81YpS79F = model_dat$MIC_AB_gS81YpS79F , 
  p_MIC_AB_gS81FpS79Y = model_dat$MIC_AB_gS81FpS79Y , 
  p_MIC_AB_gS81FpS79F = model_dat$MIC_AB_gS81FpS79F , 
  p_MIC_AB_gS81FpD83Y = model_dat$MIC_AB_gS81FpD83Y , 
  p_MIC_AB_gS81FpD83N = model_dat$MIC_AB_gS81FpD83N , 
  p_MIC_AB_gE85KpS79Y = model_dat$MIC_AB_gE85KpS79Y , 
  p_MIC_AB_gE85GpS79F = model_dat$MIC_AB_gE85GpS79F , 
  
  eS0            = 4,
  p_Bmax         = 8,
  p_V            =  5*1000, # V blood #mL
  
  ST = 24*14, 
  n = 500) #%>% 
#left_join(model_dat)
n = 500

saveRDS(sim, file = paste0("/home/linda/LA_12_D39/Results/Scenario_", Scenario_n,  "_n", n, "_", Sys.Date(), ".rds" )) 




#######

stopCluster(cl)

