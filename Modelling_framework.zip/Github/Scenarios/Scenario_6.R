#################################
### CS model with random draw ###
###    Sequential PK and PD   ###
###        Linda Aulin        ###
#####       20200129        #####
#################################
# Adapted for S.pneumo data    ##
####       20200416          ####
##### Including 4 states    #####
### WT, parC, gyrA, parC+gyrA ###
#################################


# Load packages

library(doParallel)
library(doRNG)
library(readxl)
library(RxODE)
library(dplyr)
library(tidyr)
library(ggplot2)
#library(patchwork)

#Set wd

setwd("/home/linda/LA_12_D39/")
wd <- getwd()


# set scenario

Scenario_n <- 6
#base scenario, not fitness no CE 
# Parallellization

nodelist<-rep("localhost",47) # 60 cores
cl<-makePSOCKcluster(nodelist, outfile='log.txt') 
registerDoParallel(cl)
clusterCall(cl, function(x) .libPaths(x), .libPaths())

# clusterEvalQ(cl, setwd("/home/linda/D39_CS/")) # set work dir correctly to each cluster instance
clusterEvalQ(cl, "/home/linda/LA_12_D39/") # set work dir correctly to each cluster instance

#----------

model_dat <- read.csv("Data/model_input.csv", stringsAsFactors = F)
source("Scripts/CS_Model_PNAS.R")

n = 500


CSS_AB <- 1
CSS_CIP <- 1
AB <-  "ERY"

input_all <- expand_grid(AB, CSS_CIP, CSS_AB ) %>% 
  filter(!(CSS_AB == 0 & CSS_CIP == 0)) %>% 
  filter(!(AB == "CIP" & CSS_AB !=0)) %>% 
  filter(!(AB != "CIP" & CSS_AB ==0)) %>% 
  left_join(model_dat) %>% 
  mutate(KG_ParC = KG_S,
         KG_GyrA = KG_S,
         KG_R = KG_S,
         MIC_AB_ParC = MIC_AB_S,
         MIC_AB_GyrA = MIC_AB_S,
         MIC_AB_R    = MIC_AB_S )


saveRDS(input_all, file = paste0("/home/linda/LA_12_D39/Results/Scenario_", Scenario_n, "_input.rds" ))

for(i in 1:length(input_all$MUT_ParC)){
  
  
  test_par <- input_all[i,] %>% 
    mutate(index = i) %>% 
    rename(DRUG = AB)
  
  
  print(i)
  

  sim  <- CS_model(sim_ID     = i,
                       DRUG       = test_par$DRUG,
                       p_KG_S     = test_par$KG_S,
                   p_KG_ParC      = test_par$KG_ParC       ,
                   p_KG_GyrA      = test_par$KG_GyrA      ,
                   p_KG_R         = test_par$KG_R          ,
                   p_GMIN_CIP     = test_par$Gmin_CIP   ,
                   p_HILL_CIP     = test_par$HILL_CIP   ,
                   p_GMIN_AB      = test_par$Gmin_AB    ,
                   p_HILL_AB      = test_par$HILL_AB    ,
                   p_MIC_CIP_S    = test_par$MIC_CIP_S  ,
                   p_MIC_CIP_ParC = test_par$MIC_CIP_ParC  ,
                   p_MIC_CIP_GyrA = test_par$MIC_CIP_GyrA  ,
                   p_MIC_CIP_R    = test_par$MIC_CIP_R  ,
                   p_MIC_AB_S     = test_par$MIC_AB_S   , 
                   p_MIC_AB_ParC  = test_par$MIC_AB_ParC   , 
                   p_MIC_AB_GyrA  = test_par$MIC_AB_GyrA   , 
                   p_MIC_AB_R     = test_par$MIC_AB_R     ,
                   p_INTER        = test_par$INTER,
                   eS0            = 4,
                   p_Bmax         = 8,
                   CSS_CIP        = test_par$CSS_CIP,
                   CSS_AB        = test_par$CSS_AB,
                   DOSE_scale    = "MIC", 
                   p_V            =  5*1000, # V blood #mL
                  
                   ST = 24*14, 
                   n = 500) %>% 
    mutate(index = i) %>% 
    left_join(test_par)
  
 
  saveRDS(sim, file = paste0("/home/linda/LA_12_D39/Results/Scenario_", Scenario_n, "_sim_",i, "_n",n, "_", Sys.Date(), ".rds" )) 
  
}


#######

stopCluster(cl)



